import { OptionsObjectType } from "../components/shared/OptionsList";
export declare const optionsFromSimpleList: (data: (string | number)[]) => OptionsObjectType[];
export declare const optionsFromObject: (data: any) => OptionsObjectType[];
