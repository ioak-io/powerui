import React, { useState, useRef, useEffect, forwardRef, useLayoutEffect, isValidElement, cloneElement } from 'react';
import { createPortal } from 'react-dom';

/******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
/* global Reflect, Promise, SuppressedError, Symbol */


var __assign = function() {
    __assign = Object.assign || function __assign(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};

function __rest(s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
}

function __awaiter(thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}

function __generator(thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
}

function __spreadArray(to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
}

typeof SuppressedError === "function" ? SuppressedError : function (error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
};

var top = 'top';
var bottom = 'bottom';
var right = 'right';
var left = 'left';
var auto = 'auto';
var basePlacements = [top, bottom, right, left];
var start = 'start';
var end = 'end';
var clippingParents = 'clippingParents';
var viewport = 'viewport';
var popper = 'popper';
var reference = 'reference';
var variationPlacements = /*#__PURE__*/basePlacements.reduce(function (acc, placement) {
  return acc.concat([placement + "-" + start, placement + "-" + end]);
}, []);
var placements = /*#__PURE__*/[].concat(basePlacements, [auto]).reduce(function (acc, placement) {
  return acc.concat([placement, placement + "-" + start, placement + "-" + end]);
}, []); // modifiers that need to read the DOM

var beforeRead = 'beforeRead';
var read = 'read';
var afterRead = 'afterRead'; // pure-logic modifiers

var beforeMain = 'beforeMain';
var main = 'main';
var afterMain = 'afterMain'; // modifier with the purpose to write to the DOM (or write into a framework state)

var beforeWrite = 'beforeWrite';
var write = 'write';
var afterWrite = 'afterWrite';
var modifierPhases = [beforeRead, read, afterRead, beforeMain, main, afterMain, beforeWrite, write, afterWrite];

function getNodeName(element) {
  return element ? (element.nodeName || '').toLowerCase() : null;
}

function getWindow(node) {
  if (node == null) {
    return window;
  }

  if (node.toString() !== '[object Window]') {
    var ownerDocument = node.ownerDocument;
    return ownerDocument ? ownerDocument.defaultView || window : window;
  }

  return node;
}

function isElement(node) {
  var OwnElement = getWindow(node).Element;
  return node instanceof OwnElement || node instanceof Element;
}

function isHTMLElement(node) {
  var OwnElement = getWindow(node).HTMLElement;
  return node instanceof OwnElement || node instanceof HTMLElement;
}

function isShadowRoot(node) {
  // IE 11 has no ShadowRoot
  if (typeof ShadowRoot === 'undefined') {
    return false;
  }

  var OwnElement = getWindow(node).ShadowRoot;
  return node instanceof OwnElement || node instanceof ShadowRoot;
}

// and applies them to the HTMLElements such as popper and arrow

function applyStyles(_ref) {
  var state = _ref.state;
  Object.keys(state.elements).forEach(function (name) {
    var style = state.styles[name] || {};
    var attributes = state.attributes[name] || {};
    var element = state.elements[name]; // arrow is optional + virtual elements

    if (!isHTMLElement(element) || !getNodeName(element)) {
      return;
    } // Flow doesn't support to extend this property, but it's the most
    // effective way to apply styles to an HTMLElement
    // $FlowFixMe[cannot-write]


    Object.assign(element.style, style);
    Object.keys(attributes).forEach(function (name) {
      var value = attributes[name];

      if (value === false) {
        element.removeAttribute(name);
      } else {
        element.setAttribute(name, value === true ? '' : value);
      }
    });
  });
}

function effect$2(_ref2) {
  var state = _ref2.state;
  var initialStyles = {
    popper: {
      position: state.options.strategy,
      left: '0',
      top: '0',
      margin: '0'
    },
    arrow: {
      position: 'absolute'
    },
    reference: {}
  };
  Object.assign(state.elements.popper.style, initialStyles.popper);
  state.styles = initialStyles;

  if (state.elements.arrow) {
    Object.assign(state.elements.arrow.style, initialStyles.arrow);
  }

  return function () {
    Object.keys(state.elements).forEach(function (name) {
      var element = state.elements[name];
      var attributes = state.attributes[name] || {};
      var styleProperties = Object.keys(state.styles.hasOwnProperty(name) ? state.styles[name] : initialStyles[name]); // Set all values to an empty string to unset them

      var style = styleProperties.reduce(function (style, property) {
        style[property] = '';
        return style;
      }, {}); // arrow is optional + virtual elements

      if (!isHTMLElement(element) || !getNodeName(element)) {
        return;
      }

      Object.assign(element.style, style);
      Object.keys(attributes).forEach(function (attribute) {
        element.removeAttribute(attribute);
      });
    });
  };
} // eslint-disable-next-line import/no-unused-modules


var applyStyles$1 = {
  name: 'applyStyles',
  enabled: true,
  phase: 'write',
  fn: applyStyles,
  effect: effect$2,
  requires: ['computeStyles']
};

function getBasePlacement(placement) {
  return placement.split('-')[0];
}

var max = Math.max;
var min = Math.min;
var round = Math.round;

function getUAString() {
  var uaData = navigator.userAgentData;

  if (uaData != null && uaData.brands && Array.isArray(uaData.brands)) {
    return uaData.brands.map(function (item) {
      return item.brand + "/" + item.version;
    }).join(' ');
  }

  return navigator.userAgent;
}

function isLayoutViewport() {
  return !/^((?!chrome|android).)*safari/i.test(getUAString());
}

function getBoundingClientRect(element, includeScale, isFixedStrategy) {
  if (includeScale === void 0) {
    includeScale = false;
  }

  if (isFixedStrategy === void 0) {
    isFixedStrategy = false;
  }

  var clientRect = element.getBoundingClientRect();
  var scaleX = 1;
  var scaleY = 1;

  if (includeScale && isHTMLElement(element)) {
    scaleX = element.offsetWidth > 0 ? round(clientRect.width) / element.offsetWidth || 1 : 1;
    scaleY = element.offsetHeight > 0 ? round(clientRect.height) / element.offsetHeight || 1 : 1;
  }

  var _ref = isElement(element) ? getWindow(element) : window,
      visualViewport = _ref.visualViewport;

  var addVisualOffsets = !isLayoutViewport() && isFixedStrategy;
  var x = (clientRect.left + (addVisualOffsets && visualViewport ? visualViewport.offsetLeft : 0)) / scaleX;
  var y = (clientRect.top + (addVisualOffsets && visualViewport ? visualViewport.offsetTop : 0)) / scaleY;
  var width = clientRect.width / scaleX;
  var height = clientRect.height / scaleY;
  return {
    width: width,
    height: height,
    top: y,
    right: x + width,
    bottom: y + height,
    left: x,
    x: x,
    y: y
  };
}

// means it doesn't take into account transforms.

function getLayoutRect(element) {
  var clientRect = getBoundingClientRect(element); // Use the clientRect sizes if it's not been transformed.
  // Fixes https://github.com/popperjs/popper-core/issues/1223

  var width = element.offsetWidth;
  var height = element.offsetHeight;

  if (Math.abs(clientRect.width - width) <= 1) {
    width = clientRect.width;
  }

  if (Math.abs(clientRect.height - height) <= 1) {
    height = clientRect.height;
  }

  return {
    x: element.offsetLeft,
    y: element.offsetTop,
    width: width,
    height: height
  };
}

function contains(parent, child) {
  var rootNode = child.getRootNode && child.getRootNode(); // First, attempt with faster native method

  if (parent.contains(child)) {
    return true;
  } // then fallback to custom implementation with Shadow DOM support
  else if (rootNode && isShadowRoot(rootNode)) {
      var next = child;

      do {
        if (next && parent.isSameNode(next)) {
          return true;
        } // $FlowFixMe[prop-missing]: need a better way to handle this...


        next = next.parentNode || next.host;
      } while (next);
    } // Give up, the result is false


  return false;
}

function getComputedStyle(element) {
  return getWindow(element).getComputedStyle(element);
}

function isTableElement(element) {
  return ['table', 'td', 'th'].indexOf(getNodeName(element)) >= 0;
}

function getDocumentElement(element) {
  // $FlowFixMe[incompatible-return]: assume body is always available
  return ((isElement(element) ? element.ownerDocument : // $FlowFixMe[prop-missing]
  element.document) || window.document).documentElement;
}

function getParentNode(element) {
  if (getNodeName(element) === 'html') {
    return element;
  }

  return (// this is a quicker (but less type safe) way to save quite some bytes from the bundle
    // $FlowFixMe[incompatible-return]
    // $FlowFixMe[prop-missing]
    element.assignedSlot || // step into the shadow DOM of the parent of a slotted node
    element.parentNode || ( // DOM Element detected
    isShadowRoot(element) ? element.host : null) || // ShadowRoot detected
    // $FlowFixMe[incompatible-call]: HTMLElement is a Node
    getDocumentElement(element) // fallback

  );
}

function getTrueOffsetParent(element) {
  if (!isHTMLElement(element) || // https://github.com/popperjs/popper-core/issues/837
  getComputedStyle(element).position === 'fixed') {
    return null;
  }

  return element.offsetParent;
} // `.offsetParent` reports `null` for fixed elements, while absolute elements
// return the containing block


function getContainingBlock(element) {
  var isFirefox = /firefox/i.test(getUAString());
  var isIE = /Trident/i.test(getUAString());

  if (isIE && isHTMLElement(element)) {
    // In IE 9, 10 and 11 fixed elements containing block is always established by the viewport
    var elementCss = getComputedStyle(element);

    if (elementCss.position === 'fixed') {
      return null;
    }
  }

  var currentNode = getParentNode(element);

  if (isShadowRoot(currentNode)) {
    currentNode = currentNode.host;
  }

  while (isHTMLElement(currentNode) && ['html', 'body'].indexOf(getNodeName(currentNode)) < 0) {
    var css = getComputedStyle(currentNode); // This is non-exhaustive but covers the most common CSS properties that
    // create a containing block.
    // https://developer.mozilla.org/en-US/docs/Web/CSS/Containing_block#identifying_the_containing_block

    if (css.transform !== 'none' || css.perspective !== 'none' || css.contain === 'paint' || ['transform', 'perspective'].indexOf(css.willChange) !== -1 || isFirefox && css.willChange === 'filter' || isFirefox && css.filter && css.filter !== 'none') {
      return currentNode;
    } else {
      currentNode = currentNode.parentNode;
    }
  }

  return null;
} // Gets the closest ancestor positioned element. Handles some edge cases,
// such as table ancestors and cross browser bugs.


function getOffsetParent(element) {
  var window = getWindow(element);
  var offsetParent = getTrueOffsetParent(element);

  while (offsetParent && isTableElement(offsetParent) && getComputedStyle(offsetParent).position === 'static') {
    offsetParent = getTrueOffsetParent(offsetParent);
  }

  if (offsetParent && (getNodeName(offsetParent) === 'html' || getNodeName(offsetParent) === 'body' && getComputedStyle(offsetParent).position === 'static')) {
    return window;
  }

  return offsetParent || getContainingBlock(element) || window;
}

function getMainAxisFromPlacement(placement) {
  return ['top', 'bottom'].indexOf(placement) >= 0 ? 'x' : 'y';
}

function within(min$1, value, max$1) {
  return max(min$1, min(value, max$1));
}
function withinMaxClamp(min, value, max) {
  var v = within(min, value, max);
  return v > max ? max : v;
}

function getFreshSideObject() {
  return {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0
  };
}

function mergePaddingObject(paddingObject) {
  return Object.assign({}, getFreshSideObject(), paddingObject);
}

function expandToHashMap(value, keys) {
  return keys.reduce(function (hashMap, key) {
    hashMap[key] = value;
    return hashMap;
  }, {});
}

var toPaddingObject = function toPaddingObject(padding, state) {
  padding = typeof padding === 'function' ? padding(Object.assign({}, state.rects, {
    placement: state.placement
  })) : padding;
  return mergePaddingObject(typeof padding !== 'number' ? padding : expandToHashMap(padding, basePlacements));
};

function arrow(_ref) {
  var _state$modifiersData$;

  var state = _ref.state,
      name = _ref.name,
      options = _ref.options;
  var arrowElement = state.elements.arrow;
  var popperOffsets = state.modifiersData.popperOffsets;
  var basePlacement = getBasePlacement(state.placement);
  var axis = getMainAxisFromPlacement(basePlacement);
  var isVertical = [left, right].indexOf(basePlacement) >= 0;
  var len = isVertical ? 'height' : 'width';

  if (!arrowElement || !popperOffsets) {
    return;
  }

  var paddingObject = toPaddingObject(options.padding, state);
  var arrowRect = getLayoutRect(arrowElement);
  var minProp = axis === 'y' ? top : left;
  var maxProp = axis === 'y' ? bottom : right;
  var endDiff = state.rects.reference[len] + state.rects.reference[axis] - popperOffsets[axis] - state.rects.popper[len];
  var startDiff = popperOffsets[axis] - state.rects.reference[axis];
  var arrowOffsetParent = getOffsetParent(arrowElement);
  var clientSize = arrowOffsetParent ? axis === 'y' ? arrowOffsetParent.clientHeight || 0 : arrowOffsetParent.clientWidth || 0 : 0;
  var centerToReference = endDiff / 2 - startDiff / 2; // Make sure the arrow doesn't overflow the popper if the center point is
  // outside of the popper bounds

  var min = paddingObject[minProp];
  var max = clientSize - arrowRect[len] - paddingObject[maxProp];
  var center = clientSize / 2 - arrowRect[len] / 2 + centerToReference;
  var offset = within(min, center, max); // Prevents breaking syntax highlighting...

  var axisProp = axis;
  state.modifiersData[name] = (_state$modifiersData$ = {}, _state$modifiersData$[axisProp] = offset, _state$modifiersData$.centerOffset = offset - center, _state$modifiersData$);
}

function effect$1(_ref2) {
  var state = _ref2.state,
      options = _ref2.options;
  var _options$element = options.element,
      arrowElement = _options$element === void 0 ? '[data-popper-arrow]' : _options$element;

  if (arrowElement == null) {
    return;
  } // CSS selector


  if (typeof arrowElement === 'string') {
    arrowElement = state.elements.popper.querySelector(arrowElement);

    if (!arrowElement) {
      return;
    }
  }

  if (!contains(state.elements.popper, arrowElement)) {
    return;
  }

  state.elements.arrow = arrowElement;
} // eslint-disable-next-line import/no-unused-modules


var arrow$1 = {
  name: 'arrow',
  enabled: true,
  phase: 'main',
  fn: arrow,
  effect: effect$1,
  requires: ['popperOffsets'],
  requiresIfExists: ['preventOverflow']
};

function getVariation(placement) {
  return placement.split('-')[1];
}

var unsetSides = {
  top: 'auto',
  right: 'auto',
  bottom: 'auto',
  left: 'auto'
}; // Round the offsets to the nearest suitable subpixel based on the DPR.
// Zooming can change the DPR, but it seems to report a value that will
// cleanly divide the values into the appropriate subpixels.

function roundOffsetsByDPR(_ref, win) {
  var x = _ref.x,
      y = _ref.y;
  var dpr = win.devicePixelRatio || 1;
  return {
    x: round(x * dpr) / dpr || 0,
    y: round(y * dpr) / dpr || 0
  };
}

function mapToStyles(_ref2) {
  var _Object$assign2;

  var popper = _ref2.popper,
      popperRect = _ref2.popperRect,
      placement = _ref2.placement,
      variation = _ref2.variation,
      offsets = _ref2.offsets,
      position = _ref2.position,
      gpuAcceleration = _ref2.gpuAcceleration,
      adaptive = _ref2.adaptive,
      roundOffsets = _ref2.roundOffsets,
      isFixed = _ref2.isFixed;
  var _offsets$x = offsets.x,
      x = _offsets$x === void 0 ? 0 : _offsets$x,
      _offsets$y = offsets.y,
      y = _offsets$y === void 0 ? 0 : _offsets$y;

  var _ref3 = typeof roundOffsets === 'function' ? roundOffsets({
    x: x,
    y: y
  }) : {
    x: x,
    y: y
  };

  x = _ref3.x;
  y = _ref3.y;
  var hasX = offsets.hasOwnProperty('x');
  var hasY = offsets.hasOwnProperty('y');
  var sideX = left;
  var sideY = top;
  var win = window;

  if (adaptive) {
    var offsetParent = getOffsetParent(popper);
    var heightProp = 'clientHeight';
    var widthProp = 'clientWidth';

    if (offsetParent === getWindow(popper)) {
      offsetParent = getDocumentElement(popper);

      if (getComputedStyle(offsetParent).position !== 'static' && position === 'absolute') {
        heightProp = 'scrollHeight';
        widthProp = 'scrollWidth';
      }
    } // $FlowFixMe[incompatible-cast]: force type refinement, we compare offsetParent with window above, but Flow doesn't detect it


    offsetParent = offsetParent;

    if (placement === top || (placement === left || placement === right) && variation === end) {
      sideY = bottom;
      var offsetY = isFixed && offsetParent === win && win.visualViewport ? win.visualViewport.height : // $FlowFixMe[prop-missing]
      offsetParent[heightProp];
      y -= offsetY - popperRect.height;
      y *= gpuAcceleration ? 1 : -1;
    }

    if (placement === left || (placement === top || placement === bottom) && variation === end) {
      sideX = right;
      var offsetX = isFixed && offsetParent === win && win.visualViewport ? win.visualViewport.width : // $FlowFixMe[prop-missing]
      offsetParent[widthProp];
      x -= offsetX - popperRect.width;
      x *= gpuAcceleration ? 1 : -1;
    }
  }

  var commonStyles = Object.assign({
    position: position
  }, adaptive && unsetSides);

  var _ref4 = roundOffsets === true ? roundOffsetsByDPR({
    x: x,
    y: y
  }, getWindow(popper)) : {
    x: x,
    y: y
  };

  x = _ref4.x;
  y = _ref4.y;

  if (gpuAcceleration) {
    var _Object$assign;

    return Object.assign({}, commonStyles, (_Object$assign = {}, _Object$assign[sideY] = hasY ? '0' : '', _Object$assign[sideX] = hasX ? '0' : '', _Object$assign.transform = (win.devicePixelRatio || 1) <= 1 ? "translate(" + x + "px, " + y + "px)" : "translate3d(" + x + "px, " + y + "px, 0)", _Object$assign));
  }

  return Object.assign({}, commonStyles, (_Object$assign2 = {}, _Object$assign2[sideY] = hasY ? y + "px" : '', _Object$assign2[sideX] = hasX ? x + "px" : '', _Object$assign2.transform = '', _Object$assign2));
}

function computeStyles(_ref5) {
  var state = _ref5.state,
      options = _ref5.options;
  var _options$gpuAccelerat = options.gpuAcceleration,
      gpuAcceleration = _options$gpuAccelerat === void 0 ? true : _options$gpuAccelerat,
      _options$adaptive = options.adaptive,
      adaptive = _options$adaptive === void 0 ? true : _options$adaptive,
      _options$roundOffsets = options.roundOffsets,
      roundOffsets = _options$roundOffsets === void 0 ? true : _options$roundOffsets;
  var commonStyles = {
    placement: getBasePlacement(state.placement),
    variation: getVariation(state.placement),
    popper: state.elements.popper,
    popperRect: state.rects.popper,
    gpuAcceleration: gpuAcceleration,
    isFixed: state.options.strategy === 'fixed'
  };

  if (state.modifiersData.popperOffsets != null) {
    state.styles.popper = Object.assign({}, state.styles.popper, mapToStyles(Object.assign({}, commonStyles, {
      offsets: state.modifiersData.popperOffsets,
      position: state.options.strategy,
      adaptive: adaptive,
      roundOffsets: roundOffsets
    })));
  }

  if (state.modifiersData.arrow != null) {
    state.styles.arrow = Object.assign({}, state.styles.arrow, mapToStyles(Object.assign({}, commonStyles, {
      offsets: state.modifiersData.arrow,
      position: 'absolute',
      adaptive: false,
      roundOffsets: roundOffsets
    })));
  }

  state.attributes.popper = Object.assign({}, state.attributes.popper, {
    'data-popper-placement': state.placement
  });
} // eslint-disable-next-line import/no-unused-modules


var computeStyles$1 = {
  name: 'computeStyles',
  enabled: true,
  phase: 'beforeWrite',
  fn: computeStyles,
  data: {}
};

var passive = {
  passive: true
};

function effect(_ref) {
  var state = _ref.state,
      instance = _ref.instance,
      options = _ref.options;
  var _options$scroll = options.scroll,
      scroll = _options$scroll === void 0 ? true : _options$scroll,
      _options$resize = options.resize,
      resize = _options$resize === void 0 ? true : _options$resize;
  var window = getWindow(state.elements.popper);
  var scrollParents = [].concat(state.scrollParents.reference, state.scrollParents.popper);

  if (scroll) {
    scrollParents.forEach(function (scrollParent) {
      scrollParent.addEventListener('scroll', instance.update, passive);
    });
  }

  if (resize) {
    window.addEventListener('resize', instance.update, passive);
  }

  return function () {
    if (scroll) {
      scrollParents.forEach(function (scrollParent) {
        scrollParent.removeEventListener('scroll', instance.update, passive);
      });
    }

    if (resize) {
      window.removeEventListener('resize', instance.update, passive);
    }
  };
} // eslint-disable-next-line import/no-unused-modules


var eventListeners = {
  name: 'eventListeners',
  enabled: true,
  phase: 'write',
  fn: function fn() {},
  effect: effect,
  data: {}
};

var hash$1 = {
  left: 'right',
  right: 'left',
  bottom: 'top',
  top: 'bottom'
};
function getOppositePlacement(placement) {
  return placement.replace(/left|right|bottom|top/g, function (matched) {
    return hash$1[matched];
  });
}

var hash = {
  start: 'end',
  end: 'start'
};
function getOppositeVariationPlacement(placement) {
  return placement.replace(/start|end/g, function (matched) {
    return hash[matched];
  });
}

function getWindowScroll(node) {
  var win = getWindow(node);
  var scrollLeft = win.pageXOffset;
  var scrollTop = win.pageYOffset;
  return {
    scrollLeft: scrollLeft,
    scrollTop: scrollTop
  };
}

function getWindowScrollBarX(element) {
  // If <html> has a CSS width greater than the viewport, then this will be
  // incorrect for RTL.
  // Popper 1 is broken in this case and never had a bug report so let's assume
  // it's not an issue. I don't think anyone ever specifies width on <html>
  // anyway.
  // Browsers where the left scrollbar doesn't cause an issue report `0` for
  // this (e.g. Edge 2019, IE11, Safari)
  return getBoundingClientRect(getDocumentElement(element)).left + getWindowScroll(element).scrollLeft;
}

function getViewportRect(element, strategy) {
  var win = getWindow(element);
  var html = getDocumentElement(element);
  var visualViewport = win.visualViewport;
  var width = html.clientWidth;
  var height = html.clientHeight;
  var x = 0;
  var y = 0;

  if (visualViewport) {
    width = visualViewport.width;
    height = visualViewport.height;
    var layoutViewport = isLayoutViewport();

    if (layoutViewport || !layoutViewport && strategy === 'fixed') {
      x = visualViewport.offsetLeft;
      y = visualViewport.offsetTop;
    }
  }

  return {
    width: width,
    height: height,
    x: x + getWindowScrollBarX(element),
    y: y
  };
}

// of the `<html>` and `<body>` rect bounds if horizontally scrollable

function getDocumentRect(element) {
  var _element$ownerDocumen;

  var html = getDocumentElement(element);
  var winScroll = getWindowScroll(element);
  var body = (_element$ownerDocumen = element.ownerDocument) == null ? void 0 : _element$ownerDocumen.body;
  var width = max(html.scrollWidth, html.clientWidth, body ? body.scrollWidth : 0, body ? body.clientWidth : 0);
  var height = max(html.scrollHeight, html.clientHeight, body ? body.scrollHeight : 0, body ? body.clientHeight : 0);
  var x = -winScroll.scrollLeft + getWindowScrollBarX(element);
  var y = -winScroll.scrollTop;

  if (getComputedStyle(body || html).direction === 'rtl') {
    x += max(html.clientWidth, body ? body.clientWidth : 0) - width;
  }

  return {
    width: width,
    height: height,
    x: x,
    y: y
  };
}

function isScrollParent(element) {
  // Firefox wants us to check `-x` and `-y` variations as well
  var _getComputedStyle = getComputedStyle(element),
      overflow = _getComputedStyle.overflow,
      overflowX = _getComputedStyle.overflowX,
      overflowY = _getComputedStyle.overflowY;

  return /auto|scroll|overlay|hidden/.test(overflow + overflowY + overflowX);
}

function getScrollParent(node) {
  if (['html', 'body', '#document'].indexOf(getNodeName(node)) >= 0) {
    // $FlowFixMe[incompatible-return]: assume body is always available
    return node.ownerDocument.body;
  }

  if (isHTMLElement(node) && isScrollParent(node)) {
    return node;
  }

  return getScrollParent(getParentNode(node));
}

/*
given a DOM element, return the list of all scroll parents, up the list of ancesors
until we get to the top window object. This list is what we attach scroll listeners
to, because if any of these parent elements scroll, we'll need to re-calculate the
reference element's position.
*/

function listScrollParents(element, list) {
  var _element$ownerDocumen;

  if (list === void 0) {
    list = [];
  }

  var scrollParent = getScrollParent(element);
  var isBody = scrollParent === ((_element$ownerDocumen = element.ownerDocument) == null ? void 0 : _element$ownerDocumen.body);
  var win = getWindow(scrollParent);
  var target = isBody ? [win].concat(win.visualViewport || [], isScrollParent(scrollParent) ? scrollParent : []) : scrollParent;
  var updatedList = list.concat(target);
  return isBody ? updatedList : // $FlowFixMe[incompatible-call]: isBody tells us target will be an HTMLElement here
  updatedList.concat(listScrollParents(getParentNode(target)));
}

function rectToClientRect(rect) {
  return Object.assign({}, rect, {
    left: rect.x,
    top: rect.y,
    right: rect.x + rect.width,
    bottom: rect.y + rect.height
  });
}

function getInnerBoundingClientRect(element, strategy) {
  var rect = getBoundingClientRect(element, false, strategy === 'fixed');
  rect.top = rect.top + element.clientTop;
  rect.left = rect.left + element.clientLeft;
  rect.bottom = rect.top + element.clientHeight;
  rect.right = rect.left + element.clientWidth;
  rect.width = element.clientWidth;
  rect.height = element.clientHeight;
  rect.x = rect.left;
  rect.y = rect.top;
  return rect;
}

function getClientRectFromMixedType(element, clippingParent, strategy) {
  return clippingParent === viewport ? rectToClientRect(getViewportRect(element, strategy)) : isElement(clippingParent) ? getInnerBoundingClientRect(clippingParent, strategy) : rectToClientRect(getDocumentRect(getDocumentElement(element)));
} // A "clipping parent" is an overflowable container with the characteristic of
// clipping (or hiding) overflowing elements with a position different from
// `initial`


function getClippingParents(element) {
  var clippingParents = listScrollParents(getParentNode(element));
  var canEscapeClipping = ['absolute', 'fixed'].indexOf(getComputedStyle(element).position) >= 0;
  var clipperElement = canEscapeClipping && isHTMLElement(element) ? getOffsetParent(element) : element;

  if (!isElement(clipperElement)) {
    return [];
  } // $FlowFixMe[incompatible-return]: https://github.com/facebook/flow/issues/1414


  return clippingParents.filter(function (clippingParent) {
    return isElement(clippingParent) && contains(clippingParent, clipperElement) && getNodeName(clippingParent) !== 'body';
  });
} // Gets the maximum area that the element is visible in due to any number of
// clipping parents


function getClippingRect(element, boundary, rootBoundary, strategy) {
  var mainClippingParents = boundary === 'clippingParents' ? getClippingParents(element) : [].concat(boundary);
  var clippingParents = [].concat(mainClippingParents, [rootBoundary]);
  var firstClippingParent = clippingParents[0];
  var clippingRect = clippingParents.reduce(function (accRect, clippingParent) {
    var rect = getClientRectFromMixedType(element, clippingParent, strategy);
    accRect.top = max(rect.top, accRect.top);
    accRect.right = min(rect.right, accRect.right);
    accRect.bottom = min(rect.bottom, accRect.bottom);
    accRect.left = max(rect.left, accRect.left);
    return accRect;
  }, getClientRectFromMixedType(element, firstClippingParent, strategy));
  clippingRect.width = clippingRect.right - clippingRect.left;
  clippingRect.height = clippingRect.bottom - clippingRect.top;
  clippingRect.x = clippingRect.left;
  clippingRect.y = clippingRect.top;
  return clippingRect;
}

function computeOffsets(_ref) {
  var reference = _ref.reference,
      element = _ref.element,
      placement = _ref.placement;
  var basePlacement = placement ? getBasePlacement(placement) : null;
  var variation = placement ? getVariation(placement) : null;
  var commonX = reference.x + reference.width / 2 - element.width / 2;
  var commonY = reference.y + reference.height / 2 - element.height / 2;
  var offsets;

  switch (basePlacement) {
    case top:
      offsets = {
        x: commonX,
        y: reference.y - element.height
      };
      break;

    case bottom:
      offsets = {
        x: commonX,
        y: reference.y + reference.height
      };
      break;

    case right:
      offsets = {
        x: reference.x + reference.width,
        y: commonY
      };
      break;

    case left:
      offsets = {
        x: reference.x - element.width,
        y: commonY
      };
      break;

    default:
      offsets = {
        x: reference.x,
        y: reference.y
      };
  }

  var mainAxis = basePlacement ? getMainAxisFromPlacement(basePlacement) : null;

  if (mainAxis != null) {
    var len = mainAxis === 'y' ? 'height' : 'width';

    switch (variation) {
      case start:
        offsets[mainAxis] = offsets[mainAxis] - (reference[len] / 2 - element[len] / 2);
        break;

      case end:
        offsets[mainAxis] = offsets[mainAxis] + (reference[len] / 2 - element[len] / 2);
        break;
    }
  }

  return offsets;
}

function detectOverflow(state, options) {
  if (options === void 0) {
    options = {};
  }

  var _options = options,
      _options$placement = _options.placement,
      placement = _options$placement === void 0 ? state.placement : _options$placement,
      _options$strategy = _options.strategy,
      strategy = _options$strategy === void 0 ? state.strategy : _options$strategy,
      _options$boundary = _options.boundary,
      boundary = _options$boundary === void 0 ? clippingParents : _options$boundary,
      _options$rootBoundary = _options.rootBoundary,
      rootBoundary = _options$rootBoundary === void 0 ? viewport : _options$rootBoundary,
      _options$elementConte = _options.elementContext,
      elementContext = _options$elementConte === void 0 ? popper : _options$elementConte,
      _options$altBoundary = _options.altBoundary,
      altBoundary = _options$altBoundary === void 0 ? false : _options$altBoundary,
      _options$padding = _options.padding,
      padding = _options$padding === void 0 ? 0 : _options$padding;
  var paddingObject = mergePaddingObject(typeof padding !== 'number' ? padding : expandToHashMap(padding, basePlacements));
  var altContext = elementContext === popper ? reference : popper;
  var popperRect = state.rects.popper;
  var element = state.elements[altBoundary ? altContext : elementContext];
  var clippingClientRect = getClippingRect(isElement(element) ? element : element.contextElement || getDocumentElement(state.elements.popper), boundary, rootBoundary, strategy);
  var referenceClientRect = getBoundingClientRect(state.elements.reference);
  var popperOffsets = computeOffsets({
    reference: referenceClientRect,
    element: popperRect,
    strategy: 'absolute',
    placement: placement
  });
  var popperClientRect = rectToClientRect(Object.assign({}, popperRect, popperOffsets));
  var elementClientRect = elementContext === popper ? popperClientRect : referenceClientRect; // positive = overflowing the clipping rect
  // 0 or negative = within the clipping rect

  var overflowOffsets = {
    top: clippingClientRect.top - elementClientRect.top + paddingObject.top,
    bottom: elementClientRect.bottom - clippingClientRect.bottom + paddingObject.bottom,
    left: clippingClientRect.left - elementClientRect.left + paddingObject.left,
    right: elementClientRect.right - clippingClientRect.right + paddingObject.right
  };
  var offsetData = state.modifiersData.offset; // Offsets can be applied only to the popper element

  if (elementContext === popper && offsetData) {
    var offset = offsetData[placement];
    Object.keys(overflowOffsets).forEach(function (key) {
      var multiply = [right, bottom].indexOf(key) >= 0 ? 1 : -1;
      var axis = [top, bottom].indexOf(key) >= 0 ? 'y' : 'x';
      overflowOffsets[key] += offset[axis] * multiply;
    });
  }

  return overflowOffsets;
}

function computeAutoPlacement(state, options) {
  if (options === void 0) {
    options = {};
  }

  var _options = options,
      placement = _options.placement,
      boundary = _options.boundary,
      rootBoundary = _options.rootBoundary,
      padding = _options.padding,
      flipVariations = _options.flipVariations,
      _options$allowedAutoP = _options.allowedAutoPlacements,
      allowedAutoPlacements = _options$allowedAutoP === void 0 ? placements : _options$allowedAutoP;
  var variation = getVariation(placement);
  var placements$1 = variation ? flipVariations ? variationPlacements : variationPlacements.filter(function (placement) {
    return getVariation(placement) === variation;
  }) : basePlacements;
  var allowedPlacements = placements$1.filter(function (placement) {
    return allowedAutoPlacements.indexOf(placement) >= 0;
  });

  if (allowedPlacements.length === 0) {
    allowedPlacements = placements$1;
  } // $FlowFixMe[incompatible-type]: Flow seems to have problems with two array unions...


  var overflows = allowedPlacements.reduce(function (acc, placement) {
    acc[placement] = detectOverflow(state, {
      placement: placement,
      boundary: boundary,
      rootBoundary: rootBoundary,
      padding: padding
    })[getBasePlacement(placement)];
    return acc;
  }, {});
  return Object.keys(overflows).sort(function (a, b) {
    return overflows[a] - overflows[b];
  });
}

function getExpandedFallbackPlacements(placement) {
  if (getBasePlacement(placement) === auto) {
    return [];
  }

  var oppositePlacement = getOppositePlacement(placement);
  return [getOppositeVariationPlacement(placement), oppositePlacement, getOppositeVariationPlacement(oppositePlacement)];
}

function flip(_ref) {
  var state = _ref.state,
      options = _ref.options,
      name = _ref.name;

  if (state.modifiersData[name]._skip) {
    return;
  }

  var _options$mainAxis = options.mainAxis,
      checkMainAxis = _options$mainAxis === void 0 ? true : _options$mainAxis,
      _options$altAxis = options.altAxis,
      checkAltAxis = _options$altAxis === void 0 ? true : _options$altAxis,
      specifiedFallbackPlacements = options.fallbackPlacements,
      padding = options.padding,
      boundary = options.boundary,
      rootBoundary = options.rootBoundary,
      altBoundary = options.altBoundary,
      _options$flipVariatio = options.flipVariations,
      flipVariations = _options$flipVariatio === void 0 ? true : _options$flipVariatio,
      allowedAutoPlacements = options.allowedAutoPlacements;
  var preferredPlacement = state.options.placement;
  var basePlacement = getBasePlacement(preferredPlacement);
  var isBasePlacement = basePlacement === preferredPlacement;
  var fallbackPlacements = specifiedFallbackPlacements || (isBasePlacement || !flipVariations ? [getOppositePlacement(preferredPlacement)] : getExpandedFallbackPlacements(preferredPlacement));
  var placements = [preferredPlacement].concat(fallbackPlacements).reduce(function (acc, placement) {
    return acc.concat(getBasePlacement(placement) === auto ? computeAutoPlacement(state, {
      placement: placement,
      boundary: boundary,
      rootBoundary: rootBoundary,
      padding: padding,
      flipVariations: flipVariations,
      allowedAutoPlacements: allowedAutoPlacements
    }) : placement);
  }, []);
  var referenceRect = state.rects.reference;
  var popperRect = state.rects.popper;
  var checksMap = new Map();
  var makeFallbackChecks = true;
  var firstFittingPlacement = placements[0];

  for (var i = 0; i < placements.length; i++) {
    var placement = placements[i];

    var _basePlacement = getBasePlacement(placement);

    var isStartVariation = getVariation(placement) === start;
    var isVertical = [top, bottom].indexOf(_basePlacement) >= 0;
    var len = isVertical ? 'width' : 'height';
    var overflow = detectOverflow(state, {
      placement: placement,
      boundary: boundary,
      rootBoundary: rootBoundary,
      altBoundary: altBoundary,
      padding: padding
    });
    var mainVariationSide = isVertical ? isStartVariation ? right : left : isStartVariation ? bottom : top;

    if (referenceRect[len] > popperRect[len]) {
      mainVariationSide = getOppositePlacement(mainVariationSide);
    }

    var altVariationSide = getOppositePlacement(mainVariationSide);
    var checks = [];

    if (checkMainAxis) {
      checks.push(overflow[_basePlacement] <= 0);
    }

    if (checkAltAxis) {
      checks.push(overflow[mainVariationSide] <= 0, overflow[altVariationSide] <= 0);
    }

    if (checks.every(function (check) {
      return check;
    })) {
      firstFittingPlacement = placement;
      makeFallbackChecks = false;
      break;
    }

    checksMap.set(placement, checks);
  }

  if (makeFallbackChecks) {
    // `2` may be desired in some cases – research later
    var numberOfChecks = flipVariations ? 3 : 1;

    var _loop = function _loop(_i) {
      var fittingPlacement = placements.find(function (placement) {
        var checks = checksMap.get(placement);

        if (checks) {
          return checks.slice(0, _i).every(function (check) {
            return check;
          });
        }
      });

      if (fittingPlacement) {
        firstFittingPlacement = fittingPlacement;
        return "break";
      }
    };

    for (var _i = numberOfChecks; _i > 0; _i--) {
      var _ret = _loop(_i);

      if (_ret === "break") break;
    }
  }

  if (state.placement !== firstFittingPlacement) {
    state.modifiersData[name]._skip = true;
    state.placement = firstFittingPlacement;
    state.reset = true;
  }
} // eslint-disable-next-line import/no-unused-modules


var flip$1 = {
  name: 'flip',
  enabled: true,
  phase: 'main',
  fn: flip,
  requiresIfExists: ['offset'],
  data: {
    _skip: false
  }
};

function getSideOffsets(overflow, rect, preventedOffsets) {
  if (preventedOffsets === void 0) {
    preventedOffsets = {
      x: 0,
      y: 0
    };
  }

  return {
    top: overflow.top - rect.height - preventedOffsets.y,
    right: overflow.right - rect.width + preventedOffsets.x,
    bottom: overflow.bottom - rect.height + preventedOffsets.y,
    left: overflow.left - rect.width - preventedOffsets.x
  };
}

function isAnySideFullyClipped(overflow) {
  return [top, right, bottom, left].some(function (side) {
    return overflow[side] >= 0;
  });
}

function hide(_ref) {
  var state = _ref.state,
      name = _ref.name;
  var referenceRect = state.rects.reference;
  var popperRect = state.rects.popper;
  var preventedOffsets = state.modifiersData.preventOverflow;
  var referenceOverflow = detectOverflow(state, {
    elementContext: 'reference'
  });
  var popperAltOverflow = detectOverflow(state, {
    altBoundary: true
  });
  var referenceClippingOffsets = getSideOffsets(referenceOverflow, referenceRect);
  var popperEscapeOffsets = getSideOffsets(popperAltOverflow, popperRect, preventedOffsets);
  var isReferenceHidden = isAnySideFullyClipped(referenceClippingOffsets);
  var hasPopperEscaped = isAnySideFullyClipped(popperEscapeOffsets);
  state.modifiersData[name] = {
    referenceClippingOffsets: referenceClippingOffsets,
    popperEscapeOffsets: popperEscapeOffsets,
    isReferenceHidden: isReferenceHidden,
    hasPopperEscaped: hasPopperEscaped
  };
  state.attributes.popper = Object.assign({}, state.attributes.popper, {
    'data-popper-reference-hidden': isReferenceHidden,
    'data-popper-escaped': hasPopperEscaped
  });
} // eslint-disable-next-line import/no-unused-modules


var hide$1 = {
  name: 'hide',
  enabled: true,
  phase: 'main',
  requiresIfExists: ['preventOverflow'],
  fn: hide
};

function distanceAndSkiddingToXY(placement, rects, offset) {
  var basePlacement = getBasePlacement(placement);
  var invertDistance = [left, top].indexOf(basePlacement) >= 0 ? -1 : 1;

  var _ref = typeof offset === 'function' ? offset(Object.assign({}, rects, {
    placement: placement
  })) : offset,
      skidding = _ref[0],
      distance = _ref[1];

  skidding = skidding || 0;
  distance = (distance || 0) * invertDistance;
  return [left, right].indexOf(basePlacement) >= 0 ? {
    x: distance,
    y: skidding
  } : {
    x: skidding,
    y: distance
  };
}

function offset(_ref2) {
  var state = _ref2.state,
      options = _ref2.options,
      name = _ref2.name;
  var _options$offset = options.offset,
      offset = _options$offset === void 0 ? [0, 0] : _options$offset;
  var data = placements.reduce(function (acc, placement) {
    acc[placement] = distanceAndSkiddingToXY(placement, state.rects, offset);
    return acc;
  }, {});
  var _data$state$placement = data[state.placement],
      x = _data$state$placement.x,
      y = _data$state$placement.y;

  if (state.modifiersData.popperOffsets != null) {
    state.modifiersData.popperOffsets.x += x;
    state.modifiersData.popperOffsets.y += y;
  }

  state.modifiersData[name] = data;
} // eslint-disable-next-line import/no-unused-modules


var offset$1 = {
  name: 'offset',
  enabled: true,
  phase: 'main',
  requires: ['popperOffsets'],
  fn: offset
};

function popperOffsets(_ref) {
  var state = _ref.state,
      name = _ref.name;
  // Offsets are the actual position the popper needs to have to be
  // properly positioned near its reference element
  // This is the most basic placement, and will be adjusted by
  // the modifiers in the next step
  state.modifiersData[name] = computeOffsets({
    reference: state.rects.reference,
    element: state.rects.popper,
    strategy: 'absolute',
    placement: state.placement
  });
} // eslint-disable-next-line import/no-unused-modules


var popperOffsets$1 = {
  name: 'popperOffsets',
  enabled: true,
  phase: 'read',
  fn: popperOffsets,
  data: {}
};

function getAltAxis(axis) {
  return axis === 'x' ? 'y' : 'x';
}

function preventOverflow(_ref) {
  var state = _ref.state,
      options = _ref.options,
      name = _ref.name;
  var _options$mainAxis = options.mainAxis,
      checkMainAxis = _options$mainAxis === void 0 ? true : _options$mainAxis,
      _options$altAxis = options.altAxis,
      checkAltAxis = _options$altAxis === void 0 ? false : _options$altAxis,
      boundary = options.boundary,
      rootBoundary = options.rootBoundary,
      altBoundary = options.altBoundary,
      padding = options.padding,
      _options$tether = options.tether,
      tether = _options$tether === void 0 ? true : _options$tether,
      _options$tetherOffset = options.tetherOffset,
      tetherOffset = _options$tetherOffset === void 0 ? 0 : _options$tetherOffset;
  var overflow = detectOverflow(state, {
    boundary: boundary,
    rootBoundary: rootBoundary,
    padding: padding,
    altBoundary: altBoundary
  });
  var basePlacement = getBasePlacement(state.placement);
  var variation = getVariation(state.placement);
  var isBasePlacement = !variation;
  var mainAxis = getMainAxisFromPlacement(basePlacement);
  var altAxis = getAltAxis(mainAxis);
  var popperOffsets = state.modifiersData.popperOffsets;
  var referenceRect = state.rects.reference;
  var popperRect = state.rects.popper;
  var tetherOffsetValue = typeof tetherOffset === 'function' ? tetherOffset(Object.assign({}, state.rects, {
    placement: state.placement
  })) : tetherOffset;
  var normalizedTetherOffsetValue = typeof tetherOffsetValue === 'number' ? {
    mainAxis: tetherOffsetValue,
    altAxis: tetherOffsetValue
  } : Object.assign({
    mainAxis: 0,
    altAxis: 0
  }, tetherOffsetValue);
  var offsetModifierState = state.modifiersData.offset ? state.modifiersData.offset[state.placement] : null;
  var data = {
    x: 0,
    y: 0
  };

  if (!popperOffsets) {
    return;
  }

  if (checkMainAxis) {
    var _offsetModifierState$;

    var mainSide = mainAxis === 'y' ? top : left;
    var altSide = mainAxis === 'y' ? bottom : right;
    var len = mainAxis === 'y' ? 'height' : 'width';
    var offset = popperOffsets[mainAxis];
    var min$1 = offset + overflow[mainSide];
    var max$1 = offset - overflow[altSide];
    var additive = tether ? -popperRect[len] / 2 : 0;
    var minLen = variation === start ? referenceRect[len] : popperRect[len];
    var maxLen = variation === start ? -popperRect[len] : -referenceRect[len]; // We need to include the arrow in the calculation so the arrow doesn't go
    // outside the reference bounds

    var arrowElement = state.elements.arrow;
    var arrowRect = tether && arrowElement ? getLayoutRect(arrowElement) : {
      width: 0,
      height: 0
    };
    var arrowPaddingObject = state.modifiersData['arrow#persistent'] ? state.modifiersData['arrow#persistent'].padding : getFreshSideObject();
    var arrowPaddingMin = arrowPaddingObject[mainSide];
    var arrowPaddingMax = arrowPaddingObject[altSide]; // If the reference length is smaller than the arrow length, we don't want
    // to include its full size in the calculation. If the reference is small
    // and near the edge of a boundary, the popper can overflow even if the
    // reference is not overflowing as well (e.g. virtual elements with no
    // width or height)

    var arrowLen = within(0, referenceRect[len], arrowRect[len]);
    var minOffset = isBasePlacement ? referenceRect[len] / 2 - additive - arrowLen - arrowPaddingMin - normalizedTetherOffsetValue.mainAxis : minLen - arrowLen - arrowPaddingMin - normalizedTetherOffsetValue.mainAxis;
    var maxOffset = isBasePlacement ? -referenceRect[len] / 2 + additive + arrowLen + arrowPaddingMax + normalizedTetherOffsetValue.mainAxis : maxLen + arrowLen + arrowPaddingMax + normalizedTetherOffsetValue.mainAxis;
    var arrowOffsetParent = state.elements.arrow && getOffsetParent(state.elements.arrow);
    var clientOffset = arrowOffsetParent ? mainAxis === 'y' ? arrowOffsetParent.clientTop || 0 : arrowOffsetParent.clientLeft || 0 : 0;
    var offsetModifierValue = (_offsetModifierState$ = offsetModifierState == null ? void 0 : offsetModifierState[mainAxis]) != null ? _offsetModifierState$ : 0;
    var tetherMin = offset + minOffset - offsetModifierValue - clientOffset;
    var tetherMax = offset + maxOffset - offsetModifierValue;
    var preventedOffset = within(tether ? min(min$1, tetherMin) : min$1, offset, tether ? max(max$1, tetherMax) : max$1);
    popperOffsets[mainAxis] = preventedOffset;
    data[mainAxis] = preventedOffset - offset;
  }

  if (checkAltAxis) {
    var _offsetModifierState$2;

    var _mainSide = mainAxis === 'x' ? top : left;

    var _altSide = mainAxis === 'x' ? bottom : right;

    var _offset = popperOffsets[altAxis];

    var _len = altAxis === 'y' ? 'height' : 'width';

    var _min = _offset + overflow[_mainSide];

    var _max = _offset - overflow[_altSide];

    var isOriginSide = [top, left].indexOf(basePlacement) !== -1;

    var _offsetModifierValue = (_offsetModifierState$2 = offsetModifierState == null ? void 0 : offsetModifierState[altAxis]) != null ? _offsetModifierState$2 : 0;

    var _tetherMin = isOriginSide ? _min : _offset - referenceRect[_len] - popperRect[_len] - _offsetModifierValue + normalizedTetherOffsetValue.altAxis;

    var _tetherMax = isOriginSide ? _offset + referenceRect[_len] + popperRect[_len] - _offsetModifierValue - normalizedTetherOffsetValue.altAxis : _max;

    var _preventedOffset = tether && isOriginSide ? withinMaxClamp(_tetherMin, _offset, _tetherMax) : within(tether ? _tetherMin : _min, _offset, tether ? _tetherMax : _max);

    popperOffsets[altAxis] = _preventedOffset;
    data[altAxis] = _preventedOffset - _offset;
  }

  state.modifiersData[name] = data;
} // eslint-disable-next-line import/no-unused-modules


var preventOverflow$1 = {
  name: 'preventOverflow',
  enabled: true,
  phase: 'main',
  fn: preventOverflow,
  requiresIfExists: ['offset']
};

function getHTMLElementScroll(element) {
  return {
    scrollLeft: element.scrollLeft,
    scrollTop: element.scrollTop
  };
}

function getNodeScroll(node) {
  if (node === getWindow(node) || !isHTMLElement(node)) {
    return getWindowScroll(node);
  } else {
    return getHTMLElementScroll(node);
  }
}

function isElementScaled(element) {
  var rect = element.getBoundingClientRect();
  var scaleX = round(rect.width) / element.offsetWidth || 1;
  var scaleY = round(rect.height) / element.offsetHeight || 1;
  return scaleX !== 1 || scaleY !== 1;
} // Returns the composite rect of an element relative to its offsetParent.
// Composite means it takes into account transforms as well as layout.


function getCompositeRect(elementOrVirtualElement, offsetParent, isFixed) {
  if (isFixed === void 0) {
    isFixed = false;
  }

  var isOffsetParentAnElement = isHTMLElement(offsetParent);
  var offsetParentIsScaled = isHTMLElement(offsetParent) && isElementScaled(offsetParent);
  var documentElement = getDocumentElement(offsetParent);
  var rect = getBoundingClientRect(elementOrVirtualElement, offsetParentIsScaled, isFixed);
  var scroll = {
    scrollLeft: 0,
    scrollTop: 0
  };
  var offsets = {
    x: 0,
    y: 0
  };

  if (isOffsetParentAnElement || !isOffsetParentAnElement && !isFixed) {
    if (getNodeName(offsetParent) !== 'body' || // https://github.com/popperjs/popper-core/issues/1078
    isScrollParent(documentElement)) {
      scroll = getNodeScroll(offsetParent);
    }

    if (isHTMLElement(offsetParent)) {
      offsets = getBoundingClientRect(offsetParent, true);
      offsets.x += offsetParent.clientLeft;
      offsets.y += offsetParent.clientTop;
    } else if (documentElement) {
      offsets.x = getWindowScrollBarX(documentElement);
    }
  }

  return {
    x: rect.left + scroll.scrollLeft - offsets.x,
    y: rect.top + scroll.scrollTop - offsets.y,
    width: rect.width,
    height: rect.height
  };
}

function order(modifiers) {
  var map = new Map();
  var visited = new Set();
  var result = [];
  modifiers.forEach(function (modifier) {
    map.set(modifier.name, modifier);
  }); // On visiting object, check for its dependencies and visit them recursively

  function sort(modifier) {
    visited.add(modifier.name);
    var requires = [].concat(modifier.requires || [], modifier.requiresIfExists || []);
    requires.forEach(function (dep) {
      if (!visited.has(dep)) {
        var depModifier = map.get(dep);

        if (depModifier) {
          sort(depModifier);
        }
      }
    });
    result.push(modifier);
  }

  modifiers.forEach(function (modifier) {
    if (!visited.has(modifier.name)) {
      // check for visited object
      sort(modifier);
    }
  });
  return result;
}

function orderModifiers(modifiers) {
  // order based on dependencies
  var orderedModifiers = order(modifiers); // order based on phase

  return modifierPhases.reduce(function (acc, phase) {
    return acc.concat(orderedModifiers.filter(function (modifier) {
      return modifier.phase === phase;
    }));
  }, []);
}

function debounce(fn) {
  var pending;
  return function () {
    if (!pending) {
      pending = new Promise(function (resolve) {
        Promise.resolve().then(function () {
          pending = undefined;
          resolve(fn());
        });
      });
    }

    return pending;
  };
}

function mergeByName(modifiers) {
  var merged = modifiers.reduce(function (merged, current) {
    var existing = merged[current.name];
    merged[current.name] = existing ? Object.assign({}, existing, current, {
      options: Object.assign({}, existing.options, current.options),
      data: Object.assign({}, existing.data, current.data)
    }) : current;
    return merged;
  }, {}); // IE11 does not support Object.values

  return Object.keys(merged).map(function (key) {
    return merged[key];
  });
}

var DEFAULT_OPTIONS = {
  placement: 'bottom',
  modifiers: [],
  strategy: 'absolute'
};

function areValidElements() {
  for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
    args[_key] = arguments[_key];
  }

  return !args.some(function (element) {
    return !(element && typeof element.getBoundingClientRect === 'function');
  });
}

function popperGenerator(generatorOptions) {
  if (generatorOptions === void 0) {
    generatorOptions = {};
  }

  var _generatorOptions = generatorOptions,
      _generatorOptions$def = _generatorOptions.defaultModifiers,
      defaultModifiers = _generatorOptions$def === void 0 ? [] : _generatorOptions$def,
      _generatorOptions$def2 = _generatorOptions.defaultOptions,
      defaultOptions = _generatorOptions$def2 === void 0 ? DEFAULT_OPTIONS : _generatorOptions$def2;
  return function createPopper(reference, popper, options) {
    if (options === void 0) {
      options = defaultOptions;
    }

    var state = {
      placement: 'bottom',
      orderedModifiers: [],
      options: Object.assign({}, DEFAULT_OPTIONS, defaultOptions),
      modifiersData: {},
      elements: {
        reference: reference,
        popper: popper
      },
      attributes: {},
      styles: {}
    };
    var effectCleanupFns = [];
    var isDestroyed = false;
    var instance = {
      state: state,
      setOptions: function setOptions(setOptionsAction) {
        var options = typeof setOptionsAction === 'function' ? setOptionsAction(state.options) : setOptionsAction;
        cleanupModifierEffects();
        state.options = Object.assign({}, defaultOptions, state.options, options);
        state.scrollParents = {
          reference: isElement(reference) ? listScrollParents(reference) : reference.contextElement ? listScrollParents(reference.contextElement) : [],
          popper: listScrollParents(popper)
        }; // Orders the modifiers based on their dependencies and `phase`
        // properties

        var orderedModifiers = orderModifiers(mergeByName([].concat(defaultModifiers, state.options.modifiers))); // Strip out disabled modifiers

        state.orderedModifiers = orderedModifiers.filter(function (m) {
          return m.enabled;
        });
        runModifierEffects();
        return instance.update();
      },
      // Sync update – it will always be executed, even if not necessary. This
      // is useful for low frequency updates where sync behavior simplifies the
      // logic.
      // For high frequency updates (e.g. `resize` and `scroll` events), always
      // prefer the async Popper#update method
      forceUpdate: function forceUpdate() {
        if (isDestroyed) {
          return;
        }

        var _state$elements = state.elements,
            reference = _state$elements.reference,
            popper = _state$elements.popper; // Don't proceed if `reference` or `popper` are not valid elements
        // anymore

        if (!areValidElements(reference, popper)) {
          return;
        } // Store the reference and popper rects to be read by modifiers


        state.rects = {
          reference: getCompositeRect(reference, getOffsetParent(popper), state.options.strategy === 'fixed'),
          popper: getLayoutRect(popper)
        }; // Modifiers have the ability to reset the current update cycle. The
        // most common use case for this is the `flip` modifier changing the
        // placement, which then needs to re-run all the modifiers, because the
        // logic was previously ran for the previous placement and is therefore
        // stale/incorrect

        state.reset = false;
        state.placement = state.options.placement; // On each update cycle, the `modifiersData` property for each modifier
        // is filled with the initial data specified by the modifier. This means
        // it doesn't persist and is fresh on each update.
        // To ensure persistent data, use `${name}#persistent`

        state.orderedModifiers.forEach(function (modifier) {
          return state.modifiersData[modifier.name] = Object.assign({}, modifier.data);
        });

        for (var index = 0; index < state.orderedModifiers.length; index++) {
          if (state.reset === true) {
            state.reset = false;
            index = -1;
            continue;
          }

          var _state$orderedModifie = state.orderedModifiers[index],
              fn = _state$orderedModifie.fn,
              _state$orderedModifie2 = _state$orderedModifie.options,
              _options = _state$orderedModifie2 === void 0 ? {} : _state$orderedModifie2,
              name = _state$orderedModifie.name;

          if (typeof fn === 'function') {
            state = fn({
              state: state,
              options: _options,
              name: name,
              instance: instance
            }) || state;
          }
        }
      },
      // Async and optimistically optimized update – it will not be executed if
      // not necessary (debounced to run at most once-per-tick)
      update: debounce(function () {
        return new Promise(function (resolve) {
          instance.forceUpdate();
          resolve(state);
        });
      }),
      destroy: function destroy() {
        cleanupModifierEffects();
        isDestroyed = true;
      }
    };

    if (!areValidElements(reference, popper)) {
      return instance;
    }

    instance.setOptions(options).then(function (state) {
      if (!isDestroyed && options.onFirstUpdate) {
        options.onFirstUpdate(state);
      }
    }); // Modifiers have the ability to execute arbitrary code before the first
    // update cycle runs. They will be executed in the same order as the update
    // cycle. This is useful when a modifier adds some persistent data that
    // other modifiers need to use, but the modifier is run after the dependent
    // one.

    function runModifierEffects() {
      state.orderedModifiers.forEach(function (_ref) {
        var name = _ref.name,
            _ref$options = _ref.options,
            options = _ref$options === void 0 ? {} : _ref$options,
            effect = _ref.effect;

        if (typeof effect === 'function') {
          var cleanupFn = effect({
            state: state,
            name: name,
            instance: instance,
            options: options
          });

          var noopFn = function noopFn() {};

          effectCleanupFns.push(cleanupFn || noopFn);
        }
      });
    }

    function cleanupModifierEffects() {
      effectCleanupFns.forEach(function (fn) {
        return fn();
      });
      effectCleanupFns = [];
    }

    return instance;
  };
}

var defaultModifiers = [eventListeners, popperOffsets$1, computeStyles$1, applyStyles$1, offset$1, flip$1, preventOverflow$1, arrow$1, hide$1];
var createPopper = /*#__PURE__*/popperGenerator({
  defaultModifiers: defaultModifiers
}); // eslint-disable-next-line import/no-unused-modules

function styleInject(css, ref) {
  if ( ref === void 0 ) ref = {};
  var insertAt = ref.insertAt;

  if (!css || typeof document === 'undefined') { return; }

  var head = document.head || document.getElementsByTagName('head')[0];
  var style = document.createElement('style');
  style.type = 'text/css';

  if (insertAt === 'top') {
    if (head.firstChild) {
      head.insertBefore(style, head.firstChild);
    } else {
      head.appendChild(style);
    }
  } else {
    head.appendChild(style);
  }

  if (style.styleSheet) {
    style.styleSheet.cssText = css;
  } else {
    style.appendChild(document.createTextNode(css));
  }
}

var css_248z$1 = ".basicui-select__ul {\n    list-style: none;\n    margin: 0px;\n    padding: 8px 0px;\n    max-height: 250px;\n    overflow: hidden auto;\n    /* border: 1px solid rgba(0, 0, 0, 0.175); */\n    border-radius: 4px;\n}\n\n.basicui-select__ul {\n    background-color: var(--basicui-bg-accent);\n    color: var(--basicui-fg);\n}\n\n.basicui-select__ul__search {\n    padding: 0 6px 6px 6px;\n}\n\n.basicui-select__ul__search input {\n    width: 100%;\n}\n\n.basicui-select__ul__li {\n    /* border-bottom: 1px solid #00000020; */\n}\n\n.basicui-select__ul__li:last-child {\n    border-bottom: none;\n}\n\n.basicui-select__ul__li__link {\n    width: 100%;\n    padding: 6px 6px;\n    font-size: var(--basicui-formelement-font-size);\n    font-weight: var(--basicui-formelement-font-weight);\n    text-align: left;\n    background-color: transparent;\n    color: var(--theme-black-900);\n    display: grid;\n    grid-template-columns: auto 1fr;\n    column-gap: 8px;\n    justify-items: flex-start;\n    align-items: center;\n    border: none;\n    box-shadow: none;\n    line-height: 1.5;\n    transition: 250ms background-color ease-in-out, 250ms color ease-in-out;\n}\n\n.basicui-dark .basicui-select__ul__li__link {\n    color: var(--theme-white-50);\n}\n\n.basicui-select__ul__li__indicator {\n    width: 16px;\n}\n\n.basicui-select__ul__li__indicator div {\n    display: flex;\n}\n\n.basicui-select__ul__li__indicator svg {\n    fill: var(--theme-black-900);\n}\n\n.basicui-dark .basicui-select__ul__li__indicator svg {\n    fill: var(--theme-white-50);\n}\n\n.basicui-select__ul__li__link--active,\n.basicui-select__ul__li__link:hover {\n    background-color: var(--basicui-bg-default-transparent);\n    /* color: var(--theme-primary-transparent-50i); */\n}\n\n/* .basicui-dark .basicui-select__ul__li__link--active,\n.basicui-dark .basicui-select__ul__li__link:hover {\n    background-color: var(--basicui-bg-default);\n    color: var(--basicui-fg-default);\n} */\n";
styleInject(css_248z$1);

var OptionsList = function (props) {
    var _a;
    var _b = useState(0), currentIndex = _b[0], setCurrentIndex = _b[1];
    var currentIndexRef = useRef(0);
    var searchReferenceElement = useRef(null);
    var optionsRef = useRef([]);
    useEffect(function () {
        setCurrentIndex(0);
        currentIndexRef.current = 0;
        optionsRef.current = props.options;
    }, [props.options]);
    useEffect(function () {
        if (props.referenceElement.current) {
            props.referenceElement.current.addEventListener('keydown', keydownEventHandler);
        }
        // if (props.popperElement.current) {
        //     props.popperElement.current.addEventListener('keydown', keydownEventHandler);
        // }
        return function () {
            if (props.referenceElement.current) {
                props.referenceElement.current.removeEventListener('keydown', keydownEventHandler);
            }
        };
    }, [props.referenceElement]);
    useEffect(function () {
        if (searchReferenceElement.current) {
            searchReferenceElement.current.addEventListener('keydown', keydownEventHandler);
        }
        // if (props.popperElement.current) {
        //     props.popperElement.current.addEventListener('keydown', keydownEventHandler);
        // }
        return function () {
            if (searchReferenceElement.current) {
                searchReferenceElement.current.removeEventListener('keydown', keydownEventHandler);
            }
        };
    }, [searchReferenceElement]);
    var keydownEventHandler = function (event) {
        switch (event.key) {
            case 'ArrowDown':
                event.preventDefault();
                navigateDown();
                break;
            case 'ArrowUp':
                event.preventDefault();
                navigateUp();
                break;
            case 'Enter':
                event.preventDefault();
                props.handleChange(event, currentIndexRef.current, optionsRef.current[currentIndexRef.current].value);
                break;
            case 'Tab':
                event.preventDefault();
                break;
            case 'Escape':
                event.preventDefault();
                props.handleClose();
                break;
        }
    };
    var navigateUp = function () {
        var _current = 0;
        if (currentIndexRef.current !== 0) {
            _current = currentIndexRef.current - 1;
        }
        else {
            optionsRef.current.length - 1;
        }
        currentIndexRef.current = _current;
        setCurrentIndex(_current);
    };
    var navigateDown = function () {
        var _current = 0;
        if (currentIndexRef.current < optionsRef.current.length - 1) {
            _current = currentIndexRef.current + 1;
        }
        currentIndexRef.current = _current;
        setCurrentIndex(_current);
    };
    var handleClick = function (event, index, option) {
        props.handleChange(event, index, option);
    };
    var handleSearchTextChange = function (event) {
        if (props.handleSearchTextChange) {
            props.handleSearchTextChange(event.target.value);
        }
    };
    return React.createElement("div", null,
        React.createElement("ul", { role: "listbox", className: "basicui-select__ul basicui-popup" },
            props.handleSearchTextChange && React.createElement("div", { className: "basicui-select__ul__search" },
                React.createElement("input", { ref: searchReferenceElement, className: "basicui-input", autoFocus: true, onInput: handleSearchTextChange, autoComplete: "none" })), (_a = props.options) === null || _a === void 0 ? void 0 :
            _a.map(function (option, index) { return (React.createElement("li", { key: index, role: "option", className: "basicui-select__ul__li" },
                React.createElement("button", { className: "basicui-select__ul__li__link ".concat(currentIndex === index ? 'basicui-select__ul__li__link--active' : ''), onClick: function (event) { return handleClick(event, index, option.value); } },
                    React.createElement("div", { className: "basicui-select__ul__li__indicator" }, props.value.includes(option.value + "") && React.createElement("div", null,
                        React.createElement("svg", { height: "16", viewBox: "0 0 16 16", version: "1.1", width: "16", "aria-hidden": "true" },
                            React.createElement("path", { fillRule: "evenodd", d: "M13.78 4.22a.75.75 0 010 1.06l-7.25 7.25a.75.75 0 01-1.06 0L2.22 9.28a.75.75 0 011.06-1.06L6 10.94l6.72-6.72a.75.75 0 011.06 0z" })))),
                    React.createElement("div", { className: "basicui-select__ul__li__text" }, option.label)))); })));
};

function isEmptyOrSpaces(str) {
    if (typeof str === 'number') {
        return !str || str === 0;
    }
    return !str || str.match(/^ *$/) !== null;
}

var css_248z = "";
styleInject(css_248z);

/**
 * FormElementMessage component
 */
var FormElementMessage = function (props) {
    return (React.createElement("div", { className: "basicui-form-element-".concat(props.type) }, props.text));
};

/**
 * Component to render input form element. For using it with standard html input, add css class basicui-input
 */
var Label = function (props) {
    return (React.createElement(React.Fragment, null,
        props.children && !isEmptyOrSpaces(props.children) && React.createElement(FormElementMessage, { text: props.children, type: "label" }),
        props.labelDesc && !isEmptyOrSpaces(props.labelDesc) && React.createElement(FormElementMessage, { text: props.labelDesc, type: "labeldesc" })));
};

/**
 * Component to render drop down input form element. Supports multi select and auto complete features
 */
var Select$1 = function (props) {
    var valueRef = useRef([]);
    var _a = useState([]), valuesText = _a[0], setValuesText = _a[1];
    var _b = useState(false), isVisible = _b[0], setIsVisible = _b[1];
    var referenceElement = useRef(null);
    var popperElement = useRef(null);
    var _c = useState(''), searchText = _c[0], setSearchText = _c[1];
    var _d = useState([]), options = _d[0], setOptions = _d[1];
    useEffect(function () {
        valueRef.current = props.value || [];
    }, [props.value]);
    useEffect(function () {
        if (!isVisible) {
            setSearchText("");
        }
    }, [isVisible]);
    useEffect(function () {
        var _searchText = searchText.toLowerCase();
        if (isEmptyOrSpaces(_searchText)) {
            setOptions(props.options);
        }
        else {
            var _options = props.options.filter(function (item) { return (item.value + "").toLowerCase().includes(_searchText); });
            if (props.allowNewValues && !_options.find(function (item) { return item.value === _searchText; })) {
                _options.unshift({ value: searchText, label: searchText });
            }
            setOptions(_options);
        }
    }, [searchText, props.options]);
    useEffect(function () {
        var _optionsAsMap = {};
        props.options.forEach(function (item) { return (_optionsAsMap[item.value] = item.label); });
        var _valuesText = [];
        props.value.forEach(function (item) { return _valuesText.push(_optionsAsMap[item] || item); });
        setValuesText(_valuesText);
    }, [props.value]);
    useEffect(function () {
        // listen for clicks and close select on body
        document.addEventListener("mousedown", handleDocumentClick);
        return function () {
            document.removeEventListener("mousedown", handleDocumentClick);
        };
    }, []);
    useEffect(function () {
        if (referenceElement.current && popperElement.current) {
            createPopper(referenceElement.current, popperElement.current, {
                placement: 'bottom-start',
                modifiers: [preventOverflow$1, flip$1,
                    {
                        name: 'offset',
                        options: {
                            offset: [0, 6],
                        },
                    }
                ],
            });
        }
    }, [referenceElement, popperElement]);
    var handleDocumentClick = function (event) {
        var _a, _b;
        if (((_a = referenceElement.current) === null || _a === void 0 ? void 0 : _a.contains(event.target)) || ((_b = popperElement.current) === null || _b === void 0 ? void 0 : _b.contains(event.target))) {
            return;
        }
        setIsVisible(false);
    };
    var handleSelectClick = function (event) {
        setIsVisible(!isVisible);
    };
    var handleChange = function (event, index, option) {
        var _value = __spreadArray([], valueRef.current, true);
        if (!props.multiple && _value.includes(option)) {
            _value = [];
        }
        else if (!props.multiple && !_value.includes(option)) {
            _value = [option];
        }
        else if (_value.includes(option)) {
            _value = _value.filter(function (item) { return item !== option; });
        }
        else {
            _value = __spreadArray(__spreadArray([], _value, true), [option], false);
        }
        var _event = {
            preventDefault: event.preventDefault,
            currentTarget: {
                values: _value,
                value: _value,
                name: props.name
            }
        };
        if (!props.multiple) {
            _event.currentTarget.value = _value.length > 0 ? _value[0] : null;
        }
        if (props.onChange) {
            props.onChange(_event);
        }
        if (props.onInput) {
            props.onInput(_event);
        }
        if (!props.multiple) {
            setIsVisible(false);
        }
    };
    var handleSearchTextChange = function (_searchText) {
        setSearchText(_searchText);
    };
    return (React.createElement("div", { className: ["basicui-select"].join(" ") },
        props.label && React.createElement(Label, { labelDesc: props.labelDesc }, props.label),
        React.createElement("button", { className: "basicui-input basicui-select__button", type: "button", ref: referenceElement, onClick: handleSelectClick }, valuesText.join(', ') || props.placeholder || "-"),
        React.createElement("div", { ref: popperElement, className: "basicui-select__popper" }, isVisible && React.createElement(OptionsList, { value: props.value, options: options, referenceElement: referenceElement, handleChange: handleChange, handleClose: function () { return setIsVisible(false); }, handleSearchTextChange: props.autocomplete ? handleSearchTextChange : null }))));
};

/**
 * Component to render input form element. For using it with standard html input, add css class basicui-input
 */
var Input = function (_a) {
    var id = _a.id, type = _a.type, label = _a.label, labelDesc = _a.labelDesc, value = _a.value, placeholder = _a.placeholder, tooltip = _a.tooltip, errorMessage = _a.errorMessage, warningMessage = _a.warningMessage, successMessage = _a.successMessage, className = _a.className, wrapperClassName = _a.wrapperClassName, restProps = __rest(_a, ["id", "type", "label", "labelDesc", "value", "placeholder", "tooltip", "errorMessage", "warningMessage", "successMessage", "className", "wrapperClassName"]);
    return (React.createElement("div", { className: "basicui-input-el ".concat(wrapperClassName || "") },
        label && React.createElement(Label, { labelDesc: labelDesc }, label),
        React.createElement("input", __assign({ id: id, className: "basicui-input ".concat(className || "", " ").concat(errorMessage ? "basicui-input--error" : "", " ").concat(warningMessage ? "basicui-input--warning" : "", " ").concat(successMessage ? "basicui-input--success" : ""), value: value, type: type, placeholder: placeholder, autoComplete: "off" }, restProps)),
        tooltip && React.createElement(FormElementMessage, { text: tooltip, type: "info" }),
        errorMessage && React.createElement(FormElementMessage, { text: errorMessage, type: "error" }),
        warningMessage && React.createElement(FormElementMessage, { text: warningMessage, type: "warning" }),
        successMessage && React.createElement(FormElementMessage, { text: successMessage, type: "success" })));
};

var ButtonVariantType;
(function (ButtonVariantType) {
    ButtonVariantType["default"] = "default";
    ButtonVariantType["outline"] = "outline";
    ButtonVariantType["fill"] = "fill";
    ButtonVariantType["chroma"] = "chroma";
    ButtonVariantType["transparent"] = "transparent";
})(ButtonVariantType || (ButtonVariantType = {}));
var ButtonVariantType$1 = ButtonVariantType;

var ThemeType;
(function (ThemeType) {
    ThemeType["default"] = "default";
    ThemeType["primary"] = "primary";
    ThemeType["secondary"] = "secondary";
    ThemeType["success"] = "success";
    ThemeType["warning"] = "warning";
    ThemeType["danger"] = "danger";
})(ThemeType || (ThemeType = {}));
var ThemeType$1 = ThemeType;

/**
 * Component to render drop down input form element. Supports multi select and auto complete features
 */
var Button = function (_a) {
    var type = _a.type, theme = _a.theme, variant = _a.variant, loading = _a.loading, children = _a.children, disabled = _a.disabled, className = _a.className, restProps = __rest(_a, ["type", "theme", "variant", "loading", "children", "disabled", "className"]);
    return (React.createElement("button", __assign({ className: "".concat(className || "", " basicui-button basicui-button--theme-").concat(theme || ThemeType$1.default, " ").concat(loading ? "basicui-button--loading" : "", " basicui-button--variant-").concat(variant || ButtonVariantType$1.default), type: type || "button", disabled: disabled || loading }, restProps),
        loading && (React.createElement("svg", { className: "basicui-button__svg--loading", xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 512 512" },
            React.createElement("path", { d: "M304 48a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zm0 416a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zM48 304a48 48 0 1 0 0-96 48 48 0 1 0 0 96zm464-48a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zM142.9 437A48 48 0 1 0 75 369.1 48 48 0 1 0 142.9 437zm0-294.2A48 48 0 1 0 75 75a48 48 0 1 0 67.9 67.9zM369.1 437A48 48 0 1 0 437 369.1 48 48 0 1 0 369.1 437z" }))),
        children));
};

/**
 * Component to render drop down input form element. Supports multi select and auto complete features
 */
var IconButton = forwardRef(function (_a, ref) {
    var type = _a.type, theme = _a.theme, variant = _a.variant, loading = _a.loading, circle = _a.circle, children = _a.children, className = _a.className, restProps = __rest(_a, ["type", "theme", "variant", "loading", "circle", "children", "className"]);
    return (React.createElement("button", __assign({ ref: ref, className: "".concat(className || "", " basicui-button basicui-icon-button ").concat(circle ? "basicui-icon-button--circle" : "", " basicui-button--theme-").concat(theme || ThemeType$1.default, " basicui-button--variant-").concat(variant || ButtonVariantType$1.default, " ").concat(loading ? "basicui-button--loading" : ""), type: type || "button" }, restProps),
        loading && (React.createElement("svg", { className: "basicui-button__svg--loading", xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 512 512" },
            React.createElement("path", { d: "M304 48a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zm0 416a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zM48 304a48 48 0 1 0 0-96 48 48 0 1 0 0 96zm464-48a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zM142.9 437A48 48 0 1 0 75 369.1 48 48 0 1 0 142.9 437zm0-294.2A48 48 0 1 0 75 75a48 48 0 1 0 67.9 67.9zM369.1 437A48 48 0 1 0 437 369.1 48 48 0 1 0 369.1 437z" }))),
        !loading && children));
});

/**
 * Component to render drop down input form element. Supports multi select and auto complete features
 */
var Link = function (_a) {
    var href = _a.href, children = _a.children, label = _a.label, noGlow = _a.noGlow, noUnderline = _a.noUnderline, theme = _a.theme, className = _a.className, restProps = __rest(_a, ["href", "children", "label", "noGlow", "noUnderline", "theme", "className"]);
    return (React.createElement("a", __assign({ href: href }, restProps, { className: "".concat(className || '', " basicui-link basicui-link--theme-").concat(theme || ThemeType$1.default, " ").concat(noUnderline ? "basicui-link--no-underline" : "", " ").concat(noGlow ? "basicui-link--no-glow" : "") }),
        children,
        React.createElement("span", null, label)));
};

/**
 * Component to render input form element. For using it with standard html input, add css class basicui-input
 */
var Textarea = function (_a) {
    var value = _a.value, label = _a.label, labelDesc = _a.labelDesc, tooltip = _a.tooltip, errorMessage = _a.errorMessage, successMessage = _a.successMessage, warningMessage = _a.warningMessage, restProps = __rest(_a, ["value", "label", "labelDesc", "tooltip", "errorMessage", "successMessage", "warningMessage"]);
    return (React.createElement("div", { className: ["basicui-textarea"].join(" ") },
        label && React.createElement(Label, { labelDesc: labelDesc }, label),
        React.createElement("textarea", __assign({ className: "basicui-input", value: value, autoComplete: "none" }, restProps)),
        tooltip && React.createElement(FormElementMessage, { text: tooltip, type: "info" }),
        errorMessage && React.createElement(FormElementMessage, { text: errorMessage, type: "error" }),
        warningMessage && React.createElement(FormElementMessage, { text: warningMessage, type: "warning" }),
        successMessage && React.createElement(FormElementMessage, { text: successMessage, type: "success" })));
};

/**
 * Component to render input form element. For using it with standard html input, add css class basicui-input
 */
var SelectNative = function (_a) {
    var id = _a.id, label = _a.label, labelDesc = _a.labelDesc; _a.placeholder; var initialValues = _a.initialValues, options = _a.options, tooltip = _a.tooltip, errorMessage = _a.errorMessage, warningMessage = _a.warningMessage, successMessage = _a.successMessage, multiple = _a.multiple; _a.autocomplete; var restProps = __rest(_a, ["id", "label", "labelDesc", "placeholder", "initialValues", "options", "tooltip", "errorMessage", "warningMessage", "successMessage", "multiple", "autocomplete"]);
    var _b = useState([]), values = _b[0], setValues = _b[1];
    useEffect(function () {
        if (values.length === 0 && initialValues && initialValues.length > 0) {
            setValues(initialValues);
        }
    }, [initialValues]);
    return (React.createElement("div", { className: ["basicui-selectnative"].join(" ") },
        label && React.createElement(Label, { labelDesc: labelDesc }, label),
        React.createElement("select", __assign({ id: id, className: "basicui-input basicui-selectnative ".concat(multiple ? 'basicui-selectnative--multiple' : '') }, restProps, { multiple: multiple, size: multiple ? 5 : 1 }), options.map(function (option) {
            return React.createElement("option", { selected: values.includes(option.value), className: "basicui-selectnative__option" }, option.label);
        })),
        tooltip && React.createElement(FormElementMessage, { text: tooltip, type: "info" }),
        errorMessage && React.createElement(FormElementMessage, { text: errorMessage, type: "error" }),
        warningMessage && React.createElement(FormElementMessage, { text: warningMessage, type: "warning" }),
        successMessage && React.createElement(FormElementMessage, { text: successMessage, type: "success" })));
};

/**
 * Component to render radio form element. For using it with standard html input, add css class basicui-input
 */
var Radio = function (_a) {
    _a.id; var theme = _a.theme, label = _a.label, checked = _a.checked, restProps = __rest(_a, ["id", "theme", "label", "checked"]);
    return (React.createElement("label", { className: "basicui-radio ".concat(checked ? "basicui-radio--checked" : "", " basicui-radio--theme-").concat(theme || ThemeType$1.default) },
        React.createElement("input", __assign({ className: "basicui-radio__input", type: "radio", checked: checked }, restProps)),
        label && React.createElement("span", { className: "basicui-radio__span" }, label)));
};

/**
 * Component to render checkbox form element. For using it with standard html input, add css class basicui-input
 */
var Checkbox = function (_a) {
    var id = _a.id, label = _a.label, theme = _a.theme, checked = _a.checked, circle = _a.circle, restProps = __rest(_a, ["id", "label", "theme", "checked", "circle"]);
    return (React.createElement("label", { className: "basicui-checkbox ".concat(checked ? "basicui-checkbox--checked" : "", " basicui-checkbox--theme-").concat(theme || ThemeType$1.default), htmlFor: id },
        React.createElement("input", __assign({ className: "basicui-checkbox__input".concat(circle ? " basicui-checkbox__input--circle" : ""), id: id, checked: checked, type: "checkbox" }, restProps)),
        label && React.createElement("span", { className: "basicui-checkbox__span" }, label)));
};

var TabShapeType;
(function (TabShapeType) {
    TabShapeType["default"] = "default";
    TabShapeType["round"] = "round";
    TabShapeType["rectangle"] = "rectangle";
})(TabShapeType || (TabShapeType = {}));
var TabShapeType$1 = TabShapeType;

/**
 * Component to render tab surface
 */
var Tabs = function (props) {
    var _a = useState([]), tabHeaders = _a[0], setTabHeaders = _a[1];
    var _b = useState({}), tabMap = _b[0], setTabMap = _b[1];
    useEffect(function () {
        var _tabMap = {};
        var _tabHeaders = [];
        props.children.forEach(function (tab) {
            var _a;
            _tabMap[tab.props.id] = tab;
            (_a = tab.props.children) === null || _a === void 0 ? void 0 : _a.forEach(function (item) {
                if (item.type.displayName === "TabHeader" || item.type.name === "TabHeader") {
                    _tabHeaders.push({ id: tab.props.id, component: item });
                }
            });
        });
        setTabMap(_tabMap);
        setTabHeaders(_tabHeaders);
    }, [props.children]);
    var handleClick = function (tabId) {
        props.onChange(tabId);
    };
    return (React.createElement("div", { className: "basicui-tabs ".concat(props.offset ? "basicui-tabs--offset" : "", " basicui-tabs--theme-").concat(props.theme || ThemeType$1.default, " basicui-tabs--shape-").concat(props.shape || TabShapeType$1.default) },
        React.createElement("ul", { className: "basicui-tabs__ul" }, tabHeaders.map(function (tab) {
            return React.createElement("li", { key: tab.id, className: "basicui-tabs__ul__li ".concat(props.activeTabId === tab.id ? "basicui-tabs__ul__li--active" : "", " ") },
                React.createElement("button", { className: "basicui-tabs__ul__li__button", onClick: function () { return handleClick(tab.id); } }, tab.component));
        })),
        React.createElement("div", null, tabMap[props.activeTabId])));
};

/**
 * Component to render drop down input form element. Supports multi select and auto complete features
 */
var Tab = function (props) {
    var _a = useState(), tabDetail = _a[0], setTabDetail = _a[1];
    useEffect(function () {
        props.children.forEach(function (item) {
            if (item.type.displayName === "TabDetail" || item.type.name === "TabDetail") {
                setTabDetail(item);
            }
        });
    }, [props.children]);
    return (React.createElement("div", { className: "basicui-tab" }, tabDetail));
};

var TabHeaderAlignmentType;
(function (TabHeaderAlignmentType) {
    TabHeaderAlignmentType["default"] = "default";
    TabHeaderAlignmentType["column"] = "column";
})(TabHeaderAlignmentType || (TabHeaderAlignmentType = {}));
var TabHeaderAlignmentType$1 = TabHeaderAlignmentType;

/**
 * Component to render Header link for the tab
 */
var TabHeader = function (props) {
    useRef(null);
    return (React.createElement("div", { className: "basicui-tab-header basicui-tab-header--alignment-".concat(props.alignment || TabHeaderAlignmentType$1.default) }, props.children));
};

/**
 * Component to render details for the tab
 */
var TabDetail = function (props) {
    useRef(null);
    return (React.createElement("div", { className: "basicui-tab-detail" }, props.children));
};

// Default props value.
var defaultPortalProps = {
    wrapperId: "basicui-portal"
};
// Render component.
var Portal = function (_a) {
    var children = _a.children, wrapperId = _a.wrapperId;
    // Manage state of portal-wrapper.
    var _b = useState(null), wrapper = _b[0], setWrapper = _b[1];
    useLayoutEffect(function () {
        // Find the container-element (if exist).       
        var element = document.getElementById(wrapperId);
        // Bool flag whether container-element has been created.       
        var created = false;
        if (!element) {
            created = true;
            var wrapper_1 = document.createElement('div');
            wrapper_1.setAttribute("id", wrapperId);
            document.body.appendChild(wrapper_1);
            element = wrapper_1;
        }
        // Set wrapper state.
        setWrapper(element);
        // Cleanup effect.
        return function () {
            if (created && (element === null || element === void 0 ? void 0 : element.parentNode)) {
                element.parentNode.removeChild(element);
            }
        };
    }, [wrapperId]);
    // Return null on initial rendering.
    if (wrapper === null)
        return null;
    // Return portal-wrapper component.
    return createPortal(children, wrapper);
};
Portal.defaultProps = defaultPortalProps;

var Modal = function (props) {
    var _a = useState(props.isOpen), shouldRender = _a[0], setShouldRender = _a[1];
    var _b = useState(false), isClosing = _b[0], setIsClosing = _b[1];
    useEffect(function () {
        var handleKeyDown = function (event) {
            if (event.key === 'Escape') {
                props.onClose();
            }
        };
        if (props.isOpen) {
            document.addEventListener('keydown', handleKeyDown);
        }
        return function () {
            document.removeEventListener('keydown', handleKeyDown);
        };
    }, [props.isOpen, props.onClose]);
    useEffect(function () {
        if (!props.isOpen) {
            setIsClosing(true);
            var timeoutId_1 = setTimeout(function () {
                setShouldRender(false);
            }, 250);
            return function () { return clearTimeout(timeoutId_1); };
        }
        else {
            setIsClosing(false);
            setShouldRender(true);
        }
    }, [props.isOpen]);
    if (!shouldRender)
        return null;
    var handleOverlayClick = function (e) {
        if (e.target === e.currentTarget) {
            props.onClose();
        }
    };
    return (React.createElement(Portal, { wrapperId: "basicui-modal" },
        React.createElement("div", { className: "basicui-modal ".concat(props.isOpen ? 'basicui-modal--open' : 'basicui-modal--close') },
            React.createElement("div", { className: "basicui-modal__overlay", onClick: handleOverlayClick },
                React.createElement("div", { className: "basicui-modal__base \n                            ".concat(isClosing ? 'basicui-modal__base--closing' : 'basicui-modal__base--opening', "\n                            basicui-modal__base--size-").concat(props.size || "default", " basicui-modal__base--placement-").concat(props.placement || "default") }, props.children)))));
};

var ModalHeader = function (props) {
    return (React.createElement("div", { className: "basicui-modal-header ".concat(props.border ? "basicui-modal-header--show-border" : "") },
        React.createElement("div", { className: "basicui-modal-header__heading" }, props.heading),
        React.createElement("button", { className: "basicui-modal-header__close", onClick: props.onClose },
            React.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 384 512" },
                React.createElement("path", { d: "M342.6 150.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192 210.7 86.6 105.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L146.7 256 41.4 361.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192 301.3 297.4 406.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L237.3 256 342.6 150.6z" })))));
};

var ModalFooter = function (props) {
    return (React.createElement("div", { className: "basicui-modal-footer ".concat(props.border ? "basicui-modal-footer--show-border" : "", " basicui-modal-footer--alignment-").concat(props.alignment || ThemeType$1.default) }, props.children));
};

var ModalBody = function (props) {
    return (React.createElement("div", { className: "basicui-modal-body" }, props.children));
};

function SvgIcon(_a) {
    var _this = this;
    var children = _a.children, src = _a.src, className = _a.className, width = _a.width, height = _a.height, fill = _a.fill;
    var _b = useState(null); _b[0]; var setSvgContent = _b[1];
    var _c = useState(null), updatedSvgContent = _c[0], setUpdatedSvgContent = _c[1];
    useEffect(function () {
        var fetchSVG = function () { return __awaiter(_this, void 0, void 0, function () {
            var response, text, error_1;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 3, , 4]);
                        return [4 /*yield*/, fetch(src || "")];
                    case 1:
                        response = _a.sent();
                        return [4 /*yield*/, response.text()];
                    case 2:
                        text = _a.sent();
                        setSvgContent(text);
                        setUpdatedSvgContent(text.replace(/<svg([^>]+)>/, function (match, group) {
                            var widthAttr = width ? "width=\"".concat(width, "\" ") : '';
                            var heightAttr = height ? "height=\"".concat(height, "\" ") : '';
                            return "<svg ".concat(group, " ").concat(widthAttr).concat(heightAttr, ">");
                        }));
                        return [3 /*break*/, 4];
                    case 3:
                        error_1 = _a.sent();
                        console.error("Failed to fetch SVG:", error_1);
                        return [3 /*break*/, 4];
                    case 4: return [2 /*return*/];
                }
            });
        }); };
        if (src) {
            fetchSVG();
        }
    }, [src, width, height]);
    if (!src && !children)
        return null;
    var wrapperStyle = {
        width: width || "20px",
        height: height || "20px",
        fill: fill || "var(--basicui-fg)",
        // display: 'inline-block' as const,
    };
    var styledChildren = isValidElement(children)
        ? cloneElement(children, {
            style: __assign(__assign({}, children.props.style), { width: width, height: height }),
        })
        : children;
    return (React.createElement(React.Fragment, null,
        children && (React.createElement("div", { className: "basicui-svgicon ".concat(className || ""), style: wrapperStyle }, styledChildren)),
        !children && updatedSvgContent && (React.createElement("div", { className: "basicui-svgicon ".concat(className || ""), style: wrapperStyle, dangerouslySetInnerHTML: { __html: updatedSvgContent } }))));
}

/**
 * Component to render an accordion with optional custom header.
 * Allows parent to fully control expand/collapse behavior.
 */
var Accordion = function (props) {
    var bodyRef = useRef(null);
    var isAnimationCompletedRef = useRef(true);
    var handleChange = function () {
        if (isAnimationCompletedRef.current && props.onChange) {
            props.onChange();
        }
    };
    useEffect(function () {
        updateScrollHeight();
    }, [props.expanded]);
    var updateScrollHeight = function () {
        if (!bodyRef.current)
            return;
        if (props.expanded) {
            bodyRef.current.style.height = bodyRef.current.scrollHeight + 'px';
            bodyRef.current.style.overflowY = 'hidden';
            bodyRef.current.style.visibility = 'visible';
            isAnimationCompletedRef.current = false;
            setTimeout(function () {
                if (bodyRef.current) {
                    bodyRef.current.style.overflowY = 'visible';
                    bodyRef.current.style.height = 'auto';
                }
                isAnimationCompletedRef.current = true;
            }, 300);
        }
        else {
            isAnimationCompletedRef.current = false;
            bodyRef.current.style.height = bodyRef.current.scrollHeight + 'px';
            setTimeout(function () {
                bodyRef.current.style.height = '0px';
            }, 0);
            bodyRef.current.style.overflowY = 'hidden';
            setTimeout(function () {
                if (bodyRef.current) {
                    bodyRef.current.style.visibility = 'hidden';
                }
                isAnimationCompletedRef.current = true;
            }, 300);
        }
    };
    var renderHeader = function () {
        if (props.header) {
            return React.createElement("div", { className: "basicui-accordion__header-custom" }, props.header);
        }
        if (props.heading && props.onChange) {
            return (React.createElement("button", { className: "basicui-accordion__header", onClick: handleChange },
                React.createElement("div", null, props.heading),
                React.createElement(SvgIcon, { className: "basicui-accordion__header__arrow", src: "/icons/fontawesome/down.svg", height: "12px", width: "12px" })));
        }
        return null; // No header
    };
    return (React.createElement("div", { className: "basicui-accordion ".concat(props.expanded ? "accordion-active" : "", " ").concat(props.bordered ? "accordion-bordered" : "", " theme-").concat(props.theme || ThemeType$1.default, " ").concat(props.className || "") },
        renderHeader(),
        React.createElement("div", { className: "basicui-accordion__body", ref: bodyRef },
            React.createElement("div", { className: "basicui-accordion__body__content" }, props.children))));
};

var Popover = function (_a) {
    var visible = _a.visible, anchorRef = _a.anchorRef, onClose = _a.onClose, children = _a.children, _b = _a.placement, placement = _b === void 0 ? "bottom-start" : _b;
    var popperRef = useRef(null);
    var popperInstance = useRef(null);
    useEffect(function () {
        if (anchorRef.current && popperRef.current && visible) {
            popperInstance.current = createPopper(anchorRef.current, popperRef.current, {
                placement: placement,
                modifiers: [
                    preventOverflow$1,
                    flip$1,
                    {
                        name: "offset",
                        options: {
                            offset: [0, 6],
                        },
                    },
                ],
            });
        }
        return function () {
            if (popperInstance.current) {
                popperInstance.current.destroy();
                popperInstance.current = null;
            }
        };
    }, [visible, anchorRef, placement]);
    useEffect(function () {
        console.log(anchorRef.current, popperRef.current);
        var handleClickOutside = function (event) {
            var _a, _b, _c, _d;
            console.log("***clikc outside");
            console.log(anchorRef.current, popperRef.current, event.target, (_a = anchorRef.current) === null || _a === void 0 ? void 0 : _a.contains(event.target), (_b = popperRef.current) === null || _b === void 0 ? void 0 : _b.contains(event.target));
            if (!((_c = anchorRef.current) === null || _c === void 0 ? void 0 : _c.contains(event.target)) &&
                !((_d = popperRef.current) === null || _d === void 0 ? void 0 : _d.contains(event.target))) {
                onClose === null || onClose === void 0 ? void 0 : onClose();
            }
        };
        if (visible) {
            setTimeout(function () {
                document.addEventListener("mousedown", handleClickOutside);
            }, 0);
        }
        return function () {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [visible, anchorRef, onClose]);
    if (!visible)
        return null;
    return (React.createElement("div", { ref: popperRef, className: "popover-container", style: { zIndex: 99 } }, children));
};

var optionsFromSimpleList = function (data) {
    var _options = data.map(function (item) { return ({ label: item, value: item }); });
    return _options;
};
var optionsFromObject = function (data) {
    var _options = Object.keys(data).map(function (item) { return ({ value: item, label: data[item] }); });
    return _options;
};

var Select = /*#__PURE__*/Object.freeze({
    __proto__: null,
    optionsFromObject: optionsFromObject,
    optionsFromSimpleList: optionsFromSimpleList
});

var AlignmentType;
(function (AlignmentType) {
    AlignmentType["default"] = "default";
    AlignmentType["left"] = "left";
    AlignmentType["center"] = "center";
})(AlignmentType || (AlignmentType = {}));
var AlignmentType$1 = AlignmentType;

var ModalPlacement;
(function (ModalPlacement) {
    ModalPlacement["default"] = "default";
    ModalPlacement["top"] = "top";
    ModalPlacement["bottom"] = "bottom";
    ModalPlacement["side"] = "side";
})(ModalPlacement || (ModalPlacement = {}));
var ModalPlacement$1 = ModalPlacement;

var ModalSizeType;
(function (ModalSizeType) {
    ModalSizeType["default"] = "default";
    ModalSizeType["small"] = "small";
    ModalSizeType["large"] = "large";
    ModalSizeType["xlarge"] = "xlarge";
})(ModalSizeType || (ModalSizeType = {}));
var ModalSizeType$1 = ModalSizeType;

var Logo$1 = function (props) {
    return (React.createElement("div", { className: "basicui-logo" },
        React.createElement("div", { className: "basicui-logo__icon" },
            React.createElement("img", { src: props.isDarkMode ? props.logoIconWhite : props.logoIconBlack, alt: "Logo" })),
        props.showText && (React.createElement("div", { className: "basicui-logo__text" },
            React.createElement("img", { src: props.isDarkMode ? props.logoTextWhite : props.logoTextBlack, alt: "Logo" })))));
};

var NavbarHeader = function (props) {
    return (React.createElement("div", { className: "basicui-appshellsentinel-navbar-header" },
        React.createElement(Logo$1, { isDarkMode: props.isDarkMode, logoIconBlack: props.logoIconBlack, logoIconWhite: props.logoIconWhite, logoTextBlack: props.logoTextBlack, logoTextWhite: props.logoTextWhite, showText: props.isSidebarExpanded }),
        props.isSidebarExpanded && React.createElement("div", null, props.children)));
};
NavbarHeader.displayName = "NavbarHeader";

var NavbarFooter = function (props) {
    return (React.createElement("div", { className: "basicui-appshellsentinel-navbar-footer ".concat(props.isSidebarExpanded
            ? "basicui-appshellsentinel-navbar-footer--expanded"
            : "basicui-appshellsentinel-navbar-footer--collapsed") },
        React.createElement("div", { className: "basicui-appshellsentinel-navbar-footer__left" },
            props.userName && (React.createElement("button", { className: "button", onClick: props.onSignout }, "SO")),
            !props.userName && (React.createElement("button", { className: "button", onClick: props.onSignin }, "SI")),
            props.isSidebarExpanded && React.createElement("div", null, props.userName)),
        props.isSidebarExpanded && (React.createElement("div", { className: "basicui-appshellsentinel-navbar-footer__right", onClick: props.onDarkModeToggle },
            React.createElement("svg", { "aria-hidden": "true", focusable: "false", "data-prefix": "fas", "data-icon": "sun", className: "svg-inline--fa fa-sun ", role: "img", xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 512 512" },
                React.createElement("path", { fill: "currentColor", d: "M361.5 1.2c5 2.1 8.6 6.6 9.6 11.9L391 121l107.9 19.8c5.3 1 9.8 4.6 11.9 9.6s1.5 10.7-1.6 15.2L446.9 256l62.3 90.3c3.1 4.5 3.7 10.2 1.6 15.2s-6.6 8.6-11.9 9.6L391 391 371.1 498.9c-1 5.3-4.6 9.8-9.6 11.9s-10.7 1.5-15.2-1.6L256 446.9l-90.3 62.3c-4.5 3.1-10.2 3.7-15.2 1.6s-8.6-6.6-9.6-11.9L121 391 13.1 371.1c-5.3-1-9.8-4.6-11.9-9.6s-1.5-10.7 1.6-15.2L65.1 256 2.8 165.7c-3.1-4.5-3.7-10.2-1.6-15.2s6.6-8.6 11.9-9.6L121 121 140.9 13.1c1-5.3 4.6-9.8 9.6-11.9s10.7-1.5 15.2 1.6L256 65.1 346.3 2.8c4.5-3.1 10.2-3.7 15.2-1.6zM160 256a96 96 0 1 1 192 0 96 96 0 1 1 -192 0zm224 0a128 128 0 1 0 -256 0 128 128 0 1 0 256 0z" }))))));
};
NavbarFooter.displayName = "NavbarFooter";

var NavbarBody = function (props) {
    return (React.createElement("div", { className: "basicui-appshellsentinel-navbar-body" },
        React.createElement("button", { className: "basicui-appshellsentinel-navbar-body__toggle", onClick: props.onSidebarToggle },
            props.isSidebarExpanded && (React.createElement("svg", { "aria-hidden": "true", focusable: "false", "data-prefix": "fas", "data-icon": "chevron-left", className: "svg-inline--fa fa-chevron-left ", role: "img", xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 320 512" },
                React.createElement("path", { fill: "currentColor", d: "M9.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l192 192c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L77.3 256 246.6 86.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-192 192z" }))),
            !props.isSidebarExpanded && (React.createElement("svg", { "aria-hidden": "true", focusable: "false", "data-prefix": "fas", "data-icon": "chevron-right", className: "svg-inline--fa fa-chevron-right ", role: "img", xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 320 512" },
                React.createElement("path", { fill: "currentColor", d: "M310.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L242.7 256 73.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z" })))),
        props.children));
};
NavbarBody.displayName = "NavbarBody";

var Navbar$1 = function (_a) {
    var children = _a.children, props = __rest(_a, ["children"]);
    var _b = useState(), appShellNavbarHeader = _b[0], setNavbarHeader = _b[1];
    var _c = useState(), appShellNavbarBody = _c[0], setNavbarBody = _c[1];
    var _d = useState(), appShellNavbarFooter = _d[0], setNavbarFooter = _d[1];
    useEffect(function () {
        children.forEach(function (item) {
            var clonedChild = React.cloneElement(item, __assign({}, props));
            if (item.type.displayName === "NavbarHeader" ||
                item.type.name === "NavbarHeader") {
                setNavbarHeader(clonedChild);
            }
            if (item.type.displayName === "NavbarBody" ||
                item.type.name === "NavbarBody") {
                setNavbarBody(clonedChild);
            }
            if (item.type.displayName === "NavbarFooter" ||
                item.type.name === "NavbarFooter") {
                setNavbarFooter(clonedChild);
            }
        });
    }, [children]);
    return (React.createElement("div", { className: "basicui-appshellsentinel-navbar" },
        appShellNavbarHeader,
        appShellNavbarBody,
        appShellNavbarFooter));
};
Navbar$1.Header = NavbarHeader;
Navbar$1.Footer = NavbarFooter;
Navbar$1.Body = NavbarBody;
Navbar$1.displayName = "Navbar";

var Topbar$1 = function (props) {
    var _a = useState(false), isMobileNavOpen = _a[0], setIsMobileNavOpen = _a[1];
    useEffect(function () {
        var _a;
        console.log(props.location, "****location changed", (_a = props.location) === null || _a === void 0 ? void 0 : _a.pathname);
        setIsMobileNavOpen(false);
    }, [props.location]);
    return (React.createElement(React.Fragment, null,
        React.createElement("div", { className: "basicui-appshellsentinel-topbar" },
            React.createElement("div", { className: "basicui-appshellsentinel-topbar__left" },
                React.createElement(Logo$1, { isDarkMode: props.isDarkMode, logoIconBlack: props.logoIconBlack, logoIconWhite: props.logoIconWhite, logoTextBlack: props.logoTextBlack, logoTextWhite: props.logoTextWhite, showText: true })),
            React.createElement("div", { className: "basicui-appshellsentinel-topbar__right" },
                React.createElement("button", { className: "basicui-appshellsentinel-topbar__right__toggle", onClick: function () { return setIsMobileNavOpen(!isMobileNavOpen); } },
                    React.createElement("svg", { "aria-hidden": "true", focusable: "false", "data-prefix": "fas", "data-icon": "bars", className: "svg-inline--fa fa-bars ", role: "img", xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 448 512" },
                        React.createElement("path", { fill: "currentColor", d: "M0 96C0 78.3 14.3 64 32 64H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32C14.3 128 0 113.7 0 96zM0 256c0-17.7 14.3-32 32-32H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32c-17.7 0-32-14.3-32-32zM448 416c0 17.7-14.3 32-32 32H32c-17.7 0-32-14.3-32-32s14.3-32 32-32H416c17.7 0 32 14.3 32 32z" }))))),
        isMobileNavOpen && props.children));
};
Topbar$1.displayName = "Topbar";

var Body$1 = function (props) {
    return React.createElement("div", { className: "basicui-appshellsentinel-body" }, props.children);
};
Body$1.displayName = "Body";

var MobileNavbarBody = function (props) {
    return (React.createElement("div", { className: "basicui-appshellsentinel-mobile-navbar-body" }, props.children));
};
MobileNavbarBody.displayName = "MobileNavbarBody";

var MobileNavbarFooter = function (props) {
    return (React.createElement("div", { className: "basicui-appshellsentinel-mobile-navbar-footer" },
        React.createElement("div", { className: "basicui-appshellsentinel-mobile-navbar-footer__left" },
            props.userName && (React.createElement("button", { className: "button", onClick: props.onSignout }, "SO")),
            !props.userName && (React.createElement("button", { className: "button", onClick: props.onSignin }, "SI")),
            props.isSidebarExpanded && React.createElement("div", null, props.userName)),
        props.isSidebarExpanded && (React.createElement("div", { className: "basicui-appshellsentinel-mobile-navbar-footer__right", onClick: props.onDarkModeToggle },
            React.createElement("svg", { "aria-hidden": "true", focusable: "false", "data-prefix": "fas", "data-icon": "sun", className: "svg-inline--fa fa-sun ", role: "img", xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 512 512" },
                React.createElement("path", { fill: "currentColor", d: "M361.5 1.2c5 2.1 8.6 6.6 9.6 11.9L391 121l107.9 19.8c5.3 1 9.8 4.6 11.9 9.6s1.5 10.7-1.6 15.2L446.9 256l62.3 90.3c3.1 4.5 3.7 10.2 1.6 15.2s-6.6 8.6-11.9 9.6L391 391 371.1 498.9c-1 5.3-4.6 9.8-9.6 11.9s-10.7 1.5-15.2-1.6L256 446.9l-90.3 62.3c-4.5 3.1-10.2 3.7-15.2 1.6s-8.6-6.6-9.6-11.9L121 391 13.1 371.1c-5.3-1-9.8-4.6-11.9-9.6s-1.5-10.7 1.6-15.2L65.1 256 2.8 165.7c-3.1-4.5-3.7-10.2-1.6-15.2s6.6-8.6 11.9-9.6L121 121 140.9 13.1c1-5.3 4.6-9.8 9.6-11.9s10.7-1.5 15.2 1.6L256 65.1 346.3 2.8c4.5-3.1 10.2-3.7 15.2-1.6zM160 256a96 96 0 1 1 192 0 96 96 0 1 1 -192 0zm224 0a128 128 0 1 0 -256 0 128 128 0 1 0 256 0z" }))))));
};
MobileNavbarFooter.displayName = "MobileNavbarFooter";

var MobileNavbar$1 = function (_a) {
    var children = _a.children, props = __rest(_a, ["children"]);
    var _b = useState(), appShellMobileNavbarBody = _b[0], setMobileNavbarBody = _b[1];
    var _c = useState(), appShellMobileNavbarFooter = _c[0], setMobileNavbarFooter = _c[1];
    useEffect(function () {
        children.forEach(function (item) {
            var clonedChild = React.cloneElement(item, __assign({}, props));
            if (item.type.displayName === "MobileNavbarBody" ||
                item.type.name === "MobileNavbarBody") {
                setMobileNavbarBody(clonedChild);
            }
            if (item.type.displayName === "MobileNavbarFooter" ||
                item.type.name === "MobileNavbarFooter") {
                setMobileNavbarFooter(clonedChild);
            }
        });
    }, [children]);
    return (React.createElement("div", { className: "basicui-appshellsentinel-mobile-navbar" },
        appShellMobileNavbarBody,
        appShellMobileNavbarFooter));
};
MobileNavbar$1.Body = MobileNavbarBody;
MobileNavbar$1.Footer = MobileNavbarFooter;
MobileNavbar$1.displayName = "MobileNavbar";

var AppShellSentinel = function (_a) {
    var children = _a.children, props = __rest(_a, ["children"]);
    var _b = useState(false); _b[0]; _b[1];
    var _c = useState(), navbar = _c[0], setNavbar = _c[1];
    var _d = useState(), topbar = _d[0], setTopbar = _d[1];
    var _e = useState(), body = _e[0], setBody = _e[1];
    var _f = useState(), mobileNavbarBody = _f[0], setMobileNavbar = _f[1];
    useEffect(function () {
        children.forEach(function (item) {
            var clonedChild = React.cloneElement(item, __assign({}, props));
            if (item.type.displayName === "Navbar" ||
                item.type.name === "Navbar") {
                setNavbar(clonedChild);
            }
            if (item.type.displayName === "Body" ||
                item.type.name === "Body") {
                setBody(clonedChild);
            }
            if (item.type.displayName === "MobileNavbar" ||
                item.type.name === "MobileNavbar") {
                setMobileNavbar(clonedChild);
            }
        });
    }, [children]);
    useEffect(function () {
        children.forEach(function (item) {
            var clonedChild = React.cloneElement(item, __assign(__assign({}, props), { children: mobileNavbarBody }));
            if (item.type.displayName === "Topbar" ||
                item.type.name === "Topbar") {
                setTopbar(clonedChild);
            }
        });
    }, [children, mobileNavbarBody]);
    return (React.createElement("div", { className: "basicui-appshellsentinel ".concat(props.isSidebarExpanded
            ? "basicui-appshellsentinel--expanded"
            : "basicui-appshellsentinel--collapsed") },
        !props.hideNavbar && (React.createElement("div", { className: "basicui-appshellsentinel__left  desktop-only" }, navbar)),
        React.createElement("div", { className: "basicui-appshellsentinel__right ".concat(props.hideNavbar ? "basicui-appshellsentinel__right--" + "hide-navbar" : "") },
            topbar,
            body)));
};
AppShellSentinel.Navbar = Navbar$1;
AppShellSentinel.Topbar = Topbar$1;
AppShellSentinel.Body = Body$1;
AppShellSentinel.MobileNavbar = MobileNavbar$1;
AppShellSentinel.displayName = "AppShellSentinel";

var Navbar = function (_a) {
    var children = _a.children; __rest(_a, ["children"]);
    return (React.createElement("div", { className: "basicui-appshellreveal-navbar" }, children));
};
Navbar.displayName = "Navbar";

var Logo = function (props) {
    return (React.createElement("div", { className: "basicui-logo" },
        React.createElement("div", { className: "basicui-logo__icon" },
            React.createElement("img", { src: props.isDarkMode ? props.logoIconWhite : props.logoIconBlack, alt: "Logo" })),
        props.showText && (React.createElement("div", { className: "basicui-logo__text" },
            React.createElement("img", { src: props.isDarkMode ? props.logoTextWhite : props.logoTextBlack, alt: "Logo" })))));
};

var Topbar = function (props) {
    var _a = useState(false), isMobileNavOpen = _a[0], setIsMobileNavOpen = _a[1];
    useEffect(function () {
        var _a;
        console.log(props.location, "****location changed", (_a = props.location) === null || _a === void 0 ? void 0 : _a.pathname);
        setIsMobileNavOpen(false);
    }, [props.location]);
    return (React.createElement(React.Fragment, null,
        React.createElement("div", { className: "basicui-appshellreveal-topbar" },
            React.createElement("div", { className: "basicui-appshellreveal-topbar__left" },
                React.createElement(Logo, { isDarkMode: props.isDarkMode, logoIconBlack: props.logoIconBlack, logoIconWhite: props.logoIconWhite, logoTextBlack: props.logoTextBlack, logoTextWhite: props.logoTextWhite, showText: true })),
            React.createElement("div", { className: "basicui-appshellreveal-topbar__right" },
                React.createElement("button", { className: "basicui-appshellreveal-topbar__right__toggle", onClick: function () { return setIsMobileNavOpen(!isMobileNavOpen); } },
                    React.createElement("svg", { "aria-hidden": "true", focusable: "false", "data-prefix": "fas", "data-icon": "bars", className: "svg-inline--fa fa-bars ", role: "img", xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 448 512" },
                        React.createElement("path", { fill: "currentColor", d: "M0 96C0 78.3 14.3 64 32 64H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32C14.3 128 0 113.7 0 96zM0 256c0-17.7 14.3-32 32-32H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32c-17.7 0-32-14.3-32-32zM448 416c0 17.7-14.3 32-32 32H32c-17.7 0-32-14.3-32-32s14.3-32 32-32H416c17.7 0 32 14.3 32 32z" }))))),
        isMobileNavOpen && props.children));
};
Topbar.displayName = "Topbar";

var Body = function (props) {
    return React.createElement("div", { className: "basicui-appshellreveal-body" }, props.children);
};
Body.displayName = "Body";

var MobileNavbar = function (_a) {
    var children = _a.children; __rest(_a, ["children"]);
    return (React.createElement("div", { className: "basicui-appshellreveal-mobile-navbar" }, children));
};
MobileNavbar.displayName = "MobileNavbar";

var AppShellReveal = function (_a) {
    var children = _a.children, props = __rest(_a, ["children"]);
    var _b = useState(false), shouldRenderMenu = _b[0], setShouldRenderMenu = _b[1];
    var _c = useState(), navbar = _c[0], setNavbar = _c[1];
    var _d = useState(), body = _d[0], setBody = _d[1];
    var _e = useState(), mobileNavbarBody = _e[0], setMobileNavbar = _e[1];
    var animationTimeout = useRef(null);
    useEffect(function () {
        children.forEach(function (item) {
            var clonedChild = React.cloneElement(item, __assign({}, props));
            if (item.type.displayName === "Navbar" || item.type.name === "Navbar") {
                setNavbar(clonedChild);
            }
            if (item.type.displayName === "Body" || item.type.name === "Body") {
                setBody(clonedChild);
            }
            if (item.type.displayName === "MobileNavbar" || item.type.name === "MobileNavbar") {
                setMobileNavbar(clonedChild);
            }
        });
    }, [children]);
    useEffect(function () {
        if (props.isMenuActive) {
            setShouldRenderMenu(true);
        }
        else {
            if (animationTimeout.current)
                clearTimeout(animationTimeout.current);
            animationTimeout.current = setTimeout(function () {
                setShouldRenderMenu(false);
            }, 300);
        }
        return function () {
            if (animationTimeout.current)
                clearTimeout(animationTimeout.current);
        };
    }, [props.isMenuActive]);
    return (React.createElement("div", { className: "basicui-appshellreveal" },
        React.createElement("header", { className: "basicui-appshellreveal__header" },
            React.createElement("div", { className: "basicui-appshellreveal__header__left" },
                React.createElement(Logo, { logoIconBlack: props.logoIconBlack, logoIconWhite: props.logoIconWhite, logoTextBlack: props.logoTextBlack, logoTextWhite: props.logoTextWhite, showText: true, isDarkMode: props.isDarkMode })),
            props.userName && (React.createElement("button", { className: "basicui-internal-button basicui-appshellreveal__header__user", onClick: props.onSignout },
                React.createElement(SvgIcon, { src: "/icons/fontawesome/signout.svg" }),
                " ",
                props.userName)),
            !props.userName && (React.createElement("button", { className: "basicui-internal-button basicui-appshellreveal__header__user", onClick: props.onSignin },
                React.createElement(SvgIcon, { src: "/icons/fontawesome/signin.svg" }),
                " Login")),
            React.createElement("button", { className: "basicui-internal-button basicui-appshellreveal__header__right", onClick: function () { return props.setIsMenuActive(!props.isMenuActive); } },
                React.createElement("div", { className: "basicui-appshellreveal__header__right__icon ".concat(props.isMenuActive ? "basicui-appshellreveal__header__right__icon--open" : "") },
                    React.createElement("span", null),
                    React.createElement("span", null)))),
        React.createElement("div", { className: "basicui-appshellreveal__main" }, body),
        shouldRenderMenu && (React.createElement("div", { className: "basicui-appshellreveal__menupanel basicui-webonly ".concat(props.isMenuActive ? "slide-down" : "slide-up") },
            React.createElement("div", { className: "basicui-appshellreveal__menupanel__menucontent" }, navbar))),
        shouldRenderMenu && (React.createElement("div", { className: "basicui-appshellreveal__menupanel basicui-mobileonly ".concat(props.isMenuActive ? "slide-down" : "slide-up") },
            React.createElement("div", { className: "basicui-appshellreveal__menupanel__menucontent" }, mobileNavbarBody)))));
};
AppShellReveal.Navbar = Navbar;
AppShellReveal.Topbar = Topbar;
AppShellReveal.Body = Body;
AppShellReveal.MobileNavbar = MobileNavbar;
AppShellReveal.displayName = "AppShellReveal";

/**
 * Component to layout child elements in a flex arrangement
 */
var FlexContainer = function (props) {
    return (React.createElement("div", { className: "basicui-flex-container basicui-flex-container--orientation-".concat(props.orientation || "default", " basicui-flex-container--alignx-").concat(props.alignX || "default", " basicui-flex-container--aligny-").concat(props.alignY || "default", " basicui-flex-container--gap-").concat(props.gap || "default", " ").concat(props.wrap ? "basicui-flex-container--wrap" : "") },
        React.createElement("div", { className: "basicui-flex-container__children" }, props.children),
        React.createElement("div", { className: "basicui-flex-container__antimargin" })));
};

/**
 * Component to show loading indication on a page
 */
var LoadingBlocks = function (props) {
    var _a = useState([]), blocks = _a[0], setBlocks = _a[1];
    useEffect(function () {
        // Generate random block widths
        var newBlocks = Array.from({ length: props.numberOfBlocks }, function () {
            return Math.floor(Math.random() * (props.maxWidth - props.minWidth) + props.minWidth);
        });
        setBlocks(newBlocks);
    }, [props.numberOfBlocks]);
    return (React.createElement("div", { className: "basicui-loadingblocks" }, blocks.map(function (width, index) { return (React.createElement("div", { key: index, className: "basicui-loadingblocks__block ".concat(props.isStatic ? "" : "basicui-loadingblocks__block--loading"), style: { width: "".concat(width, "%") } })); })));
};

export { Accordion, AlignmentType$1 as AlignmentType, AppShellReveal, AppShellSentinel, Button, ButtonVariantType$1 as ButtonVariantType, Checkbox, FlexContainer, IconButton, Input, Label, Link, LoadingBlocks, Modal, ModalBody, ModalFooter, ModalHeader, ModalPlacement$1 as ModalPlacement, ModalSizeType$1 as ModalSizeType, Popover, Radio, Select$1 as Select, SelectNative, Select as SelectPropsConverter, SvgIcon, Tab, TabDetail, TabHeader, Tabs, Textarea, ThemeType$1 as ThemeType };
//# sourceMappingURL=index.esm.js.map
