import React from "react";
import "./styles/index.css";
export type ThemesOverviewProps = {};
/**
 * Component to render drop down input form element. Supports multi select and auto complete features
 */
declare const ThemesOverview: (props: ThemesOverviewProps) => React.JSX.Element;
export default ThemesOverview;
