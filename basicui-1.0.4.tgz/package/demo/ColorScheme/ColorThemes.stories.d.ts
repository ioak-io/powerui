import React from 'react';
import type { Meta } from '@storybook/react';
declare const meta: Meta;
export default meta;
export declare const ColorThemes: () => React.JSX.Element;
