import React from "react";
import "./styles/index.css";
export type ColorSchemeProps = {
    discriminator: "black" | "white" | "black-extended" | "white-extended" | "default" | "default-transparent" | "primary" | "primary-transparent" | "danger" | "danger-transparent" | "themes-overview";
};
/**
 * Component to render drop down input form element. Supports multi select and auto complete features
 */
declare const ColorScheme: (props: ColorSchemeProps) => React.JSX.Element;
export default ColorScheme;
