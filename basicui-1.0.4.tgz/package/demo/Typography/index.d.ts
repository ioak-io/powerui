import React from "react";
export type TypographyProps = {};
/**
 * Component to render drop down input form element. Supports multi select and auto complete features
 */
declare const Typography: (props: TypographyProps) => React.JSX.Element;
export default Typography;
