import { Meta, StoryObj } from '@storybook/react';
import UserGuide from '.';
declare const meta: Meta<typeof UserGuide>;
export default meta;
type Story = StoryObj<typeof UserGuide>;
export declare const Introduction: Story;
export declare const ColorSchemeGenerator: Story;
