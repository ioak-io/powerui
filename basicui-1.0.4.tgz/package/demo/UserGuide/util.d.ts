type ColorSet = {
    [key: string]: string;
};
export declare const generateCompleteColorScheme: (baseHex: string, baseColorVariableName: string) => {
    lightMode: ColorSet;
    darkMode: ColorSet;
};
export {};
