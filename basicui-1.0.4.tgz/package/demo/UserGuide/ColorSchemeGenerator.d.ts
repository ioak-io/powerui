import React from "react";
import "./style.css";
declare const ColorSchemeGenerator: () => React.JSX.Element;
export default ColorSchemeGenerator;
