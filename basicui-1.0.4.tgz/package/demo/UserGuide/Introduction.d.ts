import React from "react";
import "./style.css";
declare const Introduction: () => React.JSX.Element;
export default Introduction;
