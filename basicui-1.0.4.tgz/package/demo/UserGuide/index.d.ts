import React from "react";
import "./style.css";
interface Props {
    variant: "introduction" | "color-scheme-generator";
}
declare const UserGuide: (props: Props) => React.JSX.Element;
export default UserGuide;
