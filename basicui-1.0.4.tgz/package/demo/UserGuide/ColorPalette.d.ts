import React from "react";
interface ColorPaletteProps {
    colors: {
        lightMode: Record<string, string>;
        darkMode: Record<string, string>;
    };
    colorname: string;
}
declare const ColorPalette: React.FC<ColorPaletteProps>;
export default ColorPalette;
