import React from "react";
import "./style.css";
export type DemoSectionProps = {
    heading: string;
    children: any;
};
/**
 * Component to render drop down input form element. Supports multi select and auto complete features
 */
declare const DemoSection: (props: DemoSectionProps) => React.JSX.Element;
export default DemoSection;
