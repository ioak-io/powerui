import React from "react";
import ThemeType from "../types/ThemeType";
export interface CheckboxProps {
    id?: string;
    label?: string;
    theme?: ThemeType;
    circle?: boolean;
    checked?: boolean;
    defaultChecked?: boolean;
    [key: string]: any;
}
/**
 * Component to render checkbox form element. For using it with standard html input, add css class basicui-input
 */
declare const Checkbox: ({ id, label, theme, checked, circle, ...restProps }: CheckboxProps) => React.JSX.Element;
export default Checkbox;
