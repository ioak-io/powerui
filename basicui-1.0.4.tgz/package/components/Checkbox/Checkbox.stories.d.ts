import { Meta } from '@storybook/react';
import Checkbox, { CheckboxProps } from ".";
declare const meta: Meta<typeof Checkbox>;
export default meta;
export declare const Playground: {
    args: {
        label: string;
    };
    decorators?: import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        [x: string]: any;
        id?: string | undefined;
        label?: string | undefined;
        theme?: import("../types/ThemeType").default | undefined;
        circle?: boolean | undefined;
        checked?: boolean | undefined;
        defaultChecked?: boolean | undefined;
    }> | import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        [x: string]: any;
        id?: string | undefined;
        label?: string | undefined;
        theme?: import("../types/ThemeType").default | undefined;
        circle?: boolean | undefined;
        checked?: boolean | undefined;
        defaultChecked?: boolean | undefined;
    }>[] | undefined;
    parameters?: import("@storybook/types").Parameters | undefined;
    argTypes?: Partial<import("@storybook/types").ArgTypes<CheckboxProps>> | undefined;
    loaders?: import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, CheckboxProps> | import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, CheckboxProps>[] | undefined;
    render?: import("@storybook/types").ArgsStoryFn<import("@storybook/react/dist/types-0fc72a6d").R, CheckboxProps> | undefined;
    name?: string | undefined;
    storyName?: string | undefined;
    play?: import("@storybook/types").PlayFunction<import("@storybook/react/dist/types-0fc72a6d").R, CheckboxProps> | undefined;
    tags?: string[] | undefined;
    story?: Omit<import("@storybook/types").StoryAnnotations<import("@storybook/react/dist/types-0fc72a6d").R, CheckboxProps, Partial<CheckboxProps>>, "story"> | undefined;
};
