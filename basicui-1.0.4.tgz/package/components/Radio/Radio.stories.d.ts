import { Meta } from '@storybook/react';
import Radio, { RadioProps } from '.';
import ThemeType from '../types/ThemeType';
declare const meta: Meta<typeof Radio>;
export default meta;
export declare const Playground: {
    args: {
        theme: ThemeType;
        label: string;
    };
    decorators?: import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        [x: string]: any;
        name?: string | undefined;
        id?: string | undefined;
        label?: string | number | undefined;
        theme?: ThemeType | undefined;
        checked?: boolean | undefined;
        value?: any;
    }> | import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        [x: string]: any;
        name?: string | undefined;
        id?: string | undefined;
        label?: string | number | undefined;
        theme?: ThemeType | undefined;
        checked?: boolean | undefined;
        value?: any;
    }>[] | undefined;
    parameters?: import("@storybook/types").Parameters | undefined;
    argTypes?: Partial<import("@storybook/types").ArgTypes<RadioProps>> | undefined;
    loaders?: import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, RadioProps> | import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, RadioProps>[] | undefined;
    render?: import("@storybook/types").ArgsStoryFn<import("@storybook/react/dist/types-0fc72a6d").R, RadioProps> | undefined;
    name?: string | undefined;
    storyName?: string | undefined;
    play?: import("@storybook/types").PlayFunction<import("@storybook/react/dist/types-0fc72a6d").R, RadioProps> | undefined;
    tags?: string[] | undefined;
    story?: Omit<import("@storybook/types").StoryAnnotations<import("@storybook/react/dist/types-0fc72a6d").R, RadioProps, Partial<RadioProps>>, "story"> | undefined;
};
