import React from "react";
import ThemeType from "../types/ThemeType";
export interface RadioProps {
    name?: string;
    id?: string;
    label?: string | number;
    theme?: ThemeType;
    checked?: boolean;
    value?: any;
    [key: string]: any;
}
/**
 * Component to render radio form element. For using it with standard html input, add css class basicui-input
 */
declare const Radio: ({ id, theme, label, checked, ...restProps }: RadioProps) => React.JSX.Element;
export default Radio;
