import React from "react";
import { ModalProps } from ".";
declare const StoryWrapper: (props: ModalProps) => React.JSX.Element;
export default StoryWrapper;
