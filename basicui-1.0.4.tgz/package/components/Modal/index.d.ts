import React from 'react';
import ModalPlacement from '../types/ModalPlacement';
import ModalSizeType from '../types/ModalSizeType';
export type ModalProps = {
    isOpen: boolean;
    onClose: any;
    size?: ModalSizeType;
    placement?: ModalPlacement;
    children?: any;
};
declare const Modal: (props: ModalProps) => React.JSX.Element | null;
export default Modal;
