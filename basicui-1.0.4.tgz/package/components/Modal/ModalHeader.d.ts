import React from 'react';
export type ModalHeaderProps = {
    onClose: any;
    heading?: string;
    border?: boolean;
};
declare const ModalHeader: (props: ModalHeaderProps) => React.JSX.Element;
export default ModalHeader;
