import React from 'react';
export type ModalBodyProps = {
    children?: any;
};
declare const ModalBody: (props: ModalBodyProps) => React.JSX.Element;
export default ModalBody;
