import { Meta } from '@storybook/react';
import React from "react";
import ModalFooter, { ModalFooterProps } from './ModalFooter';
declare const meta: Meta<typeof ModalFooter>;
export default meta;
export declare const Playground: {
    args: {
        children: React.JSX.Element;
    };
    decorators?: import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        children?: any;
        alignment?: import("../types/AlignmentType").default | undefined;
        border?: boolean | undefined;
    }> | import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        children?: any;
        alignment?: import("../types/AlignmentType").default | undefined;
        border?: boolean | undefined;
    }>[] | undefined;
    parameters?: import("@storybook/types").Parameters | undefined;
    argTypes?: Partial<import("@storybook/types").ArgTypes<ModalFooterProps>> | undefined;
    loaders?: import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, ModalFooterProps> | import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, ModalFooterProps>[] | undefined;
    render?: import("@storybook/types").ArgsStoryFn<import("@storybook/react/dist/types-0fc72a6d").R, ModalFooterProps> | undefined;
    name?: string | undefined;
    storyName?: string | undefined;
    play?: import("@storybook/types").PlayFunction<import("@storybook/react/dist/types-0fc72a6d").R, ModalFooterProps> | undefined;
    tags?: string[] | undefined;
    story?: Omit<import("@storybook/types").StoryAnnotations<import("@storybook/react/dist/types-0fc72a6d").R, ModalFooterProps, Partial<ModalFooterProps>>, "story"> | undefined;
};
