import { Meta } from '@storybook/react';
import Modal, { ModalProps } from '.';
declare const meta: Meta<typeof Modal>;
export default meta;
export declare const Playground: {
    args: {};
    decorators?: import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        isOpen: boolean;
        onClose: any;
        size?: import("../types/ModalSizeType").default | undefined;
        placement?: import("../types/ModalPlacement").default | undefined;
        children?: any;
    }> | import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        isOpen: boolean;
        onClose: any;
        size?: import("../types/ModalSizeType").default | undefined;
        placement?: import("../types/ModalPlacement").default | undefined;
        children?: any;
    }>[] | undefined;
    parameters?: import("@storybook/types").Parameters | undefined;
    argTypes?: Partial<import("@storybook/types").ArgTypes<ModalProps>> | undefined;
    loaders?: import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, ModalProps> | import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, ModalProps>[] | undefined;
    render?: import("@storybook/types").ArgsStoryFn<import("@storybook/react/dist/types-0fc72a6d").R, ModalProps> | undefined;
    name?: string | undefined;
    storyName?: string | undefined;
    play?: import("@storybook/types").PlayFunction<import("@storybook/react/dist/types-0fc72a6d").R, ModalProps> | undefined;
    tags?: string[] | undefined;
    story?: Omit<import("@storybook/types").StoryAnnotations<import("@storybook/react/dist/types-0fc72a6d").R, ModalProps, Partial<ModalProps>>, "story"> | undefined;
};
