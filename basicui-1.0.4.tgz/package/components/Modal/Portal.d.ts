import { ReactNode } from "react";
declare const defaultPortalProps: {
    wrapperId: string;
};
type PortalProps = {
    children: ReactNode;
    wrapperId: string;
} & typeof defaultPortalProps;
declare const Portal: {
    ({ children, wrapperId }: PortalProps): import("react").ReactPortal | null;
    defaultProps: {
        wrapperId: string;
    };
};
export default Portal;
