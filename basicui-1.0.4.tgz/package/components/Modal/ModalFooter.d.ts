import React from 'react';
import AlignmentType from '../types/AlignmentType';
export type ModalFooterProps = {
    children?: any;
    alignment?: AlignmentType;
    border?: boolean;
};
declare const ModalFooter: (props: ModalFooterProps) => React.JSX.Element;
export default ModalFooter;
