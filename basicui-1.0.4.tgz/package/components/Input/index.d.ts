import React from "react";
export type InputProps = {
    id?: string;
    type?: string;
    label?: string;
    labelDesc?: string;
    value?: string | number;
    placeholder?: string;
    tooltip?: string;
    errorMessage?: string;
    warningMessage?: string;
    successMessage?: string;
    onChange?: any;
    onInput?: any;
    className?: string;
    [key: string]: any;
};
/**
 * Component to render input form element. For using it with standard html input, add css class basicui-input
 */
declare const Input: ({ id, type, label, labelDesc, value, placeholder, tooltip, errorMessage, warningMessage, successMessage, className, wrapperClassName, ...restProps }: InputProps) => React.JSX.Element;
export default Input;
