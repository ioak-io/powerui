import React from "react";
export type FlexContainerProps = {
    children: any;
    orientation?: "default" | "column";
    wrap?: boolean;
    alignX?: "default" | "center" | "right";
    alignY?: "default" | "middle" | "bottom";
    gap?: "default" | "less" | "more";
};
/**
 * Component to layout child elements in a flex arrangement
 */
declare const FlexContainer: (props: FlexContainerProps) => React.JSX.Element;
export default FlexContainer;
