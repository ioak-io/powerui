import { Meta } from "@storybook/react";
import React from "react";
import FlexContainer, { FlexContainerProps } from ".";
declare const meta: Meta<typeof FlexContainer>;
export default meta;
export declare const Playground: {
    args: {
        children: React.JSX.Element;
    };
    decorators?: import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        children: any;
        orientation?: "default" | "column" | undefined;
        wrap?: boolean | undefined;
        alignX?: "center" | "default" | "right" | undefined;
        alignY?: "default" | "middle" | "bottom" | undefined;
        gap?: "default" | "less" | "more" | undefined;
    }> | import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        children: any;
        orientation?: "default" | "column" | undefined;
        wrap?: boolean | undefined;
        alignX?: "center" | "default" | "right" | undefined;
        alignY?: "default" | "middle" | "bottom" | undefined;
        gap?: "default" | "less" | "more" | undefined;
    }>[] | undefined;
    parameters?: import("@storybook/types").Parameters | undefined;
    argTypes?: Partial<import("@storybook/types").ArgTypes<FlexContainerProps>> | undefined;
    loaders?: import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, FlexContainerProps> | import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, FlexContainerProps>[] | undefined;
    render?: import("@storybook/types").ArgsStoryFn<import("@storybook/react/dist/types-0fc72a6d").R, FlexContainerProps> | undefined;
    name?: string | undefined;
    storyName?: string | undefined;
    play?: import("@storybook/types").PlayFunction<import("@storybook/react/dist/types-0fc72a6d").R, FlexContainerProps> | undefined;
    tags?: string[] | undefined;
    story?: Omit<import("@storybook/types").StoryAnnotations<import("@storybook/react/dist/types-0fc72a6d").R, FlexContainerProps, Partial<FlexContainerProps>>, "story"> | undefined;
};
