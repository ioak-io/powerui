import { Meta } from '@storybook/react';
import React from "react";
import Button, { ButtonProps } from ".";
import ThemeType from "../types/ThemeType";
import ButtonVariantType from "../types/ButtonVariantType";
declare const meta: Meta<typeof Button>;
export default meta;
export declare const Playground: {
    args: {
        theme: ThemeType;
        variant: ButtonVariantType;
        children: React.JSX.Element;
    };
    decorators?: import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        [x: string]: any;
        theme?: ThemeType | undefined;
        onClick?: any;
        onSubmit?: any;
        onReset?: any;
        type?: "button" | "submit" | "reset" | undefined;
        disabled?: boolean | undefined;
        variant?: ButtonVariantType | undefined;
        children: any;
        loading?: boolean | undefined;
        className?: string | undefined;
    }> | import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        [x: string]: any;
        theme?: ThemeType | undefined;
        onClick?: any;
        onSubmit?: any;
        onReset?: any;
        type?: "button" | "submit" | "reset" | undefined;
        disabled?: boolean | undefined;
        variant?: ButtonVariantType | undefined;
        children: any;
        loading?: boolean | undefined;
        className?: string | undefined;
    }>[] | undefined;
    parameters?: import("@storybook/types").Parameters | undefined;
    argTypes?: Partial<import("@storybook/types").ArgTypes<ButtonProps>> | undefined;
    loaders?: import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, ButtonProps> | import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, ButtonProps>[] | undefined;
    render?: import("@storybook/types").ArgsStoryFn<import("@storybook/react/dist/types-0fc72a6d").R, ButtonProps> | undefined;
    name?: string | undefined;
    storyName?: string | undefined;
    play?: import("@storybook/types").PlayFunction<import("@storybook/react/dist/types-0fc72a6d").R, ButtonProps> | undefined;
    tags?: string[] | undefined;
    story?: Omit<import("@storybook/types").StoryAnnotations<import("@storybook/react/dist/types-0fc72a6d").R, ButtonProps, Partial<ButtonProps>>, "story"> | undefined;
};
