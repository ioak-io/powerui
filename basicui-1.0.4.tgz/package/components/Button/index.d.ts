import React from "react";
import ButtonVariantType from "../types/ButtonVariantType";
import ThemeType from "../types/ThemeType";
export interface ButtonProps {
    theme?: ThemeType;
    onClick?: any;
    onSubmit?: any;
    onReset?: any;
    type?: "button" | "submit" | "reset";
    disabled?: boolean;
    variant?: ButtonVariantType;
    children: any;
    loading?: boolean;
    className?: string;
    [key: string]: any;
}
/**
 * Component to render drop down input form element. Supports multi select and auto complete features
 */
declare const Button: ({ type, theme, variant, loading, children, disabled, className, ...restProps }: ButtonProps) => React.JSX.Element;
export default Button;
