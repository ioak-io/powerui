import React from "react";
interface PopoverProps {
    visible: boolean;
    anchorRef: React.RefObject<HTMLElement>;
    onClose?: () => void;
    children: React.ReactNode;
    placement?: "top" | "bottom" | "left" | "right" | "bottom-start" | "top-end" | any;
}
declare const Popover: ({ visible, anchorRef, onClose, children, placement }: PopoverProps) => React.JSX.Element | null;
export default Popover;
