import React from "react";
export interface TabDetailProps {
    children: any;
}
/**
 * Component to render details for the tab
 */
declare const TabDetail: (props: TabDetailProps) => React.JSX.Element;
export default TabDetail;
