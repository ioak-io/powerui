import React from "react";
import TabShapeType from "../types/TabShapeType";
import ThemeType from "../types/ThemeType";
export type TabsProps = {
    theme?: ThemeType;
    shape?: TabShapeType;
    offset?: boolean;
    activeTabId: string;
    onChange: any;
    children: any;
};
/**
 * Component to render tab surface
 */
declare const Tabs: (props: TabsProps) => React.JSX.Element;
export default Tabs;
