import React from "react";
import { TabsProps } from ".";
import ThemeType from "../types/ThemeType";
export type TabsWrapperProps = {
    flushed: boolean;
    theme: ThemeType;
};
declare const TabsWrapper: (props: TabsProps) => React.JSX.Element;
export default TabsWrapper;
