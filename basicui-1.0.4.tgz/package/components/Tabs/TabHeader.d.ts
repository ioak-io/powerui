import React from "react";
import TabHeaderAlignmentType from "../types/TabHeaderAlignmentType";
export interface TabHeaderProps {
    alignment?: TabHeaderAlignmentType;
    children: any;
}
/**
 * Component to render Header link for the tab
 */
declare const TabHeader: (props: TabHeaderProps) => React.JSX.Element;
export default TabHeader;
