import { Meta } from '@storybook/react';
import Tabs, { TabsProps } from '.';
import ThemeType from '../types/ThemeType';
declare const meta: Meta<typeof Tabs>;
export default meta;
export declare const Playground: {
    args: {
        theme: ThemeType;
    };
    decorators?: import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        theme?: ThemeType | undefined;
        shape?: import("../types/TabShapeType").default | undefined;
        offset?: boolean | undefined;
        activeTabId: string;
        onChange: any;
        children: any;
    }> | import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        theme?: ThemeType | undefined;
        shape?: import("../types/TabShapeType").default | undefined;
        offset?: boolean | undefined;
        activeTabId: string;
        onChange: any;
        children: any;
    }>[] | undefined;
    parameters?: import("@storybook/types").Parameters | undefined;
    argTypes?: Partial<import("@storybook/types").ArgTypes<TabsProps>> | undefined;
    loaders?: import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, TabsProps> | import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, TabsProps>[] | undefined;
    render?: import("@storybook/types").ArgsStoryFn<import("@storybook/react/dist/types-0fc72a6d").R, TabsProps> | undefined;
    name?: string | undefined;
    storyName?: string | undefined;
    play?: import("@storybook/types").PlayFunction<import("@storybook/react/dist/types-0fc72a6d").R, TabsProps> | undefined;
    tags?: string[] | undefined;
    story?: Omit<import("@storybook/types").StoryAnnotations<import("@storybook/react/dist/types-0fc72a6d").R, TabsProps, Partial<TabsProps>>, "story"> | undefined;
};
