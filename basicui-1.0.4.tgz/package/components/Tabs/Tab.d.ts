import React from "react";
export interface TabProps {
    id: string;
    children: any;
}
/**
 * Component to render drop down input form element. Supports multi select and auto complete features
 */
declare const Tab: (props: TabProps) => React.JSX.Element;
export default Tab;
