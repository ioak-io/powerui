import React from "react";
export interface ListItemProps {
    children?: React.ReactNode;
}
declare const ListItem: {
    (props: ListItemProps): React.JSX.Element;
    displayName: string;
};
export default ListItem;
