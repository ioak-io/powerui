import React from "react";
declare const ListWrapper: (props: {
    renderFromChildren: boolean;
    showSelectOnRight: boolean;
}) => React.JSX.Element;
export default ListWrapper;
