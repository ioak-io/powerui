import React, { ReactNode } from "react";
export interface ListProps {
    data: ListItemType[];
    onClick?: (id: string) => void;
    children?: ReactNode;
    selectedItems?: string[];
    onSelect?: (event: any) => void;
    showSelectOnRight?: boolean;
    actions?: {
        singleSelect?: ReactNode[];
        multiSelect?: ReactNode[];
        noneSelect?: ReactNode[];
        always?: ReactNode[];
    };
}
export interface ListItemType {
    id: string;
    title: string;
    summary: string;
    labels?: {
        id: string;
        value: string;
    }[];
    createdAt?: Date | string;
    [key: string]: any;
}
declare const List: (props: ListProps) => React.JSX.Element;
export default List;
