import React from "react";
import { ListItemType } from ".";
export interface ListItemInternalProps {
    selectedItems?: string[];
    onClick?: (id: string) => void;
    onSelect?: (event: any) => void;
    data: ListItemType;
    children?: React.ReactNode;
    showSelectOnRight?: boolean;
}
declare const ListItemInternal: (props: ListItemInternalProps) => React.JSX.Element;
export default ListItemInternal;
