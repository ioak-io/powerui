import { Meta } from '@storybook/react';
import React from "react";
import List, { ListProps } from '.';
declare const meta: Meta<typeof List>;
export default meta;
export declare const Playground: {
    args: {
        renderFromChildren: boolean;
    };
    decorators?: import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        data: import(".").ListItemType[];
        onClick?: ((id: string) => void) | undefined;
        children?: React.ReactNode;
        selectedItems?: string[] | undefined;
        onSelect?: ((event: any) => void) | undefined;
        showSelectOnRight?: boolean | undefined;
        actions?: {
            singleSelect?: React.ReactNode[] | undefined;
            multiSelect?: React.ReactNode[] | undefined;
            noneSelect?: React.ReactNode[] | undefined;
            always?: React.ReactNode[] | undefined;
        } | undefined;
    }> | import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        data: import(".").ListItemType[];
        onClick?: ((id: string) => void) | undefined;
        children?: React.ReactNode;
        selectedItems?: string[] | undefined;
        onSelect?: ((event: any) => void) | undefined;
        showSelectOnRight?: boolean | undefined;
        actions?: {
            singleSelect?: React.ReactNode[] | undefined;
            multiSelect?: React.ReactNode[] | undefined;
            noneSelect?: React.ReactNode[] | undefined;
            always?: React.ReactNode[] | undefined;
        } | undefined;
    }>[] | undefined;
    parameters?: import("@storybook/types").Parameters | undefined;
    argTypes?: Partial<import("@storybook/types").ArgTypes<ListProps>> | undefined;
    loaders?: import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, ListProps> | import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, ListProps>[] | undefined;
    render?: import("@storybook/types").ArgsStoryFn<import("@storybook/react/dist/types-0fc72a6d").R, ListProps> | undefined;
    name?: string | undefined;
    storyName?: string | undefined;
    play?: import("@storybook/types").PlayFunction<import("@storybook/react/dist/types-0fc72a6d").R, ListProps> | undefined;
    tags?: string[] | undefined;
    story?: Omit<import("@storybook/types").StoryAnnotations<import("@storybook/react/dist/types-0fc72a6d").R, ListProps, Partial<ListProps>>, "story"> | undefined;
};
