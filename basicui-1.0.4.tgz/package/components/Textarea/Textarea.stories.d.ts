import { Meta } from '@storybook/react';
import Textarea, { TextareaProps } from '.';
declare const meta: Meta<typeof Textarea>;
export default meta;
export declare const Playground: {
    args: {
        label: string;
        initialValue: string;
        placeholder: string;
    };
    decorators?: import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        [x: string]: any;
        label?: string | undefined;
        labelDesc?: string | undefined;
        value?: string | number | undefined;
        tooltip?: string | undefined;
        errorMessage?: string | undefined;
        warningMessage?: string | undefined;
        successMessage?: string | undefined;
    }> | import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        [x: string]: any;
        label?: string | undefined;
        labelDesc?: string | undefined;
        value?: string | number | undefined;
        tooltip?: string | undefined;
        errorMessage?: string | undefined;
        warningMessage?: string | undefined;
        successMessage?: string | undefined;
    }>[] | undefined;
    parameters?: import("@storybook/types").Parameters | undefined;
    argTypes?: Partial<import("@storybook/types").ArgTypes<TextareaProps>> | undefined;
    loaders?: import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, TextareaProps> | import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, TextareaProps>[] | undefined;
    render?: import("@storybook/types").ArgsStoryFn<import("@storybook/react/dist/types-0fc72a6d").R, TextareaProps> | undefined;
    name?: string | undefined;
    storyName?: string | undefined;
    play?: import("@storybook/types").PlayFunction<import("@storybook/react/dist/types-0fc72a6d").R, TextareaProps> | undefined;
    tags?: string[] | undefined;
    story?: Omit<import("@storybook/types").StoryAnnotations<import("@storybook/react/dist/types-0fc72a6d").R, TextareaProps, Partial<TextareaProps>>, "story"> | undefined;
};
