import React from "react";
export interface TextareaProps {
    label?: string;
    labelDesc?: string;
    value?: string | number;
    tooltip?: string;
    errorMessage?: string;
    warningMessage?: string;
    successMessage?: string;
    [key: string]: any;
}
/**
 * Component to render input form element. For using it with standard html input, add css class basicui-input
 */
declare const Textarea: ({ value, label, labelDesc, tooltip, errorMessage, successMessage, warningMessage, ...restProps }: TextareaProps) => React.JSX.Element;
export default Textarea;
