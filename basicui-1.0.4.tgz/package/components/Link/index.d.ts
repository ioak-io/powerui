import React from "react";
import ThemeType from "../types/ThemeType";
export interface LinkProps {
    theme?: ThemeType;
    noUnderline?: boolean;
    noGlow?: boolean;
    children?: any;
    label?: string;
    href: string;
    className?: string;
}
/**
 * Component to render drop down input form element. Supports multi select and auto complete features
 */
declare const Link: ({ href, children, label, noGlow, noUnderline, theme, className, ...restProps }: LinkProps) => React.JSX.Element;
export default Link;
