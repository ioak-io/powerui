import { Meta } from '@storybook/react';
import React from "react";
import Link, { LinkProps } from '.';
import ThemeType from '../types/ThemeType';
declare const meta: Meta<typeof Link>;
export default meta;
export declare const Playground: {
    args: {
        theme: ThemeType;
        label: string;
        children: React.JSX.Element;
    };
    decorators?: import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        theme?: ThemeType | undefined;
        noUnderline?: boolean | undefined;
        noGlow?: boolean | undefined;
        children?: any;
        label?: string | undefined;
        href: string;
        className?: string | undefined;
    }> | import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        theme?: ThemeType | undefined;
        noUnderline?: boolean | undefined;
        noGlow?: boolean | undefined;
        children?: any;
        label?: string | undefined;
        href: string;
        className?: string | undefined;
    }>[] | undefined;
    parameters?: import("@storybook/types").Parameters | undefined;
    argTypes?: Partial<import("@storybook/types").ArgTypes<LinkProps>> | undefined;
    loaders?: import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, LinkProps> | import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, LinkProps>[] | undefined;
    render?: import("@storybook/types").ArgsStoryFn<import("@storybook/react/dist/types-0fc72a6d").R, LinkProps> | undefined;
    name?: string | undefined;
    storyName?: string | undefined;
    play?: import("@storybook/types").PlayFunction<import("@storybook/react/dist/types-0fc72a6d").R, LinkProps> | undefined;
    tags?: string[] | undefined;
    story?: Omit<import("@storybook/types").StoryAnnotations<import("@storybook/react/dist/types-0fc72a6d").R, LinkProps, Partial<LinkProps>>, "story"> | undefined;
};
