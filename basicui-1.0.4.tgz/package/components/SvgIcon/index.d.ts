import React from "react";
interface SvgIconProps {
    src?: string;
    children?: any;
    className?: string;
    width?: number | string;
    height?: number | string;
    fill?: string;
}
export default function SvgIcon({ children, src, className, width, height, fill }: SvgIconProps): React.JSX.Element | null;
export {};
