import React from "react";
import "./style.css";
export interface OptionsObjectType {
    label: string | number;
    value: string | number;
}
export interface OptionsListProps {
    referenceElement: any;
    value: (string | number)[];
    options: OptionsObjectType[];
    handleChange: any;
    handleClose: any;
    handleSearchTextChange?: any;
}
declare const OptionsList: (props: OptionsListProps) => React.JSX.Element;
export default OptionsList;
