import React from "react";
import "./style.css";
export interface FormElementMessageProps {
    text: string;
    type: 'error' | 'warning' | 'success' | 'info' | 'label' | 'labeldesc';
}
/**
 * FormElementMessage component
 */
declare const FormElementMessage: (props: FormElementMessageProps) => React.JSX.Element;
export default FormElementMessage;
