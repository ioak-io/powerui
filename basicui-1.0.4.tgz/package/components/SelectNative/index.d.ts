import React from "react";
import { OptionsObjectType } from "../shared/OptionsList";
export interface SelectNativeProps {
    initialValues?: (string | number)[];
    options: OptionsObjectType[];
    id?: string;
    label?: string;
    labelDesc?: string;
    placeholder?: string;
    tooltip?: string;
    errorMessage?: string;
    warningMessage?: string;
    successMessage?: string;
    multiple?: boolean;
    autocomplete?: boolean;
    [key: string]: any;
}
/**
 * Component to render input form element. For using it with standard html input, add css class basicui-input
 */
declare const SelectNative: ({ id, label, labelDesc, placeholder, initialValues, options, tooltip, errorMessage, warningMessage, successMessage, multiple, autocomplete, ...restProps }: SelectNativeProps) => React.JSX.Element;
export default SelectNative;
