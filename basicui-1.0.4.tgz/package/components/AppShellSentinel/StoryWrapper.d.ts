import React from "react";
import { AppShellSentinelProps } from ".";
declare const StoryWrapper: (props: AppShellSentinelProps) => React.JSX.Element;
export default StoryWrapper;
