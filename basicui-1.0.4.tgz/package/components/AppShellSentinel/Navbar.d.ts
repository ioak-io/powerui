import React from "react";
export type NavbarProps = {
    children: any;
    [key: string]: any;
};
declare const Navbar: {
    ({ children, ...props }: NavbarProps): React.JSX.Element;
    Header: {
        (props: import("./NavbarHeader").NavbarHeaderProps): React.JSX.Element;
        displayName: string;
    };
    Footer: {
        (props: import("./NavbarFooter").NavbarFooterProps): React.JSX.Element;
        displayName: string;
    };
    Body: {
        (props: import("./NavbarBody").NavbarBodyProps): React.JSX.Element;
        displayName: string;
    };
    displayName: string;
};
export default Navbar;
