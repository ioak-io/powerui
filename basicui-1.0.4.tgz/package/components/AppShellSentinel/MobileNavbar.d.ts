import React from "react";
export type NavbarProps = {
    children: any;
    [key: string]: any;
};
declare const MobileNavbar: {
    ({ children, ...props }: NavbarProps): React.JSX.Element;
    Body: {
        (props: import("./MobileNavbarBody").NavbarBodyProps): React.JSX.Element;
        displayName: string;
    };
    Footer: {
        (props: import("./MobileNavbarFooter").NavbarBodyFooterProps): React.JSX.Element;
        displayName: string;
    };
    displayName: string;
};
export default MobileNavbar;
