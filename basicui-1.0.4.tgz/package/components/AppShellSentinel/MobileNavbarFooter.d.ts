import React from "react";
export type NavbarBodyFooterProps = {
    [key: string]: any;
};
declare const MobileNavbarFooter: {
    (props: NavbarBodyFooterProps): React.JSX.Element;
    displayName: string;
};
export default MobileNavbarFooter;
