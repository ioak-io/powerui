import React from "react";
export type AppShellSentinelProps = {
    children: any;
    onSignin: any;
    onSignout: any;
    logoIconBlack: any;
    logoIconWhite: any;
    logoTextBlack: any;
    logoTextWhite: any;
    isSidebarExpanded: boolean;
    onSidebarToggle: any;
    isDarkMode: boolean;
    onDarkModeToggle: any;
    location?: any;
    hideNavbar?: boolean;
};
declare const AppShellSentinel: {
    ({ children, ...props }: AppShellSentinelProps): React.JSX.Element;
    Navbar: {
        ({ children, ...props }: import("./Navbar").NavbarProps): React.JSX.Element;
        Header: {
            (props: import("./NavbarHeader").NavbarHeaderProps): React.JSX.Element;
            displayName: string;
        };
        Footer: {
            (props: import("./NavbarFooter").NavbarFooterProps): React.JSX.Element;
            displayName: string;
        };
        Body: {
            (props: import("./NavbarBody").NavbarBodyProps): React.JSX.Element;
            displayName: string;
        };
        displayName: string;
    };
    Topbar: {
        (props: import("./Topbar").TopbarProps): React.JSX.Element;
        displayName: string;
    };
    Body: {
        (props: import("./Body").BodyProps): React.JSX.Element;
        displayName: string;
    };
    MobileNavbar: {
        ({ children, ...props }: import("./MobileNavbar").NavbarProps): React.JSX.Element;
        Body: {
            (props: import("./MobileNavbarBody").NavbarBodyProps): React.JSX.Element;
            displayName: string;
        };
        Footer: {
            (props: import("./MobileNavbarFooter").NavbarBodyFooterProps): React.JSX.Element;
            displayName: string;
        };
        displayName: string;
    };
    displayName: string;
};
export default AppShellSentinel;
