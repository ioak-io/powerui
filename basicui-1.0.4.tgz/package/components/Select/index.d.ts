import React from "react";
import { OptionsObjectType } from "../shared/OptionsList";
export interface SelectProps {
    name?: string;
    label?: string;
    labelDesc?: string;
    options: OptionsObjectType[];
    value: (string | number)[];
    placeholder?: string;
    onChange?: any;
    onInput?: any;
    multiple?: boolean;
    autocomplete?: boolean;
    allowNewValues?: boolean;
}
/**
 * Component to render drop down input form element. Supports multi select and auto complete features
 */
declare const Select: (props: SelectProps) => React.JSX.Element;
export default Select;
