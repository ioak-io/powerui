import { Meta } from '@storybook/react';
import Select, { SelectProps } from '.';
declare const meta: Meta<typeof Select>;
export default meta;
export declare const SelectForm: {
    args: {
        value: string[];
        options: import("../..").OptionsObjectType[];
        placeholder: string;
    };
    decorators?: import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        name?: string | undefined;
        label?: string | undefined;
        labelDesc?: string | undefined;
        options: import("../..").OptionsObjectType[];
        value: (string | number)[];
        placeholder?: string | undefined;
        onChange?: any;
        onInput?: any;
        multiple?: boolean | undefined;
        autocomplete?: boolean | undefined;
        allowNewValues?: boolean | undefined;
    }> | import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        name?: string | undefined;
        label?: string | undefined;
        labelDesc?: string | undefined;
        options: import("../..").OptionsObjectType[];
        value: (string | number)[];
        placeholder?: string | undefined;
        onChange?: any;
        onInput?: any;
        multiple?: boolean | undefined;
        autocomplete?: boolean | undefined;
        allowNewValues?: boolean | undefined;
    }>[] | undefined;
    parameters?: import("@storybook/types").Parameters | undefined;
    argTypes?: Partial<import("@storybook/types").ArgTypes<SelectProps>> | undefined;
    loaders?: import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, SelectProps> | import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, SelectProps>[] | undefined;
    render?: import("@storybook/types").ArgsStoryFn<import("@storybook/react/dist/types-0fc72a6d").R, SelectProps> | undefined;
    name?: string | undefined;
    storyName?: string | undefined;
    play?: import("@storybook/types").PlayFunction<import("@storybook/react/dist/types-0fc72a6d").R, SelectProps> | undefined;
    tags?: string[] | undefined;
    story?: Omit<import("@storybook/types").StoryAnnotations<import("@storybook/react/dist/types-0fc72a6d").R, SelectProps, Partial<SelectProps>>, "story"> | undefined;
};
export declare const AutocompleteForm: {
    args: {
        value: never[];
        autocomplete: boolean;
        options: import("../..").OptionsObjectType[];
        placeholder: string;
    };
    decorators?: import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        name?: string | undefined;
        label?: string | undefined;
        labelDesc?: string | undefined;
        options: import("../..").OptionsObjectType[];
        value: (string | number)[];
        placeholder?: string | undefined;
        onChange?: any;
        onInput?: any;
        multiple?: boolean | undefined;
        autocomplete?: boolean | undefined;
        allowNewValues?: boolean | undefined;
    }> | import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        name?: string | undefined;
        label?: string | undefined;
        labelDesc?: string | undefined;
        options: import("../..").OptionsObjectType[];
        value: (string | number)[];
        placeholder?: string | undefined;
        onChange?: any;
        onInput?: any;
        multiple?: boolean | undefined;
        autocomplete?: boolean | undefined;
        allowNewValues?: boolean | undefined;
    }>[] | undefined;
    parameters?: import("@storybook/types").Parameters | undefined;
    argTypes?: Partial<import("@storybook/types").ArgTypes<SelectProps>> | undefined;
    loaders?: import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, SelectProps> | import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, SelectProps>[] | undefined;
    render?: import("@storybook/types").ArgsStoryFn<import("@storybook/react/dist/types-0fc72a6d").R, SelectProps> | undefined;
    name?: string | undefined;
    storyName?: string | undefined;
    play?: import("@storybook/types").PlayFunction<import("@storybook/react/dist/types-0fc72a6d").R, SelectProps> | undefined;
    tags?: string[] | undefined;
    story?: Omit<import("@storybook/types").StoryAnnotations<import("@storybook/react/dist/types-0fc72a6d").R, SelectProps, Partial<SelectProps>>, "story"> | undefined;
};
