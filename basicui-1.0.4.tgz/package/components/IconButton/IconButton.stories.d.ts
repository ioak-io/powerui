import { Meta } from '@storybook/react';
import React from "react";
import IconButton, { IconButtonProps } from '.';
import ThemeType from '../types/ThemeType';
declare const meta: Meta<typeof IconButton>;
export default meta;
export declare const Playground: {
    args: {
        theme: ThemeType;
        children: React.JSX.Element;
    };
    decorators?: import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        [x: string]: any;
        [x: number]: any;
        ref?: React.Ref<HTMLButtonElement> | undefined;
        key?: React.Key | null | undefined;
    }> | import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        [x: string]: any;
        [x: number]: any;
        ref?: React.Ref<HTMLButtonElement> | undefined;
        key?: React.Key | null | undefined;
    }>[] | undefined;
    parameters?: import("@storybook/types").Parameters | undefined;
    argTypes?: Partial<import("@storybook/types").ArgTypes<Omit<IconButtonProps, "ref"> & React.RefAttributes<HTMLButtonElement>>> | undefined;
    loaders?: import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, Omit<IconButtonProps, "ref"> & React.RefAttributes<HTMLButtonElement>> | import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, Omit<IconButtonProps, "ref"> & React.RefAttributes<HTMLButtonElement>>[] | undefined;
    render?: import("@storybook/types").ArgsStoryFn<import("@storybook/react/dist/types-0fc72a6d").R, Omit<IconButtonProps, "ref"> & React.RefAttributes<HTMLButtonElement>> | undefined;
    name?: string | undefined;
    storyName?: string | undefined;
    play?: import("@storybook/types").PlayFunction<import("@storybook/react/dist/types-0fc72a6d").R, Omit<IconButtonProps, "ref"> & React.RefAttributes<HTMLButtonElement>> | undefined;
    tags?: string[] | undefined;
    story?: Omit<import("@storybook/types").StoryAnnotations<import("@storybook/react/dist/types-0fc72a6d").R, Omit<IconButtonProps, "ref"> & React.RefAttributes<HTMLButtonElement>, Partial<Omit<IconButtonProps, "ref"> & React.RefAttributes<HTMLButtonElement>>>, "story"> | undefined;
};
