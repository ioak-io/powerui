import React from "react";
import ButtonVariantType from "../types/ButtonVariantType";
import ThemeType from "../types/ThemeType";
export interface IconButtonProps {
    theme?: ThemeType;
    onClick?: any;
    onSubmit?: any;
    onReset?: any;
    type?: "button" | "submit" | "reset";
    variant?: ButtonVariantType;
    children: any;
    circle?: boolean;
    loading?: boolean;
    className?: string;
    [key: string]: any;
}
/**
 * Component to render drop down input form element. Supports multi select and auto complete features
 */
declare const IconButton: React.ForwardRefExoticComponent<Omit<IconButtonProps, "ref"> & React.RefAttributes<HTMLButtonElement>>;
export default IconButton;
