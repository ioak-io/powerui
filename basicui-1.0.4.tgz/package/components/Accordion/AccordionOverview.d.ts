import React from "react";
declare const AccordionOverview: () => React.JSX.Element;
export default AccordionOverview;
