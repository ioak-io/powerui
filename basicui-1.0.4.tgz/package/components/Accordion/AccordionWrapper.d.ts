import React from "react";
import { AccordionProps } from ".";
declare const AccordionWrapper: (props: AccordionProps | any) => React.JSX.Element;
export default AccordionWrapper;
