import React from "react";
import ThemeType from "../types/ThemeType";
export interface AccordionProps {
    theme?: ThemeType;
    expanded: boolean;
    onChange?: () => void;
    heading?: string;
    bordered?: boolean;
    children: React.ReactNode;
    className?: string;
    header?: React.ReactNode;
}
/**
 * Component to render an accordion with optional custom header.
 * Allows parent to fully control expand/collapse behavior.
 */
declare const Accordion: (props: AccordionProps) => React.JSX.Element;
export default Accordion;
