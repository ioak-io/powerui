import { Meta } from '@storybook/react';
import Accordion, { AccordionProps } from ".";
import ThemeType from "../types/ThemeType";
import React from 'react';
declare const meta: Meta<typeof Accordion>;
export default meta;
export declare const Playground: {
    args: {
        theme: ThemeType;
        bordered: boolean;
    };
    decorators?: import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        theme?: ThemeType | undefined;
        expanded: boolean;
        onChange?: (() => void) | undefined;
        heading?: string | undefined;
        bordered?: boolean | undefined;
        children: React.ReactNode;
        className?: string | undefined;
        header?: React.ReactNode;
    }> | import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        theme?: ThemeType | undefined;
        expanded: boolean;
        onChange?: (() => void) | undefined;
        heading?: string | undefined;
        bordered?: boolean | undefined;
        children: React.ReactNode;
        className?: string | undefined;
        header?: React.ReactNode;
    }>[] | undefined;
    parameters?: import("@storybook/types").Parameters | undefined;
    argTypes?: Partial<import("@storybook/types").ArgTypes<AccordionProps>> | undefined;
    loaders?: import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, AccordionProps> | import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, AccordionProps>[] | undefined;
    render?: import("@storybook/types").ArgsStoryFn<import("@storybook/react/dist/types-0fc72a6d").R, AccordionProps> | undefined;
    name?: string | undefined;
    storyName?: string | undefined;
    play?: import("@storybook/types").PlayFunction<import("@storybook/react/dist/types-0fc72a6d").R, AccordionProps> | undefined;
    tags?: string[] | undefined;
    story?: Omit<import("@storybook/types").StoryAnnotations<import("@storybook/react/dist/types-0fc72a6d").R, AccordionProps, Partial<AccordionProps>>, "story"> | undefined;
};
