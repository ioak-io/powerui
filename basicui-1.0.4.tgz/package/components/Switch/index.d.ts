import React from "react";
import "./style.css";
import ThemeType from "../types/ThemeType";
import SwitchSizeType from "../types/SwitchSizeType";
export interface SwitchProps {
    id: string;
    theme?: ThemeType;
    size: SwitchSizeType;
    checked?: boolean;
    [key: string]: any;
    icon: [any, any];
}
/**
 * Component to render switch form element. For using it with standard html input, add css class basicui-input
 */
declare const Switch: ({ id, label, theme, size, checked, icon, ...restProps }: SwitchProps) => React.JSX.Element;
export default Switch;
