import { Meta } from '@storybook/react';
import SearchBar, { SearchBarProps } from '.';
declare const meta: Meta<typeof SearchBar>;
export default meta;
export declare const Playground: {
    args: {
        onSearch: (data: {
            searchText: string;
            filters: {
                fieldName: string;
                selectedValueList: (string | number)[];
            }[];
        }) => void;
        filters: import("../..").SearchBarFilterType[];
        placeholder?: string | undefined;
    };
    decorators?: import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        onSearch: (data: {
            searchText: string;
            filters: {
                fieldName: string;
                selectedValueList: (string | number)[];
            }[];
        }) => void;
        filters: import("../..").SearchBarFilterType[];
        placeholder?: string | undefined;
    }> | import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        onSearch: (data: {
            searchText: string;
            filters: {
                fieldName: string;
                selectedValueList: (string | number)[];
            }[];
        }) => void;
        filters: import("../..").SearchBarFilterType[];
        placeholder?: string | undefined;
    }>[] | undefined;
    parameters?: import("@storybook/types").Parameters | undefined;
    argTypes?: Partial<import("@storybook/types").ArgTypes<SearchBarProps>> | undefined;
    loaders?: import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, SearchBarProps> | import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, SearchBarProps>[] | undefined;
    render?: import("@storybook/types").ArgsStoryFn<import("@storybook/react/dist/types-0fc72a6d").R, SearchBarProps> | undefined;
    name?: string | undefined;
    storyName?: string | undefined;
    play?: import("@storybook/types").PlayFunction<import("@storybook/react/dist/types-0fc72a6d").R, SearchBarProps> | undefined;
    tags?: string[] | undefined;
    story?: Omit<import("@storybook/types").StoryAnnotations<import("@storybook/react/dist/types-0fc72a6d").R, SearchBarProps, Partial<SearchBarProps>>, "story"> | undefined;
};
