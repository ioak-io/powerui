import React from "react";
export type LogoProps = {
    isDarkMode: boolean;
    showText: boolean;
    logoIconBlack: any;
    logoIconWhite: any;
    logoTextBlack: any;
    logoTextWhite: any;
};
declare const Logo: (props: LogoProps) => React.JSX.Element;
export default Logo;
