import React from "react";
export type AppShellRevealProps = {
    children: any;
    userName?: string;
    onSignin: any;
    onSignout: any;
    logoIconBlack: any;
    logoIconWhite: any;
    logoTextBlack: any;
    logoTextWhite: any;
    isMenuActive: boolean;
    setIsMenuActive: any;
    isDarkMode: boolean;
    onDarkModeToggle: any;
    location?: any;
    hideNavbar?: boolean;
};
declare const AppShellReveal: {
    ({ children, ...props }: AppShellRevealProps): React.JSX.Element;
    Navbar: {
        ({ children, ...props }: import("./Navbar").NavbarProps): React.JSX.Element;
        displayName: string;
    };
    Topbar: {
        (props: import("./Topbar").TopbarProps): React.JSX.Element;
        displayName: string;
    };
    Body: {
        (props: import("./Body").BodyProps): React.JSX.Element;
        displayName: string;
    };
    MobileNavbar: {
        ({ children, ...props }: import("./MobileNavbar").NavbarProps): React.JSX.Element;
        displayName: string;
    };
    displayName: string;
};
export default AppShellReveal;
