import React from "react";
export type NavbarProps = {
    children: any;
    [key: string]: any;
};
declare const MobileNavbar: {
    ({ children, ...props }: NavbarProps): React.JSX.Element;
    displayName: string;
};
export default MobileNavbar;
