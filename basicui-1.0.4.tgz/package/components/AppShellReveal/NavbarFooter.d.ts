import React from "react";
export type NavbarFooterProps = {
    children?: any;
    userName?: string;
    [key: string]: any;
};
declare const NavbarFooter: {
    (props: NavbarFooterProps): React.JSX.Element;
    displayName: string;
};
export default NavbarFooter;
