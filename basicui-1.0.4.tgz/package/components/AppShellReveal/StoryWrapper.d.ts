import React from "react";
import { AppShellRevealProps } from ".";
declare const StoryWrapper: (props: AppShellRevealProps) => React.JSX.Element;
export default StoryWrapper;
