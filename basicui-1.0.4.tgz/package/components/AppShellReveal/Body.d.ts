import React from "react";
export type BodyProps = {
    children?: any;
    [key: string]: any;
};
declare const Body: {
    (props: BodyProps): React.JSX.Element;
    displayName: string;
};
export default Body;
