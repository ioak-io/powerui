import React from "react";
export type NavbarHeaderProps = {
    children?: any;
    [key: string]: any;
};
declare const NavbarHeader: {
    (props: NavbarHeaderProps): React.JSX.Element;
    displayName: string;
};
export default NavbarHeader;
