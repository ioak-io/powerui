import React from "react";
export type TopbarProps = {
    children?: any;
    [key: string]: any;
};
declare const Topbar: {
    (props: TopbarProps): React.JSX.Element;
    displayName: string;
};
export default Topbar;
