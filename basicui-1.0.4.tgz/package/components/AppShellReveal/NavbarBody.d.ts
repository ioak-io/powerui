import React from "react";
export type NavbarBodyProps = {
    children: any;
    [key: string]: any;
};
declare const NavbarBody: {
    (props: NavbarBodyProps): React.JSX.Element;
    displayName: string;
};
export default NavbarBody;
