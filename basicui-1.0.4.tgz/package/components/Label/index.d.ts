import React from "react";
export type LabelProps = {
    children: any;
    labelDesc?: string;
};
/**
 * Component to render input form element. For using it with standard html input, add css class basicui-input
 */
declare const Label: (props: LabelProps) => React.JSX.Element;
export default Label;
