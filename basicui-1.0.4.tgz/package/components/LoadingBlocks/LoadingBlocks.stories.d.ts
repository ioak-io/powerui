import { Meta } from "@storybook/react";
import LoadingBlocks, { LoadingBlocksProps } from ".";
declare const meta: Meta<typeof LoadingBlocks>;
export default meta;
export declare const Playground: {
    args: {
        numberOfBlocks: number;
        isLoading: boolean;
        minWidth: number;
        maxWidth: number;
    };
    decorators?: import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        numberOfBlocks: number;
        isStatic?: boolean | undefined;
        minWidth: number;
        maxWidth: number;
    }> | import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        numberOfBlocks: number;
        isStatic?: boolean | undefined;
        minWidth: number;
        maxWidth: number;
    }>[] | undefined;
    parameters?: import("@storybook/types").Parameters | undefined;
    argTypes?: Partial<import("@storybook/types").ArgTypes<LoadingBlocksProps>> | undefined;
    loaders?: import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, LoadingBlocksProps> | import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, LoadingBlocksProps>[] | undefined;
    render?: import("@storybook/types").ArgsStoryFn<import("@storybook/react/dist/types-0fc72a6d").R, LoadingBlocksProps> | undefined;
    name?: string | undefined;
    storyName?: string | undefined;
    play?: import("@storybook/types").PlayFunction<import("@storybook/react/dist/types-0fc72a6d").R, LoadingBlocksProps> | undefined;
    tags?: string[] | undefined;
    story?: Omit<import("@storybook/types").StoryAnnotations<import("@storybook/react/dist/types-0fc72a6d").R, LoadingBlocksProps, Partial<LoadingBlocksProps>>, "story"> | undefined;
};
