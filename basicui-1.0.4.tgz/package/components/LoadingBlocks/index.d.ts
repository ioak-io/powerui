import React from "react";
export type LoadingBlocksProps = {
    numberOfBlocks: number;
    isStatic?: boolean;
    minWidth: number;
    maxWidth: number;
};
/**
 * Component to show loading indication on a page
 */
declare const LoadingBlocks: React.FC<LoadingBlocksProps>;
export default LoadingBlocks;
