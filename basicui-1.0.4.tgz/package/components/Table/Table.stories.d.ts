import { Meta } from '@storybook/react';
import Table, { TableProps } from '.';
declare const meta: Meta<typeof Table>;
export default meta;
export declare const Playground: {
    args: {
        inverseHeaders: boolean;
    };
    decorators?: import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        theme?: import("../types/ThemeType").default | undefined;
        inverse?: boolean | undefined;
        inverseHeader?: boolean | undefined;
        striped?: boolean | undefined;
        hover?: boolean | undefined;
        bordered?: boolean | undefined;
        small?: boolean | undefined;
    }> | import("@storybook/types").DecoratorFunction<import("@storybook/react/dist/types-0fc72a6d").R, {
        theme?: import("../types/ThemeType").default | undefined;
        inverse?: boolean | undefined;
        inverseHeader?: boolean | undefined;
        striped?: boolean | undefined;
        hover?: boolean | undefined;
        bordered?: boolean | undefined;
        small?: boolean | undefined;
    }>[] | undefined;
    parameters?: import("@storybook/types").Parameters | undefined;
    argTypes?: Partial<import("@storybook/types").ArgTypes<TableProps>> | undefined;
    loaders?: import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, TableProps> | import("@storybook/types").LoaderFunction<import("@storybook/react/dist/types-0fc72a6d").R, TableProps>[] | undefined;
    render?: import("@storybook/types").ArgsStoryFn<import("@storybook/react/dist/types-0fc72a6d").R, TableProps> | undefined;
    name?: string | undefined;
    storyName?: string | undefined;
    play?: import("@storybook/types").PlayFunction<import("@storybook/react/dist/types-0fc72a6d").R, TableProps> | undefined;
    tags?: string[] | undefined;
    story?: Omit<import("@storybook/types").StoryAnnotations<import("@storybook/react/dist/types-0fc72a6d").R, TableProps, Partial<TableProps>>, "story"> | undefined;
};
