import React from "react";
import ThemeType from "../types/ThemeType";
export type TableWrapperProps = {
    theme?: ThemeType;
    inverse?: boolean;
    inverseHeader?: boolean;
    striped?: boolean;
    hover?: boolean;
    bordered?: boolean;
    small?: boolean;
};
/**
 * Component to render drop down input form element. Supports multi select and auto complete features
 */
declare const TableWrapper: (props: TableWrapperProps) => React.JSX.Element;
export default TableWrapper;
