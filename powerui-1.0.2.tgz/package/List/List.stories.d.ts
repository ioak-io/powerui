import { Meta } from '@storybook/react';
import ListWrapper from './ListWrapper';
declare const meta: Meta<typeof ListWrapper>;
export default meta;
export declare const Playground: {
    args: {
        renderFromChildren: boolean;
    };
    decorators?: import("@storybook/types").DecoratorFunction<import("@storybook/react").ReactRenderer, {
        renderFromChildren: boolean;
        showSelectOnRight: boolean;
        showCollapse: boolean;
    }> | import("@storybook/types").DecoratorFunction<import("@storybook/react").ReactRenderer, {
        renderFromChildren: boolean;
        showSelectOnRight: boolean;
        showCollapse: boolean;
    }>[] | undefined;
    parameters?: import("@storybook/types").Parameters;
    argTypes?: Partial<import("@storybook/types").ArgTypes<{
        renderFromChildren: boolean;
        showSelectOnRight: boolean;
        showCollapse: boolean;
    }>> | undefined;
    loaders?: import("@storybook/types").LoaderFunction<import("@storybook/react").ReactRenderer, {
        renderFromChildren: boolean;
        showSelectOnRight: boolean;
        showCollapse: boolean;
    }> | import("@storybook/types").LoaderFunction<import("@storybook/react").ReactRenderer, {
        renderFromChildren: boolean;
        showSelectOnRight: boolean;
        showCollapse: boolean;
    }>[] | undefined;
    render?: import("@storybook/types").ArgsStoryFn<import("@storybook/react").ReactRenderer, {
        renderFromChildren: boolean;
        showSelectOnRight: boolean;
        showCollapse: boolean;
    }> | undefined;
    name?: import("@storybook/types").StoryName;
    storyName?: import("@storybook/types").StoryName;
    play?: import("@storybook/types").PlayFunction<import("@storybook/react").ReactRenderer, {
        renderFromChildren: boolean;
        showSelectOnRight: boolean;
        showCollapse: boolean;
    }> | undefined;
    tags?: import("@storybook/types").Tag[];
    story?: Omit<import("@storybook/types").StoryAnnotations<import("@storybook/react").ReactRenderer, {
        renderFromChildren: boolean;
        showSelectOnRight: boolean;
        showCollapse: boolean;
    }, Partial<{
        renderFromChildren: boolean;
        showSelectOnRight: boolean;
        showCollapse: boolean;
    }>>, "story"> | undefined;
};
