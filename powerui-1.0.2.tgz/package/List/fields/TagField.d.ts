import React from 'react';
import './TagField.css';
import { FieldComponentProps } from '../FieldComponentProps';
declare const TagField: React.FC<FieldComponentProps>;
export default TagField;
