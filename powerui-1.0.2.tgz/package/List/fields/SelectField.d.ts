import React from 'react';
import './SelectField.css';
import { FieldComponentProps } from '../FieldComponentProps';
declare const SelectField: React.FC<FieldComponentProps>;
export default SelectField;
