import React from 'react';
import './TextField.css';
import { FieldComponentProps } from '../FieldComponentProps';
declare const TextField: React.FC<FieldComponentProps>;
export default TextField;
