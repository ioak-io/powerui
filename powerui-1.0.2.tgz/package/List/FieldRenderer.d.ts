import React from 'react';
import { FieldComponentProps } from './FieldComponentProps';
import './FieldRenderer.css';
export declare const BASE_CLASS_FIELD_RENDERER_SHARED = "powerui-list-fieldrenderer-shared";
declare const FieldRenderer: React.FC<FieldComponentProps>;
export default FieldRenderer;
