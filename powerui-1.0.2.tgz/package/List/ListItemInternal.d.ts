import React from "react";
import { SpecDefinition } from "../types/DynamicFormTypes";
export interface ListItemInternalProps {
    selectedItems?: string[];
    onClick?: (id: string) => void;
    onSelect?: (event: any) => void;
    specDefinition: SpecDefinition;
    data: Record<string, any>;
    children?: React.ReactNode;
    showSelectOnRight?: boolean;
}
declare const ListItemInternal: (props: ListItemInternalProps) => React.JSX.Element;
export default ListItemInternal;
