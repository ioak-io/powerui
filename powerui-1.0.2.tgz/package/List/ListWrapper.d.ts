import React from "react";
import { FormSchema } from "../types/uispec.types";
export declare const listSchema: FormSchema;
declare const ListWrapper: (props: {
    renderFromChildren: boolean;
    showSelectOnRight: boolean;
    showCollapse: boolean;
}) => React.JSX.Element;
export default ListWrapper;
