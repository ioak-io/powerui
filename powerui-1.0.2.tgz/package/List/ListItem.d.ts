import React from 'react';
import './ListItem.css';
import { ListSchema } from '../types/uispec.types';
interface ListItemProps {
    data: Record<string, any>;
    schema: ListSchema;
    onClick?: () => void;
    onCheck?: (checked: boolean) => void;
    isChecked?: boolean;
}
declare const ListItem: React.FC<ListItemProps>;
export default ListItem;
