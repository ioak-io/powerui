import React from 'react';
import './ActionBar.css';
import { FormAction, FormSchema } from '../../types/uispec.types';
interface ActionBarProps {
    schema: FormSchema;
    onClick?: () => void;
    onCheck?: (checked: boolean) => void;
    isChecked?: boolean;
    onActionClick?: (e: FormAction) => Promise<void>;
}
declare const ActionBar: React.FC<ActionBarProps>;
export default ActionBar;
