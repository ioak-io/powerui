import React from 'react';
import './style.css';
import { FormAction, FormSchema } from '../../types/uispec.types';
interface ListItemProps {
    data: Record<string, any>;
    schema: FormSchema;
    onClick?: () => void;
    onCheck?: (checked: boolean) => void;
    isChecked?: boolean;
    onActionClick?: (e: FormAction, reference: string) => Promise<void>;
}
declare const ListItem: React.FC<ListItemProps>;
export default ListItem;
