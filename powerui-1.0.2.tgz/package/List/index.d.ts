import React, { ReactNode } from 'react';
import './style.css';
import { FormAction, FormSchema } from '../types/uispec.types';
interface ListProps {
    listSchema: FormSchema;
    data: Record<string, any>[];
    actions?: ReactNode[];
    onActionClick?: (e: FormAction, reference: string) => Promise<void>;
    checkedItems: string[];
    setCheckedItems?: (items: string[]) => void;
    onItemClick?: (itemReference: string) => void;
}
declare const List: React.FC<ListProps>;
export default List;
