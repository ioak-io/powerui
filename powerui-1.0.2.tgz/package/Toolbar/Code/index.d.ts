import './style.css';
import React from 'react';
import { ToolbarPluginPropsType } from '../ToolbarPluginPropsType';
declare const Code: ({ editor }: ToolbarPluginPropsType) => React.JSX.Element;
export default Code;
