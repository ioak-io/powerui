import './style.css';
import React from 'react';
import { ToolbarPluginPropsType } from '../ToolbarPluginPropsType';
declare const AddTable: ({ editor, onContextBarChange, ...props }: ToolbarPluginPropsType) => React.JSX.Element;
export default AddTable;
