import './style.css';
import React from 'react';
export type GridSizeProps = {
    onApply: any;
    onCancel: any;
};
declare const GridSize: (props: GridSizeProps) => React.JSX.Element;
export default GridSize;
