import './style.css';
import React from 'react';
import { ToolbarPluginPropsType } from '../ToolbarPluginPropsType';
declare const Link: ({ editor }: ToolbarPluginPropsType) => React.JSX.Element;
export default Link;
