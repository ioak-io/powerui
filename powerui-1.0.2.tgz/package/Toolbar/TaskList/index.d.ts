import './style.css';
import React from 'react';
import { ToolbarPluginPropsType } from '../ToolbarPluginPropsType';
declare const TaskList: ({ editor }: ToolbarPluginPropsType) => React.JSX.Element;
export default TaskList;
