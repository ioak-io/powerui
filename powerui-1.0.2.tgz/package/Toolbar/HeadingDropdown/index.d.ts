import './style.css';
import React from 'react';
import { ToolbarPluginPropsType } from '../ToolbarPluginPropsType';
declare const HeadingDropdown: ({ editor }: ToolbarPluginPropsType) => React.JSX.Element;
export default HeadingDropdown;
