import './style.css';
import React from 'react';
import { ToolbarPluginPropsType } from '../ToolbarPluginPropsType';
declare const BulletList: ({ editor }: ToolbarPluginPropsType) => React.JSX.Element;
export default BulletList;
