import './style.css';
import React from 'react';
import { ToolbarPluginPropsType } from '../ToolbarPluginPropsType';
declare const AlignLeft: ({ editor }: ToolbarPluginPropsType) => React.JSX.Element;
export default AlignLeft;
