import './style.css';
import React from 'react';
import { ToolbarPluginPropsType } from '../ToolbarPluginPropsType';
declare const Italic: ({ editor }: ToolbarPluginPropsType) => React.JSX.Element;
export default Italic;
