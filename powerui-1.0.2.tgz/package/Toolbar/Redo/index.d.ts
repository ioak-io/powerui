import './style.css';
import React from 'react';
import { ToolbarPluginPropsType } from '../ToolbarPluginPropsType';
declare const Redo: ({ editor }: ToolbarPluginPropsType) => React.JSX.Element;
export default Redo;
