import './style.css';
import React from 'react';
export type TableContextActionsProps = {
    editor: any;
};
declare const TableContextActions: (props: TableContextActionsProps) => React.JSX.Element;
export default TableContextActions;
