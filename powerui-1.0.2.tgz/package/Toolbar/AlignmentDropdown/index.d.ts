import './style.css';
import React from 'react';
import { ToolbarPluginPropsType } from '../ToolbarPluginPropsType';
declare const AlignmentDropdown: ({ editor }: ToolbarPluginPropsType) => React.JSX.Element;
export default AlignmentDropdown;
