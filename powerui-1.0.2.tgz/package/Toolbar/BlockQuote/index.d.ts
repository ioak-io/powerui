import './style.css';
import React from 'react';
import { ToolbarPluginPropsType } from '../ToolbarPluginPropsType';
declare const BlockQuote: ({ editor }: ToolbarPluginPropsType) => React.JSX.Element;
export default BlockQuote;
