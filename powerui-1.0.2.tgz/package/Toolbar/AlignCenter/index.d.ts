import './style.css';
import React from 'react';
import { ToolbarPluginPropsType } from '../ToolbarPluginPropsType';
declare const AlignCenter: ({ editor }: ToolbarPluginPropsType) => React.JSX.Element;
export default AlignCenter;
