import './contextbar.css';
import './style.css';
import React from 'react';
export type ToolbarProps = {
    editor: any;
    placement?: 'top' | 'bottom';
    children: any;
    onContextBarChange: any;
};
declare const Toolbar: ({ editor, placement, children, ...props }: ToolbarProps) => React.JSX.Element | null;
export default Toolbar;
