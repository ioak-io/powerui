import './style.css';
import React from 'react';
import { ToolbarPluginPropsType } from '../ToolbarPluginPropsType';
declare const Subscript: ({ editor }: ToolbarPluginPropsType) => React.JSX.Element;
export default Subscript;
