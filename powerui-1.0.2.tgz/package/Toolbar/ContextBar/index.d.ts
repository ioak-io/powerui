import './style.css';
import React from 'react';
export type ContextBarProps = {
    editor: any;
    content: any;
};
declare const ContextBar: (props: ContextBarProps) => React.JSX.Element;
export default ContextBar;
