import './style.css';
import React from 'react';
import { ToolbarPluginPropsType } from '../ToolbarPluginPropsType';
declare const AlignJustify: ({ editor }: ToolbarPluginPropsType) => React.JSX.Element;
export default AlignJustify;
