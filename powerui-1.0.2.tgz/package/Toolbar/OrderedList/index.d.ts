import './style.css';
import React from 'react';
import { ToolbarPluginPropsType } from '../ToolbarPluginPropsType';
declare const OrderedList: ({ editor }: ToolbarPluginPropsType) => React.JSX.Element;
export default OrderedList;
