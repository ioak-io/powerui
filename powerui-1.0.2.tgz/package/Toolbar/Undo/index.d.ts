import './style.css';
import React from 'react';
import { ToolbarPluginPropsType } from '../ToolbarPluginPropsType';
declare const Undo: ({ editor }: ToolbarPluginPropsType) => React.JSX.Element;
export default Undo;
