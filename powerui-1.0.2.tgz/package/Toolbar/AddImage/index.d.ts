import './style.css';
import React from 'react';
export type AddImagePluginProps = {
    editor: any;
    imageUploadURL: string;
    imageUploadParam: string;
    imageUploadMethod: string;
};
declare const AddImage: ({ editor, ...props }: AddImagePluginProps) => React.JSX.Element;
export default AddImage;
