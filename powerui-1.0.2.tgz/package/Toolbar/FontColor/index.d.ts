import './style.css';
import React from 'react';
import { ToolbarPluginPropsType } from '../ToolbarPluginPropsType';
declare const FontColor: ({ editor }: ToolbarPluginPropsType) => React.JSX.Element;
export default FontColor;
