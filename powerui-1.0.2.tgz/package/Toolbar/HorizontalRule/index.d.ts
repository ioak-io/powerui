import './style.css';
import React from 'react';
import { ToolbarPluginPropsType } from '../ToolbarPluginPropsType';
declare const HorizontalRule: ({ editor }: ToolbarPluginPropsType) => React.JSX.Element;
export default HorizontalRule;
