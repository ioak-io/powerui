import './style.css';
import React from 'react';
import { ToolbarPluginPropsType } from '../ToolbarPluginPropsType';
declare const ClearFormatting: ({ editor }: ToolbarPluginPropsType) => React.JSX.Element;
export default ClearFormatting;
