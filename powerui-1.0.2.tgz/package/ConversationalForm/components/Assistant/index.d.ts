import React from "react";
import "./style.css";
export type AssistantProps = {
    pendingAction?: {
        assistantId: string;
        initialText: string;
    };
    onCancel: () => void;
    onUpdate: (e: string) => void;
    onAssist: (assistantId: string, text: string, instruction: string, { onOpen, onMessage, onDone, onError, }: {
        onOpen?: () => void;
        onMessage: (msg: string) => void;
        onDone?: () => void;
        onError?: (err: any) => void;
    }) => Promise<void>;
};
declare const Assistant: (props: AssistantProps) => React.JSX.Element;
export default Assistant;
