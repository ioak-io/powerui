import React from 'react';
import './ChatBubble.css';
interface ChatBubbleProps {
    isEdit: boolean;
    onEdit: () => void;
    onCancel: () => void;
    children: React.ReactNode;
    role?: "default" | "reply";
    disabled?: boolean;
}
declare const ChatBubble: React.FC<ChatBubbleProps>;
export default ChatBubble;
