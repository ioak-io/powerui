import React from 'react';
import './MessageSection.css';
import { FieldValidation } from "../../../types/uispec.types";
interface MessageSectionProps {
    errors: string[];
    validation: FieldValidation | undefined;
    validationOutcome: Record<string, boolean>;
}
declare const MessageSection: React.FC<MessageSectionProps>;
export default MessageSection;
