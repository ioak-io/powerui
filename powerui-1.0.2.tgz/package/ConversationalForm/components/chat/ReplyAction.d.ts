import React from 'react';
import './ReplyAction.css';
interface ReplyActionProps {
    onSave: () => void;
    onCancel: () => void;
    onAssist?: () => void;
}
declare const ReplyAction: React.FC<ReplyActionProps>;
export default ReplyAction;
