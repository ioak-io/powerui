import { FieldValidation } from "../../../types/uispec.types";
export declare const requiredCheck: (validationSpec: FieldValidation | undefined, value: string | number) => boolean;
