import React from 'react';
import { FieldComponentProps } from '../../FieldComponentProps';
import './TextField.css';
declare const TextField: React.FC<FieldComponentProps>;
export default TextField;
