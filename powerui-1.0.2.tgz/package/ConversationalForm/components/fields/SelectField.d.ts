import React from 'react';
import { FieldComponentProps } from '../../FieldComponentProps';
import './SelectField.css';
declare const SelectField: React.FC<FieldComponentProps>;
export default SelectField;
