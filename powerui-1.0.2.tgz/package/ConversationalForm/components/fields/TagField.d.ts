import React from 'react';
import { FieldComponentProps } from '../../FieldComponentProps';
import './TagField.css';
declare const TagField: React.FC<FieldComponentProps>;
export default TagField;
