import React from 'react';
import { FormFieldSchema } from '../../../types/uispec.types';
import './ArrayField.css';
interface ArrayFieldProps {
    field: FormFieldSchema;
    fieldPath: string;
    value: any[];
    onChange: (val: any[]) => void;
    isEven?: boolean;
    editField: string | undefined;
    onStartEdit: (e?: string) => void;
    onFinishEdit: () => void;
    onCancelEdit: () => void;
}
declare const ArrayField: React.FC<ArrayFieldProps>;
export default ArrayField;
