import React from 'react';
import { FormFieldSchema } from '../../../types/uispec.types';
import './GroupField.css';
interface GroupFieldProps {
    field: FormFieldSchema;
    fieldPath: string;
    value: any;
    onChange: (val: any) => void;
    isEven?: boolean;
    editField: string | undefined;
    onStartEdit: (e?: string) => void;
    onFinishEdit: () => void;
    onCancelEdit: () => void;
}
declare const GroupField: React.FC<GroupFieldProps>;
export default GroupField;
