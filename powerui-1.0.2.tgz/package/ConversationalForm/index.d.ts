import React, { ReactNode } from 'react';
import { FormSchema } from '../types/uispec.types';
import './style.css';
interface NestedChatFormProps {
    schema: FormSchema;
    formData: any;
    onChange: (data: any) => void;
    actions?: ReactNode;
    errorMap?: Record<string, string[]>;
    onAssist?: (assistantId: string, text: string, instruction: string, { onOpen, onMessage, onDone, onError, }: {
        onOpen?: () => void;
        onMessage: (msg: string) => void;
        onDone?: () => void;
        onError?: (err: any) => void;
    }) => Promise<void>;
}
declare const NestedChatForm: React.FC<NestedChatFormProps>;
export default NestedChatForm;
