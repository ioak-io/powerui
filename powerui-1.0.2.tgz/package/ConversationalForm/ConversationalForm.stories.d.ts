import { Meta, StoryObj } from '@storybook/react';
import ConversationalFormDemo from './ConversationalFormDemo';
declare const meta: Meta<typeof ConversationalFormDemo>;
export default meta;
type Story = StoryObj<typeof ConversationalFormDemo>;
export declare const Demo: Story;
