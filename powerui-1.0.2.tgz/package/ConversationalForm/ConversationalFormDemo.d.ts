import React from 'react';
import './ConversationalFormDemo.css';
declare const ConversationalFormDemo: () => React.JSX.Element;
export default ConversationalFormDemo;
