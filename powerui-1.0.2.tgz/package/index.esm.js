import React$1, { useState, useEffect, useRef, useMemo } from 'react';
import { EditorContent, useEditor } from '@tiptap/react';
import require$$1 from 'react-dom';
import StarterKit from '@tiptap/starter-kit';
import Color from '@tiptap/extension-color';
import FontFamily from '@tiptap/extension-font-family';
import TextStyle from '@tiptap/extension-text-style';
import TextAlign from '@tiptap/extension-text-align';
import Underline$1 from '@tiptap/extension-underline';
import Image from '@tiptap/extension-image';
import Table from '@tiptap/extension-table';
import TableCell from '@tiptap/extension-table-cell';
import TableHeader from '@tiptap/extension-table-header';
import TableRow from '@tiptap/extension-table-row';
import Youtube from '@tiptap/extension-youtube';
import Highlight from '@tiptap/extension-highlight';
import Typography from '@tiptap/extension-typography';
import TaskItem from '@tiptap/extension-task-item';
import TaskList from '@tiptap/extension-task-list';
import Subscript from '@tiptap/extension-subscript';
import Superscript from '@tiptap/extension-superscript';
import Link from '@tiptap/extension-link';

/******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
/* global Reflect, Promise, SuppressedError, Symbol, Iterator */


var __assign$1 = function() {
    __assign$1 = Object.assign || function __assign(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign$1.apply(this, arguments);
};

function __rest$1(s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
}

function __awaiter$1(thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}

function __generator$1(thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
}

function __spreadArray$1(to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
}

typeof SuppressedError === "function" ? SuppressedError : function (error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
};

function styleInject$1(css, ref) {
  if ( ref === void 0 ) ref = {};
  var insertAt = ref.insertAt;

  if (!css || typeof document === 'undefined') { return; }

  var head = document.head || document.getElementsByTagName('head')[0];
  var style = document.createElement('style');
  style.type = 'text/css';

  if (insertAt === 'top') {
    if (head.firstChild) {
      head.insertBefore(style, head.firstChild);
    } else {
      head.appendChild(style);
    }
  } else {
    head.appendChild(style);
  }

  if (style.styleSheet) {
    style.styleSheet.cssText = css;
  } else {
    style.appendChild(document.createTextNode(css));
  }
}

var css_248z$K = ".powerui-contextbar .powerui-contextbar-content {\n    padding: 10px 10px;\n    padding: 4px;\n    display: flex;\n    flex-direction: row;\n    flex-wrap: wrap;\n    justify-content: flex-end;\n    /* overflow-x: auto; */\n    background-color: var(--powerui-contextbar-background-color);\n    border-radius: 0 0 0 0;\n    /* border-top: 1px solid var(--powerui-border-color);\n    border-bottom: none; */\n    grid-gap: 4px;\n}\n\n.powerui-contextbar .powerui-contextbar-content button {\n    background-color: var(--powerui-contextbar-background-color);\n}\n\n.powerui-contextbar .powerui-contextbar-content button:hover,\n.powerui-contextbar .powerui-contextbar-content button:focus {\n    background-color: var(--powerui-contextbar-button-background-color-hover);\n}\n\n/* .powerui-editor--toolbar-placement-top .powerui-contextbar .powerui-contextbar-content {\n    border-radius: 0 0 var(--powerui-border-radius) var(--powerui-border-radius);\n} */\n\n.powerui-contextbar .powerui-contextbar-content button svg {\n    fill: var(--powerui-color);\n    height: 12px;\n}\n\n\n.powerui-contextbar .powerui-contextbar-content input {\n    font-size: 12px;\n    width: 64px;\n    height: 30px;\n    padding: 0 10px;\n    background-color: var(--powerui-contextbar-background-color);\n    color: var(--powerui-color);\n    border: 1px solid var(--powerui-border-color-strong);\n    border-radius: var(--powerui-button-border-radius);\n    outline: none;\n}\n";
styleInject$1(css_248z$K);

var css_248z$J = ".powerui-toolbar {\n    display: flex;\n    flex-direction: column;\n}\n\n.powerui-toolbar-main {\n    padding: 10px 10px;\n    display: flex;\n    flex-direction: row;\n    flex-wrap: wrap;\n    /* overflow-x: auto; */\n    background-color: var(--powerui-background-color);\n    border-radius: var(--powerui-border-radius) var(--powerui-border-radius) 0 0;\n    border-bottom: 1px solid var(--powerui-border-color);\n    grid-gap: 4px;\n}\n\n.powerui-toolbar--placement-bottom .powerui-toolbar-main {\n    border-top: 1px solid var(--powerui-border-color);\n    border-bottom: none;\n    border-radius: 0 0 var(--powerui-border-radius) var(--powerui-border-radius);\n}\n\n.powerui-toolbar-main button {\n    display: flex;\n    justify-content: center;\n    align-items: center;\n    min-width: 30px;\n    height: 30px;\n    background-color: transparent;\n    color: var(--powerui-color);\n    border: none;\n    border-radius: var(--powerui-button-border-radius);\n    cursor: pointer;\n    transition: 250ms background-color ease-in-out, 250ms color ease-in-out;\n}\n\n.powerui-toolbar-main button:disabled {\n    color: var(--powerui-toolbar-button-color-disabled);\n}\n\n.powerui-toolbar-main button:disabled svg {\n    fill: var(--powerui-toolbar-button-color-disabled);\n}\n\n.powerui-toolbar-main button svg {\n    fill: var(--powerui-color);\n    /* padding: 3px; */\n    height: 12px;\n}\n\n\n.powerui-toolbar-main button.is-active {\n    background-color: var(--powerui-toolbar-button-background-color-active);\n    color: var(--powerui-toolbar-button-color-active);\n}\n\n.powerui-toolbar-main button:hover,\n.powerui-toolbar-main button:focus {\n    background-color: var(--powerui-toolbar-button-background-color-hover);\n    color: var(--powerui-toolbar-button-color-hover);\n}\n\n.color-picker {\n    width: 30px;\n    height: 30px;\n    display: flex;\n    justify-content: center;\n    align-items: center;\n}\n\ninput[type=\"color\"] {\n    -webkit-appearance: none;\n    -moz-appearance: none;\n    appearance: none;\n    width: 20px;\n    height: 16px;\n    background-color: transparent;\n    border: none;\n    cursor: pointer;\n}\n\ninput[type=\"color\"]::-webkit-color-swatch-wrapper {\n    padding: 0;\n}\n\ninput[type=\"color\"]::-webkit-color-swatch {\n    border-radius: 2px;\n    border: none;\n}\n\ninput[type=\"color\"]::-moz-color-swatch {\n    border-radius: 2px;\n    border: none;\n}\n\n.heading-select {\n    height: 30px;\n    background-color: inherit;\n    color: inherit;\n    outline: none;\n    border: none;\n    border-radius: var(--powerui-button-border-radius);\n}\n\n.heading-select:hover,\n.heading-select:focus {\n    background-color: var(--powerui-toolbar-button-background-color-hover);\n    color: var(--powerui-toolbar-button-color-hover);\n}\n\n.heading-select.is-active {\n    background-color: var(--powerui-toolbar-button-background-color-active);\n    color: var(--powerui-toolbar-button-color-active);\n}\n\nul[data-type=\"taskList\"] li {\n    display: flex;\n    flex-direction: row;\n}\n\nul[data-type=\"taskList\"] li p {\n    margin: 0;\n}\n\nul[data-type=\"taskList\"] li input[type=\"checkbox\"] {\n    width: 16px;\n    height: 16px;\n    border-radius: 0;\n}";
styleInject$1(css_248z$J);

var css_248z$I = "";
styleInject$1(css_248z$I);

var css_248z$H = ".powerui-table-context-actions button {\n}\n\n.powerui-table-context-actions button svg {\n}";
styleInject$1(css_248z$H);

var TableContextActions = function (props) {
    return (React$1.createElement("div", { className: "powerui-contextbar-content" },
        React$1.createElement("button", { onClick: function () { return props.editor.chain().focus().addColumnAfter().run(); }, type: "button", className: "powerui-contextbar-button" },
            React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 448 512" },
                React$1.createElement("path", { d: "M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32V224H48c-17.7 0-32 14.3-32 32s14.3 32 32 32H192V432c0 17.7 14.3 32 32 32s32-14.3 32-32V288H400c17.7 0 32-14.3 32-32s-14.3-32-32-32H256V80z" })),
            React$1.createElement("div", null, "Column")),
        React$1.createElement("button", { onClick: function () { return props.editor.chain().focus().deleteColumn().run(); }, type: "button", className: "powerui-contextbar-button" },
            React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 448 512" },
                React$1.createElement("path", { d: "M432 256c0 17.7-14.3 32-32 32L48 288c-17.7 0-32-14.3-32-32s14.3-32 32-32l352 0c17.7 0 32 14.3 32 32z" })),
            React$1.createElement("div", null, "Column")),
        React$1.createElement("button", { onClick: function () { return props.editor.chain().focus().addRowAfter().run(); }, type: "button", className: "powerui-contextbar-button" },
            React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 448 512" },
                React$1.createElement("path", { d: "M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32V224H48c-17.7 0-32 14.3-32 32s14.3 32 32 32H192V432c0 17.7 14.3 32 32 32s32-14.3 32-32V288H400c17.7 0 32-14.3 32-32s-14.3-32-32-32H256V80z" })),
            React$1.createElement("div", null, "Row")),
        React$1.createElement("button", { onClick: function () { return props.editor.chain().focus().deleteRow().run(); }, type: "button", className: "powerui-contextbar-button" },
            React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 448 512" },
                React$1.createElement("path", { d: "M432 256c0 17.7-14.3 32-32 32L48 288c-17.7 0-32-14.3-32-32s14.3-32 32-32l352 0c17.7 0 32 14.3 32 32z" })),
            React$1.createElement("div", null, "Row")),
        React$1.createElement("button", { onClick: function () { return props.editor.chain().focus().toggleHeaderRow().run(); }, type: "button", className: "powerui-contextbar-button" },
            React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 384 512" },
                React$1.createElement("path", { d: "M224 32c0-17.7-14.3-32-32-32s-32 14.3-32 32V144H48c-17.7 0-32 14.3-32 32s14.3 32 32 32H160V320c0 17.7 14.3 32 32 32s32-14.3 32-32V208H336c17.7 0 32-14.3 32-32s-14.3-32-32-32H224V32zM0 480c0 17.7 14.3 32 32 32H352c17.7 0 32-14.3 32-32s-14.3-32-32-32H32c-17.7 0-32 14.3-32 32z" })),
            React$1.createElement("div", null, "Header")),
        React$1.createElement("button", { onClick: function () { return props.editor.chain().focus().deleteTable().run(); }, type: "button", className: "powerui-contextbar-button" },
            React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 448 512" },
                React$1.createElement("path", { d: "M170.5 51.6L151.5 80h145l-19-28.4c-1.5-2.2-4-3.6-6.7-3.6H177.1c-2.7 0-5.2 1.3-6.7 3.6zm147-26.6L354.2 80H368h48 8c13.3 0 24 10.7 24 24s-10.7 24-24 24h-8V432c0 44.2-35.8 80-80 80H112c-44.2 0-80-35.8-80-80V128H24c-13.3 0-24-10.7-24-24S10.7 80 24 80h8H80 93.8l36.7-55.1C140.9 9.4 158.4 0 177.1 0h93.7c18.7 0 36.2 9.4 46.6 24.9zM80 128V432c0 17.7 14.3 32 32 32H336c17.7 0 32-14.3 32-32V128H80zm80 64V400c0 8.8-7.2 16-16 16s-16-7.2-16-16V192c0-8.8 7.2-16 16-16s16 7.2 16 16zm80 0V400c0 8.8-7.2 16-16 16s-16-7.2-16-16V192c0-8.8 7.2-16 16-16s16 7.2 16 16zm80 0V400c0 8.8-7.2 16-16 16s-16-7.2-16-16V192c0-8.8 7.2-16 16-16s16 7.2 16 16z" })))));
};

var ContextBar = function (props) {
    var _a;
    return (React$1.createElement(React$1.Fragment, null,
        props.content && props.content,
        ((_a = props.editor) === null || _a === void 0 ? void 0 : _a.isActive('table')) && React$1.createElement(TableContextActions, { editor: props.editor })));
};

var Toolbar = function (_a) {
    var editor = _a.editor, placement = _a.placement, children = _a.children; __rest$1(_a, ["editor", "placement", "children"]);
    var _b = useState(), contextBar = _b[0], setContextBar = _b[1];
    if (!editor) {
        return null;
    }
    // useEffect(() => {
    //     const _childWidgets: any[] = [];
    //     React.Children.forEach(children, (child: any) => {
    //         let _child = child;
    //         // if ([
    //         //   "ArticleViewTitleChildWidget",
    //         //   "ArticleViewSummaryChildWidget",
    //         //   "ArticleViewBodyChildWidget",
    //         //   "ArticleViewMetadataChildWidget",
    //         //   "ArticleViewTagsChildWidget"
    //         // ].includes(child.type.displayName)) {
    //         _child = React.cloneElement(child, { editor });
    //         // }
    //         _childWidgets.push(_child);
    //     })
    //     setChildWidgets(_childWidgets);
    // }, [children]);
    // useEffect(() => {
    //     if (widthRef.current && heightRef.current) {
    //         widthRef.current.value = 640
    //         heightRef.current.value = 480
    //     }
    // }, [widthRef.current, heightRef.current])
    var onContextBarChange = function (detail) {
        setContextBar(detail);
    };
    return (React$1.createElement("div", { className: "powerui-toolbar powerui-toolbar--placement-".concat(placement) },
        placement === 'bottom' && React$1.createElement("div", { className: "powerui-contextbar" },
            React$1.createElement(ContextBar, { content: contextBar, editor: editor })),
        React$1.createElement("div", { className: "powerui-toolbar-main" }, React$1.Children.map(children, function (child) {
            return React$1.cloneElement(child, { onContextBarChange: onContextBarChange });
        })),
        placement !== 'bottom' && React$1.createElement("div", { className: "powerui-contextbar" },
            React$1.createElement(ContextBar, { content: contextBar, editor: editor }))));
};

var css_248z$G = ".ProseMirror {\n    outline: none;\n    padding: 10px 10px;\n    background-color: var(--powerui-background-color);\n    border-radius: 0 0 var(--powerui-border-radius) var(--powerui-border-radius);\n}\n\n.powerui-editor--toolbar-placement-bottom .ProseMirror {\n    border-radius: var(--powerui-border-radius) var(--powerui-border-radius) 0 0;\n}\n\n.powerui-editor--toolbar-placement-top.powerui-editor--contextbar-active .ProseMirror {\n    border-radius: 0;\n}\n\n\n\n.ProseMirror>*+* {\n    margin-top: 0.75em;\n}\n\n.ProseMirror ul,\n.ProseMirror ol {\n    padding: 0 1rem;\n}\n\n.ProseMirror h1,\n.ProseMirror h2,\n.ProseMirror h3,\n.ProseMirror h4,\n.ProseMirror h5,\n.ProseMirror h6 {\n    line-height: 1.1;\n}\n\n.ProseMirror code {\n    background-color: rgba(97, 97, 97, 0.1);\n    color: #616161;\n}\n\n.ProseMirror pre {\n    background: #0d0d0d;\n    color: #fff;\n    font-family: 'JetBrainsMono', monospace;\n    padding: 0.75rem 1rem;\n    border-radius: 0.5rem;\n}\n\n.ProseMirror pre code {\n    color: inherit;\n    padding: 0;\n    background: none;\n    font-size: 0.8rem;\n}\n\n.ProseMirror img {\n    max-width: 100%;\n    height: auto;\n}\n\n.ProseMirror blockquote {\n    padding-left: 1rem;\n    border-left: 2px solid rgba(13, 13, 13, 0.1);\n}\n\n.ProseMirror hr {\n    border: none;\n    border-top: 2px solid rgba(13, 13, 13, 0.1);\n    margin: 2rem 0;\n}";
styleInject$1(css_248z$G);

var Editor = function (props) {
    var _a;
    var _b = useState(), contextBar = _b[0], setContextBar = _b[1];
    var onContextBarChange = function (detail) {
        setContextBar(detail);
    };
    useEffect(function () {
        if (!props.editor || !props.onChange)
            return;
        var handleUpdate = function () {
            var _a;
            var html = props.editor.getHTML();
            (_a = props.onChange) === null || _a === void 0 ? void 0 : _a.call(props, html);
        };
        props.editor.on('update', handleUpdate);
        return function () {
            props.editor.off('update', handleUpdate);
        };
    }, [props.editor, props.onChange]);
    return (React$1.createElement("div", { className: "powerui-editor ".concat((((_a = props.editor) === null || _a === void 0 ? void 0 : _a.isActive('table')) || contextBar) ? 'powerui-editor--contextbar-active' : '', " powerui-editor--toolbar-placement-").concat(props.toolbarPlacement || 'top') },
        props.toolbarPlacement !== "bottom" && React$1.createElement(Toolbar, { editor: props.editor, placement: props.toolbarPlacement, onContextBarChange: onContextBarChange }, props.children),
        React$1.createElement("div", { className: 'powerui-editor-content' },
            React$1.createElement(EditorContent, { editor: props.editor })),
        props.toolbarPlacement === "bottom" && React$1.createElement(Toolbar, { editor: props.editor, placement: props.toolbarPlacement, onContextBarChange: onContextBarChange }, props.children)));
};

var css_248z$F = "";
styleInject$1(css_248z$F);

var Bold = function (_a) {
    var editor = _a.editor;
    return (React$1.createElement("button", { onClick: function () { return editor.chain().focus().toggleBold().run(); }, disabled: !editor.can()
            .chain()
            .focus()
            .toggleBold()
            .run(), className: editor.isActive('bold') ? 'is-active' : '', type: "button" },
        React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 384 512" },
            React$1.createElement("path", { d: "M0 64C0 46.3 14.3 32 32 32H80 96 224c70.7 0 128 57.3 128 128c0 31.3-11.3 60.1-30 82.3c37.1 22.4 62 63.1 62 109.7c0 70.7-57.3 128-128 128H96 80 32c-17.7 0-32-14.3-32-32s14.3-32 32-32H48V256 96H32C14.3 96 0 81.7 0 64zM224 224c35.3 0 64-28.7 64-64s-28.7-64-64-64H112V224H224zM112 288V416H256c35.3 0 64-28.7 64-64s-28.7-64-64-64H224 112z" }))));
};

var css_248z$E = "";
styleInject$1(css_248z$E);

var Italic = function (_a) {
    var editor = _a.editor;
    return (React$1.createElement("button", { onClick: function () { return editor.chain().focus().toggleItalic().run(); }, disabled: !editor.can()
            .chain()
            .focus()
            .toggleItalic()
            .run(), className: editor.isActive('italic') ? 'is-active' : '', type: "button" },
        React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 384 512" },
            React$1.createElement("path", { d: "M128 64c0-17.7 14.3-32 32-32H352c17.7 0 32 14.3 32 32s-14.3 32-32 32H293.3L160 416h64c17.7 0 32 14.3 32 32s-14.3 32-32 32H32c-17.7 0-32-14.3-32-32s14.3-32 32-32H90.7L224 96H160c-17.7 0-32-14.3-32-32z" }))));
};

var css_248z$D = "";
styleInject$1(css_248z$D);

var Underline = function (_a) {
    var editor = _a.editor;
    return (React$1.createElement("button", { onClick: function () { return editor.chain().focus().toggleUnderline().run(); }, className: editor.isActive('underline') ? 'is-active' : '', type: "button" },
        React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 448 512" },
            React$1.createElement("path", { d: "M16 64c0-17.7 14.3-32 32-32h96c17.7 0 32 14.3 32 32s-14.3 32-32 32H128V224c0 53 43 96 96 96s96-43 96-96V96H304c-17.7 0-32-14.3-32-32s14.3-32 32-32h96c17.7 0 32 14.3 32 32s-14.3 32-32 32H384V224c0 88.4-71.6 160-160 160s-160-71.6-160-160V96H48C30.3 96 16 81.7 16 64zM0 448c0-17.7 14.3-32 32-32H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32c-17.7 0-32-14.3-32-32z" }))));
};

var css_248z$C = "";
styleInject$1(css_248z$C);

var Strikethrough = function (_a) {
    var editor = _a.editor;
    return (React$1.createElement("button", { onClick: function () { return editor.chain().focus().toggleStrike().run(); }, disabled: !editor.can()
            .chain()
            .focus()
            .toggleStrike()
            .run(), type: "button", className: editor.isActive('strike') ? 'is-active' : '' },
        React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 512 512" },
            React$1.createElement("path", { d: "M161.3 144c3.2-17.2 14-30.1 33.7-38.6c21.1-9 51.8-12.3 88.6-6.5c11.9 1.9 48.8 9.1 60.1 12c17.1 4.5 34.6-5.6 39.2-22.7s-5.6-34.6-22.7-39.2c-14.3-3.8-53.6-11.4-66.6-13.4c-44.7-7-88.3-4.2-123.7 10.9c-36.5 15.6-64.4 44.8-71.8 87.3c-.1 .6-.2 1.1-.2 1.7c-2.8 23.9 .5 45.6 10.1 64.6c4.5 9 10.2 16.9 16.7 23.9H32c-17.7 0-32 14.3-32 32s14.3 32 32 32H480c17.7 0 32-14.3 32-32s-14.3-32-32-32H270.1c-.1 0-.3-.1-.4-.1l-1.1-.3c-36-10.8-65.2-19.6-85.2-33.1c-9.3-6.3-15-12.6-18.2-19.1c-3.1-6.1-5.2-14.6-3.8-27.4zM348.9 337.2c2.7 6.5 4.4 15.8 1.9 30.1c-3 17.6-13.8 30.8-33.9 39.4c-21.1 9-51.7 12.3-88.5 6.5c-18-2.9-49.1-13.5-74.4-22.1c-5.6-1.9-11-3.7-15.9-5.4c-16.8-5.6-34.9 3.5-40.5 20.3s3.5 34.9 20.3 40.5c3.6 1.2 7.9 2.7 12.7 4.3l0 0 0 0c24.9 8.5 63.6 21.7 87.6 25.6l0 0 .2 0c44.7 7 88.3 4.2 123.7-10.9c36.5-15.6 64.4-44.8 71.8-87.3c3.6-21 2.7-40.4-3.1-58.1H335.1c7 5.6 11.4 11.2 13.9 17.2z" }))));
};

var css_248z$B = "";
styleInject$1(css_248z$B);

var HeadingDropdown = function (_a) {
    var editor = _a.editor;
    var handleHeadingStateChange = function (event) {
        switch (event.currentTarget.value) {
            case "Heading 1":
                editor.chain().focus().toggleHeading({ level: 1 }).run();
                break;
            case "Heading 2":
                editor.chain().focus().toggleHeading({ level: 2 }).run();
                break;
            case "Heading 3":
                editor.chain().focus().toggleHeading({ level: 3 }).run();
                break;
            case "Heading 4":
                editor.chain().focus().toggleHeading({ level: 4 }).run();
                break;
            case "Heading 5":
                editor.chain().focus().toggleHeading({ level: 5 }).run();
                break;
            case "Heading 6":
                editor.chain().focus().toggleHeading({ level: 6 }).run();
                break;
            default:
                editor.chain().focus().setParagraph().run();
        }
    };
    return (React$1.createElement("select", { className: "heading-select ".concat(!editor.isActive('paragraph') ? 'is-active' : ''), value: editor.isActive('heading', { level: 1 }) ? 'Heading 1' :
            editor.isActive('heading', { level: 2 }) ? 'Heading 2' :
                editor.isActive('heading', { level: 3 }) ? 'Heading 3' :
                    editor.isActive('heading', { level: 4 }) ? 'Heading 4' :
                        editor.isActive('heading', { level: 5 }) ? 'Heading 5' :
                            editor.isActive('heading', { level: 6 }) ? 'Heading 6' : "Paragraph", onChange: handleHeadingStateChange },
        React$1.createElement("option", null, "Paragraph"),
        React$1.createElement("option", null, "Heading 1"),
        React$1.createElement("option", null, "Heading 2"),
        React$1.createElement("option", null, "Heading 3"),
        React$1.createElement("option", null, "Heading 4"),
        React$1.createElement("option", null, "Heading 5"),
        React$1.createElement("option", null, "Heading 6")));
};

var css_248z$A = "";
styleInject$1(css_248z$A);

var AlignmentDropdown = function (_a) {
    var editor = _a.editor;
    var handleAlignmentStateChange = function (event) {
        switch (event.currentTarget.value) {
            case "Right":
                editor.chain().focus().setTextAlign('right').run();
                break;
            case "Center":
                editor.chain().focus().setTextAlign('center').run();
                break;
            case "Justify":
                editor.chain().focus().setTextAlign('justify').run();
                break;
            default:
                editor.chain().focus().setTextAlign('left').run();
        }
    };
    return (React$1.createElement("select", { className: "heading-select ".concat(!editor.isActive({ 'textAlign': 'left' }) ? 'is-active' : ''), value: editor.isActive({ 'textAlign': 'center' }) ? 'Center' :
            editor.isActive({ 'textAlign': 'right' }) ? 'Right' :
                editor.isActive({ 'textAlign': 'justify' }) ? 'Justify' : 'Left', onChange: handleAlignmentStateChange },
        React$1.createElement("option", null, "Left"),
        React$1.createElement("option", null, "Right"),
        React$1.createElement("option", null, "Center"),
        React$1.createElement("option", null, "Justify")));
};

var css_248z$z = "";
styleInject$1(css_248z$z);

var AlignLeft = function (_a) {
    var editor = _a.editor;
    return (React$1.createElement("button", { onClick: function () { return editor.chain().focus().setTextAlign('left').run(); }, className: editor.isActive({ textAlign: 'left' }) ? 'is-active' : '', type: "button" },
        React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 448 512" },
            React$1.createElement("path", { d: "M288 64c0 17.7-14.3 32-32 32H32C14.3 96 0 81.7 0 64S14.3 32 32 32H256c17.7 0 32 14.3 32 32zm0 256c0 17.7-14.3 32-32 32H32c-17.7 0-32-14.3-32-32s14.3-32 32-32H256c17.7 0 32 14.3 32 32zM0 192c0-17.7 14.3-32 32-32H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32c-17.7 0-32-14.3-32-32zM448 448c0 17.7-14.3 32-32 32H32c-17.7 0-32-14.3-32-32s14.3-32 32-32H416c17.7 0 32 14.3 32 32z" }))));
};

var css_248z$y = "";
styleInject$1(css_248z$y);

var AlignRight = function (_a) {
    var editor = _a.editor;
    return (React$1.createElement("button", { onClick: function () { return editor.chain().focus().setTextAlign('right').run(); }, className: editor.isActive({ textAlign: 'right' }) ? 'is-active' : '', type: "button" },
        React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 448 512" },
            React$1.createElement("path", { d: "M448 64c0 17.7-14.3 32-32 32H192c-17.7 0-32-14.3-32-32s14.3-32 32-32H416c17.7 0 32 14.3 32 32zm0 256c0 17.7-14.3 32-32 32H192c-17.7 0-32-14.3-32-32s14.3-32 32-32H416c17.7 0 32 14.3 32 32zM0 192c0-17.7 14.3-32 32-32H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32c-17.7 0-32-14.3-32-32zM448 448c0 17.7-14.3 32-32 32H32c-17.7 0-32-14.3-32-32s14.3-32 32-32H416c17.7 0 32 14.3 32 32z" }))));
};

var css_248z$x = "";
styleInject$1(css_248z$x);

var AlignCenter = function (_a) {
    var editor = _a.editor;
    return (React$1.createElement("button", { onClick: function () { return editor.chain().focus().setTextAlign('center').run(); }, className: editor.isActive({ textAlign: 'center' }) ? 'is-active' : '', type: "button" },
        React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 448 512" },
            React$1.createElement("path", { d: "M352 64c0-17.7-14.3-32-32-32H128c-17.7 0-32 14.3-32 32s14.3 32 32 32H320c17.7 0 32-14.3 32-32zm96 128c0-17.7-14.3-32-32-32H32c-17.7 0-32 14.3-32 32s14.3 32 32 32H416c17.7 0 32-14.3 32-32zM0 448c0 17.7 14.3 32 32 32H416c17.7 0 32-14.3 32-32s-14.3-32-32-32H32c-17.7 0-32 14.3-32 32zM352 320c0-17.7-14.3-32-32-32H128c-17.7 0-32 14.3-32 32s14.3 32 32 32H320c17.7 0 32-14.3 32-32z" }))));
};

var css_248z$w = "";
styleInject$1(css_248z$w);

var AlignJustify = function (_a) {
    var editor = _a.editor;
    return (React$1.createElement("button", { onClick: function () { return editor.chain().focus().setTextAlign('justify').run(); }, className: editor.isActive({ textAlign: 'justify' }) ? 'is-active' : '', type: "button" },
        React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 448 512" },
            React$1.createElement("path", { d: "M448 64c0-17.7-14.3-32-32-32H32C14.3 32 0 46.3 0 64S14.3 96 32 96H416c17.7 0 32-14.3 32-32zm0 256c0-17.7-14.3-32-32-32H32c-17.7 0-32 14.3-32 32s14.3 32 32 32H416c17.7 0 32-14.3 32-32zM0 192c0 17.7 14.3 32 32 32H416c17.7 0 32-14.3 32-32s-14.3-32-32-32H32c-17.7 0-32 14.3-32 32zM448 448c0-17.7-14.3-32-32-32H32c-17.7 0-32 14.3-32 32s14.3 32 32 32H416c17.7 0 32-14.3 32-32z" }))));
};

var css_248z$v = "";
styleInject$1(css_248z$v);

var BulletList = function (_a) {
    var editor = _a.editor;
    return (React$1.createElement("button", { onClick: function () { return editor.chain().focus().toggleBulletList().run(); }, className: editor.isActive('bulletList') ? 'is-active' : '', type: "button" },
        React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 512 512" },
            React$1.createElement("path", { d: "M64 144a48 48 0 1 0 0-96 48 48 0 1 0 0 96zM192 64c-17.7 0-32 14.3-32 32s14.3 32 32 32H480c17.7 0 32-14.3 32-32s-14.3-32-32-32H192zm0 160c-17.7 0-32 14.3-32 32s14.3 32 32 32H480c17.7 0 32-14.3 32-32s-14.3-32-32-32H192zm0 160c-17.7 0-32 14.3-32 32s14.3 32 32 32H480c17.7 0 32-14.3 32-32s-14.3-32-32-32H192zM64 464a48 48 0 1 0 0-96 48 48 0 1 0 0 96zm48-208a48 48 0 1 0 -96 0 48 48 0 1 0 96 0z" }))));
};

var css_248z$u = "";
styleInject$1(css_248z$u);

var BlockQuote = function (_a) {
    var editor = _a.editor;
    return (React$1.createElement("button", { onClick: function () { return editor.chain().focus().toggleBlockquote().run(); }, className: editor.isActive('blockquote') ? 'is-active' : '', type: "button" },
        React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 448 512" },
            React$1.createElement("path", { d: "M0 216C0 149.7 53.7 96 120 96h8c17.7 0 32 14.3 32 32s-14.3 32-32 32h-8c-30.9 0-56 25.1-56 56v8h64c35.3 0 64 28.7 64 64v64c0 35.3-28.7 64-64 64H64c-35.3 0-64-28.7-64-64V320 288 216zm256 0c0-66.3 53.7-120 120-120h8c17.7 0 32 14.3 32 32s-14.3 32-32 32h-8c-30.9 0-56 25.1-56 56v8h64c35.3 0 64 28.7 64 64v64c0 35.3-28.7 64-64 64H320c-35.3 0-64-28.7-64-64V320 288 216z" }))));
};

var css_248z$t = "";
styleInject$1(css_248z$t);

var OrderedList = function (_a) {
    var editor = _a.editor;
    return (React$1.createElement("button", { onClick: function () { return editor.chain().focus().toggleOrderedList().run(); }, className: editor.isActive('orderedList') ? 'is-active' : '', type: "button" },
        React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 512 512" },
            React$1.createElement("path", { d: "M24 56c0-13.3 10.7-24 24-24H80c13.3 0 24 10.7 24 24V176h16c13.3 0 24 10.7 24 24s-10.7 24-24 24H40c-13.3 0-24-10.7-24-24s10.7-24 24-24H56V80H48C34.7 80 24 69.3 24 56zM86.7 341.2c-6.5-7.4-18.3-6.9-24 1.2L51.5 357.9c-7.7 10.8-22.7 13.3-33.5 5.6s-13.3-22.7-5.6-33.5l11.1-15.6c23.7-33.2 72.3-35.6 99.2-4.9c21.3 24.4 20.8 60.9-1.1 84.7L86.8 432H120c13.3 0 24 10.7 24 24s-10.7 24-24 24H32c-9.5 0-18.2-5.6-22-14.4s-2.1-18.9 4.3-25.9l72-78c5.3-5.8 5.4-14.6 .3-20.5zM224 64H480c17.7 0 32 14.3 32 32s-14.3 32-32 32H224c-17.7 0-32-14.3-32-32s14.3-32 32-32zm0 160H480c17.7 0 32 14.3 32 32s-14.3 32-32 32H224c-17.7 0-32-14.3-32-32s14.3-32 32-32zm0 160H480c17.7 0 32 14.3 32 32s-14.3 32-32 32H224c-17.7 0-32-14.3-32-32s14.3-32 32-32z" }))));
};

var css_248z$s = "";
styleInject$1(css_248z$s);

var AddImage = function (_a) {
    var editor = _a.editor, props = __rest$1(_a, ["editor"]);
    var addImage = function (url) {
        // const url = window.prompt('URL')
        if (url) {
            editor.chain().focus().setImage({ src: url }).run();
        }
    };
    var browse = function () {
        var input = document.createElement('input');
        input.type = 'file';
        input.onchange = function () {
            Array.from(input.files);
            var payload = new FormData();
            payload.append(props.imageUploadParam, input.files[0]);
            fetch(props.imageUploadURL, {
                method: props.imageUploadMethod,
                body: payload
            })
                .then(function (response) { return response.json(); })
                .then(function (response) {
                addImage(response.url);
            });
        };
        input.click();
    };
    return (React$1.createElement("div", null,
        React$1.createElement("button", { onClick: browse, type: "button" },
            React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 512 512" },
                React$1.createElement("path", { d: "M448 80c8.8 0 16 7.2 16 16V415.8l-5-6.5-136-176c-4.5-5.9-11.6-9.3-19-9.3s-14.4 3.4-19 9.3L202 340.7l-30.5-42.7C167 291.7 159.8 288 152 288s-15 3.7-19.5 10.1l-80 112L48 416.3l0-.3V96c0-8.8 7.2-16 16-16H448zM64 32C28.7 32 0 60.7 0 96V416c0 35.3 28.7 64 64 64H448c35.3 0 64-28.7 64-64V96c0-35.3-28.7-64-64-64H64zm80 192a48 48 0 1 0 0-96 48 48 0 1 0 0 96z" })))));
};

var css_248z$r = ".powerui-add-table {\n    position: relative;\n}\n";
styleInject$1(css_248z$r);

var css_248z$q = ".powerui-add-table-grid-size {\n    display: flex;\n    flex-direction: row;\n    flex-wrap: wrap;\n    align-items: center;\n}\n\n.powerui-add-table-grid-size input,\n.powerui-add-table-grid-size button {\n    margin-right: 10px;\n}\n\n";
styleInject$1(css_248z$q);

var GridSize = function (props) {
    var _a = useState({
        rows: 2,
        columns: 4
    }), state = _a[0], setState = _a[1];
    var handleChange = function (event) {
        var _a;
        setState(__assign$1(__assign$1({}, state), (_a = {}, _a[event.currentTarget.name] = event.currentTarget.valueAsNumber, _a)));
    };
    var onApply = function () {
        props.onApply(state);
    };
    var onCancel = function () {
        setState({
            rows: 2,
            columns: 4
        });
        props.onCancel();
    };
    return (React$1.createElement("div", { className: "powerui-contextbar-content" },
        React$1.createElement("input", { name: "rows", value: state.rows, placeholder: "Rows", type: "number", onInput: handleChange }),
        React$1.createElement("input", { name: "columns", value: state.columns, placeholder: "Columns", type: "number", onInput: handleChange }),
        React$1.createElement("button", { onClick: onApply, type: "button", className: "powerui-contextbar-button" },
            React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 512 512" },
                React$1.createElement("path", { d: "M470.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L192 338.7 425.4 105.4c12.5-12.5 32.8-12.5 45.3 0z" }))),
        React$1.createElement("button", { onClick: onCancel, type: "button", className: "powerui-contextbar-button" },
            React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 320 512" },
                React$1.createElement("path", { d: "M310.6 150.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L160 210.7 54.6 105.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L114.7 256 9.4 361.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L160 301.3 265.4 406.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L205.3 256 310.6 150.6z" })))));
};

var AddTable = function (_a) {
    var editor = _a.editor, onContextBarChange = _a.onContextBarChange; __rest$1(_a, ["editor", "onContextBarChange"]);
    var contextActions = {
        onCancel: function () {
            onContextBarChange(null);
        },
        onApply: function (_a) {
            var rows = _a.rows, columns = _a.columns;
            editor.chain().focus().insertTable({ rows: rows + 1, cols: columns, withHeaderRow: true }).run();
            onContextBarChange(null);
        }
    };
    var showContextBar = function () {
        var contextBarContent = React$1.createElement(GridSize, { onApply: contextActions.onApply, onCancel: contextActions.onCancel });
        onContextBarChange(contextBarContent);
    };
    return (React$1.createElement("div", { className: "powerui-add-table" },
        React$1.createElement("button", { onClick: showContextBar, type: "button" },
            React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 512 512" },
                React$1.createElement("path", { d: "M64 256V160H224v96H64zm0 64H224v96H64V320zm224 96V320H448v96H288zM448 256H288V160H448v96zM64 32C28.7 32 0 60.7 0 96V416c0 35.3 28.7 64 64 64H448c35.3 0 64-28.7 64-64V96c0-35.3-28.7-64-64-64H64z" })))));
};

var css_248z$p = "";
styleInject$1(css_248z$p);

var AddYoutubeVideo = function (_a) {
    var editor = _a.editor;
    React$1.useRef(640);
    React$1.useRef(480);
    var addYoutubeVideo = function () {
        var url = prompt('Enter YouTube URL');
        if (url) {
            editor.commands.setYoutubeVideo({
                src: url,
                // width: Math.max(320, parseInt(widthRef.current.value, 10)) || 640,
                // height: Math.max(180, parseInt(heightRef.current.value, 10)) || 480,
            });
        }
    };
    return (React$1.createElement(React$1.Fragment, null,
        React$1.createElement("button", { id: "add", onClick: addYoutubeVideo, type: "button" },
            React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 576 512" },
                React$1.createElement("path", { d: "M549.655 124.083c-6.281-23.65-24.787-42.276-48.284-48.597C458.781 64 288 64 288 64S117.22 64 74.629 75.486c-23.497 6.322-42.003 24.947-48.284 48.597-11.412 42.867-11.412 132.305-11.412 132.305s0 89.438 11.412 132.305c6.281 23.65 24.787 41.5 48.284 47.821C117.22 448 288 448 288 448s170.78 0 213.371-11.486c23.497-6.321 42.003-24.171 48.284-47.821 11.412-42.867 11.412-132.305 11.412-132.305s0-89.438-11.412-132.305zm-317.51 213.508V175.185l142.739 81.205-142.739 81.201z" })))));
};

var css_248z$o = "";
styleInject$1(css_248z$o);

var Code = function (_a) {
    var editor = _a.editor;
    return (React$1.createElement("button", { onClick: function () { return editor.chain().focus().toggleCode().run(); }, disabled: !editor.can()
            .chain()
            .focus()
            .toggleCode()
            .run(), className: editor.isActive('code') ? 'is-active' : '', type: "button" },
        React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 640 512" },
            React$1.createElement("path", { d: "M392.8 1.2c-17-4.9-34.7 5-39.6 22l-128 448c-4.9 17 5 34.7 22 39.6s34.7-5 39.6-22l128-448c4.9-17-5-34.7-22-39.6zm80.6 120.1c-12.5 12.5-12.5 32.8 0 45.3L562.7 256l-89.4 89.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0l112-112c12.5-12.5 12.5-32.8 0-45.3l-112-112c-12.5-12.5-32.8-12.5-45.3 0zm-306.7 0c-12.5-12.5-32.8-12.5-45.3 0l-112 112c-12.5 12.5-12.5 32.8 0 45.3l112 112c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L77.3 256l89.4-89.4c12.5-12.5 12.5-32.8 0-45.3z" }))));
};

var css_248z$n = "";
styleInject$1(css_248z$n);

var CodeBlock = function (_a) {
    var editor = _a.editor;
    return (React$1.createElement("button", { onClick: function () { return editor.chain().focus().toggleCodeBlock().run(); }, className: editor.isActive('codeBlock') ? 'is-active' : '', type: "button" },
        React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 640 512" },
            React$1.createElement("path", { d: "M64 96c0-35.3 28.7-64 64-64H512c35.3 0 64 28.7 64 64V352H512V96H128V352H64V96zM0 403.2C0 392.6 8.6 384 19.2 384H620.8c10.6 0 19.2 8.6 19.2 19.2c0 42.4-34.4 76.8-76.8 76.8H76.8C34.4 480 0 445.6 0 403.2zM281 209l-31 31 31 31c9.4 9.4 9.4 24.6 0 33.9s-24.6 9.4-33.9 0l-48-48c-9.4-9.4-9.4-24.6 0-33.9l48-48c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9zM393 175l48 48c9.4 9.4 9.4 24.6 0 33.9l-48 48c-9.4 9.4-24.6 9.4-33.9 0s-9.4-24.6 0-33.9l31-31-31-31c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0z" }))));
};

var css_248z$m = "";
styleInject$1(css_248z$m);

var ClearFormatting = function (_a) {
    var editor = _a.editor;
    return (React$1.createElement("button", { onClick: function () { editor.chain().focus().clearNodes().unsetAllMarks().run(); }, type: "button" },
        React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 320 512" },
            React$1.createElement("path", { d: "M310.6 150.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L160 210.7 54.6 105.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L114.7 256 9.4 361.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L160 301.3 265.4 406.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L205.3 256 310.6 150.6z" }))));
};

var css_248z$l = "";
styleInject$1(css_248z$l);

var HorizontalRule = function (_a) {
    var editor = _a.editor;
    return (React$1.createElement("button", { onClick: function () { return editor.chain().focus().setHorizontalRule().run(); }, type: "button" },
        React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 448 512" },
            React$1.createElement("path", { d: "M32 288c-17.7 0-32 14.3-32 32s14.3 32 32 32l384 0c17.7 0 32-14.3 32-32s-14.3-32-32-32L32 288zm0-128c-17.7 0-32 14.3-32 32s14.3 32 32 32l384 0c17.7 0 32-14.3 32-32s-14.3-32-32-32L32 160z" }))));
};

var css_248z$k = "";
styleInject$1(css_248z$k);

var FontColor = function (_a) {
    var editor = _a.editor;
    return (React$1.createElement("div", { className: "color-picker" },
        React$1.createElement("input", { type: "color", onInput: function (event) { return editor.chain().focus().setColor(event.target.value).run(); }, value: editor.getAttributes('textStyle').color || "#ffffff" })));
};

var css_248z$j = "";
styleInject$1(css_248z$j);

var HighlightColor = function (_a) {
    var editor = _a.editor;
    return (React$1.createElement("div", { className: "color-picker" },
        React$1.createElement("input", { type: "color", onInput: function (event) { return editor.chain().focus().toggleHighlight({ color: event.target.value }).run(); }, value: editor.getAttributes('highlight').color || "#ffffff" })));
};

var React = React$1;
var reactDom = require$$1;

/******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
/* global Reflect, Promise, SuppressedError, Symbol */


var __assign = function() {
    __assign = Object.assign || function __assign(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};

function __rest(s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
}

function __awaiter(thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, [])).next());
    });
}

function __generator(thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
}

function __spreadArray(to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
}

typeof SuppressedError === "function" ? SuppressedError : function (error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
};

var top = 'top';
var bottom = 'bottom';
var right = 'right';
var left = 'left';
var auto = 'auto';
var basePlacements = [top, bottom, right, left];
var start = 'start';
var end = 'end';
var clippingParents = 'clippingParents';
var viewport = 'viewport';
var popper = 'popper';
var reference = 'reference';
var variationPlacements = /*#__PURE__*/basePlacements.reduce(function (acc, placement) {
  return acc.concat([placement + "-" + start, placement + "-" + end]);
}, []);
var placements = /*#__PURE__*/[].concat(basePlacements, [auto]).reduce(function (acc, placement) {
  return acc.concat([placement, placement + "-" + start, placement + "-" + end]);
}, []); // modifiers that need to read the DOM

var beforeRead = 'beforeRead';
var read = 'read';
var afterRead = 'afterRead'; // pure-logic modifiers

var beforeMain = 'beforeMain';
var main = 'main';
var afterMain = 'afterMain'; // modifier with the purpose to write to the DOM (or write into a framework state)

var beforeWrite = 'beforeWrite';
var write = 'write';
var afterWrite = 'afterWrite';
var modifierPhases = [beforeRead, read, afterRead, beforeMain, main, afterMain, beforeWrite, write, afterWrite];

function getNodeName(element) {
  return element ? (element.nodeName || '').toLowerCase() : null;
}

function getWindow(node) {
  if (node == null) {
    return window;
  }

  if (node.toString() !== '[object Window]') {
    var ownerDocument = node.ownerDocument;
    return ownerDocument ? ownerDocument.defaultView || window : window;
  }

  return node;
}

function isElement(node) {
  var OwnElement = getWindow(node).Element;
  return node instanceof OwnElement || node instanceof Element;
}

function isHTMLElement(node) {
  var OwnElement = getWindow(node).HTMLElement;
  return node instanceof OwnElement || node instanceof HTMLElement;
}

function isShadowRoot(node) {
  // IE 11 has no ShadowRoot
  if (typeof ShadowRoot === 'undefined') {
    return false;
  }

  var OwnElement = getWindow(node).ShadowRoot;
  return node instanceof OwnElement || node instanceof ShadowRoot;
}

// and applies them to the HTMLElements such as popper and arrow

function applyStyles(_ref) {
  var state = _ref.state;
  Object.keys(state.elements).forEach(function (name) {
    var style = state.styles[name] || {};
    var attributes = state.attributes[name] || {};
    var element = state.elements[name]; // arrow is optional + virtual elements

    if (!isHTMLElement(element) || !getNodeName(element)) {
      return;
    } // Flow doesn't support to extend this property, but it's the most
    // effective way to apply styles to an HTMLElement
    // $FlowFixMe[cannot-write]


    Object.assign(element.style, style);
    Object.keys(attributes).forEach(function (name) {
      var value = attributes[name];

      if (value === false) {
        element.removeAttribute(name);
      } else {
        element.setAttribute(name, value === true ? '' : value);
      }
    });
  });
}

function effect$2(_ref2) {
  var state = _ref2.state;
  var initialStyles = {
    popper: {
      position: state.options.strategy,
      left: '0',
      top: '0',
      margin: '0'
    },
    arrow: {
      position: 'absolute'
    },
    reference: {}
  };
  Object.assign(state.elements.popper.style, initialStyles.popper);
  state.styles = initialStyles;

  if (state.elements.arrow) {
    Object.assign(state.elements.arrow.style, initialStyles.arrow);
  }

  return function () {
    Object.keys(state.elements).forEach(function (name) {
      var element = state.elements[name];
      var attributes = state.attributes[name] || {};
      var styleProperties = Object.keys(state.styles.hasOwnProperty(name) ? state.styles[name] : initialStyles[name]); // Set all values to an empty string to unset them

      var style = styleProperties.reduce(function (style, property) {
        style[property] = '';
        return style;
      }, {}); // arrow is optional + virtual elements

      if (!isHTMLElement(element) || !getNodeName(element)) {
        return;
      }

      Object.assign(element.style, style);
      Object.keys(attributes).forEach(function (attribute) {
        element.removeAttribute(attribute);
      });
    });
  };
} // eslint-disable-next-line import/no-unused-modules


var applyStyles$1 = {
  name: 'applyStyles',
  enabled: true,
  phase: 'write',
  fn: applyStyles,
  effect: effect$2,
  requires: ['computeStyles']
};

function getBasePlacement(placement) {
  return placement.split('-')[0];
}

var max = Math.max;
var min = Math.min;
var round = Math.round;

function getUAString() {
  var uaData = navigator.userAgentData;

  if (uaData != null && uaData.brands && Array.isArray(uaData.brands)) {
    return uaData.brands.map(function (item) {
      return item.brand + "/" + item.version;
    }).join(' ');
  }

  return navigator.userAgent;
}

function isLayoutViewport() {
  return !/^((?!chrome|android).)*safari/i.test(getUAString());
}

function getBoundingClientRect(element, includeScale, isFixedStrategy) {
  if (includeScale === void 0) {
    includeScale = false;
  }

  if (isFixedStrategy === void 0) {
    isFixedStrategy = false;
  }

  var clientRect = element.getBoundingClientRect();
  var scaleX = 1;
  var scaleY = 1;

  if (includeScale && isHTMLElement(element)) {
    scaleX = element.offsetWidth > 0 ? round(clientRect.width) / element.offsetWidth || 1 : 1;
    scaleY = element.offsetHeight > 0 ? round(clientRect.height) / element.offsetHeight || 1 : 1;
  }

  var _ref = isElement(element) ? getWindow(element) : window,
      visualViewport = _ref.visualViewport;

  var addVisualOffsets = !isLayoutViewport() && isFixedStrategy;
  var x = (clientRect.left + (addVisualOffsets && visualViewport ? visualViewport.offsetLeft : 0)) / scaleX;
  var y = (clientRect.top + (addVisualOffsets && visualViewport ? visualViewport.offsetTop : 0)) / scaleY;
  var width = clientRect.width / scaleX;
  var height = clientRect.height / scaleY;
  return {
    width: width,
    height: height,
    top: y,
    right: x + width,
    bottom: y + height,
    left: x,
    x: x,
    y: y
  };
}

// means it doesn't take into account transforms.

function getLayoutRect(element) {
  var clientRect = getBoundingClientRect(element); // Use the clientRect sizes if it's not been transformed.
  // Fixes https://github.com/popperjs/popper-core/issues/1223

  var width = element.offsetWidth;
  var height = element.offsetHeight;

  if (Math.abs(clientRect.width - width) <= 1) {
    width = clientRect.width;
  }

  if (Math.abs(clientRect.height - height) <= 1) {
    height = clientRect.height;
  }

  return {
    x: element.offsetLeft,
    y: element.offsetTop,
    width: width,
    height: height
  };
}

function contains(parent, child) {
  var rootNode = child.getRootNode && child.getRootNode(); // First, attempt with faster native method

  if (parent.contains(child)) {
    return true;
  } // then fallback to custom implementation with Shadow DOM support
  else if (rootNode && isShadowRoot(rootNode)) {
      var next = child;

      do {
        if (next && parent.isSameNode(next)) {
          return true;
        } // $FlowFixMe[prop-missing]: need a better way to handle this...


        next = next.parentNode || next.host;
      } while (next);
    } // Give up, the result is false


  return false;
}

function getComputedStyle(element) {
  return getWindow(element).getComputedStyle(element);
}

function isTableElement(element) {
  return ['table', 'td', 'th'].indexOf(getNodeName(element)) >= 0;
}

function getDocumentElement(element) {
  // $FlowFixMe[incompatible-return]: assume body is always available
  return ((isElement(element) ? element.ownerDocument : // $FlowFixMe[prop-missing]
  element.document) || window.document).documentElement;
}

function getParentNode(element) {
  if (getNodeName(element) === 'html') {
    return element;
  }

  return (// this is a quicker (but less type safe) way to save quite some bytes from the bundle
    // $FlowFixMe[incompatible-return]
    // $FlowFixMe[prop-missing]
    element.assignedSlot || // step into the shadow DOM of the parent of a slotted node
    element.parentNode || ( // DOM Element detected
    isShadowRoot(element) ? element.host : null) || // ShadowRoot detected
    // $FlowFixMe[incompatible-call]: HTMLElement is a Node
    getDocumentElement(element) // fallback

  );
}

function getTrueOffsetParent(element) {
  if (!isHTMLElement(element) || // https://github.com/popperjs/popper-core/issues/837
  getComputedStyle(element).position === 'fixed') {
    return null;
  }

  return element.offsetParent;
} // `.offsetParent` reports `null` for fixed elements, while absolute elements
// return the containing block


function getContainingBlock(element) {
  var isFirefox = /firefox/i.test(getUAString());
  var isIE = /Trident/i.test(getUAString());

  if (isIE && isHTMLElement(element)) {
    // In IE 9, 10 and 11 fixed elements containing block is always established by the viewport
    var elementCss = getComputedStyle(element);

    if (elementCss.position === 'fixed') {
      return null;
    }
  }

  var currentNode = getParentNode(element);

  if (isShadowRoot(currentNode)) {
    currentNode = currentNode.host;
  }

  while (isHTMLElement(currentNode) && ['html', 'body'].indexOf(getNodeName(currentNode)) < 0) {
    var css = getComputedStyle(currentNode); // This is non-exhaustive but covers the most common CSS properties that
    // create a containing block.
    // https://developer.mozilla.org/en-US/docs/Web/CSS/Containing_block#identifying_the_containing_block

    if (css.transform !== 'none' || css.perspective !== 'none' || css.contain === 'paint' || ['transform', 'perspective'].indexOf(css.willChange) !== -1 || isFirefox && css.willChange === 'filter' || isFirefox && css.filter && css.filter !== 'none') {
      return currentNode;
    } else {
      currentNode = currentNode.parentNode;
    }
  }

  return null;
} // Gets the closest ancestor positioned element. Handles some edge cases,
// such as table ancestors and cross browser bugs.


function getOffsetParent(element) {
  var window = getWindow(element);
  var offsetParent = getTrueOffsetParent(element);

  while (offsetParent && isTableElement(offsetParent) && getComputedStyle(offsetParent).position === 'static') {
    offsetParent = getTrueOffsetParent(offsetParent);
  }

  if (offsetParent && (getNodeName(offsetParent) === 'html' || getNodeName(offsetParent) === 'body' && getComputedStyle(offsetParent).position === 'static')) {
    return window;
  }

  return offsetParent || getContainingBlock(element) || window;
}

function getMainAxisFromPlacement(placement) {
  return ['top', 'bottom'].indexOf(placement) >= 0 ? 'x' : 'y';
}

function within(min$1, value, max$1) {
  return max(min$1, min(value, max$1));
}
function withinMaxClamp(min, value, max) {
  var v = within(min, value, max);
  return v > max ? max : v;
}

function getFreshSideObject() {
  return {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0
  };
}

function mergePaddingObject(paddingObject) {
  return Object.assign({}, getFreshSideObject(), paddingObject);
}

function expandToHashMap(value, keys) {
  return keys.reduce(function (hashMap, key) {
    hashMap[key] = value;
    return hashMap;
  }, {});
}

var toPaddingObject = function toPaddingObject(padding, state) {
  padding = typeof padding === 'function' ? padding(Object.assign({}, state.rects, {
    placement: state.placement
  })) : padding;
  return mergePaddingObject(typeof padding !== 'number' ? padding : expandToHashMap(padding, basePlacements));
};

function arrow(_ref) {
  var _state$modifiersData$;

  var state = _ref.state,
      name = _ref.name,
      options = _ref.options;
  var arrowElement = state.elements.arrow;
  var popperOffsets = state.modifiersData.popperOffsets;
  var basePlacement = getBasePlacement(state.placement);
  var axis = getMainAxisFromPlacement(basePlacement);
  var isVertical = [left, right].indexOf(basePlacement) >= 0;
  var len = isVertical ? 'height' : 'width';

  if (!arrowElement || !popperOffsets) {
    return;
  }

  var paddingObject = toPaddingObject(options.padding, state);
  var arrowRect = getLayoutRect(arrowElement);
  var minProp = axis === 'y' ? top : left;
  var maxProp = axis === 'y' ? bottom : right;
  var endDiff = state.rects.reference[len] + state.rects.reference[axis] - popperOffsets[axis] - state.rects.popper[len];
  var startDiff = popperOffsets[axis] - state.rects.reference[axis];
  var arrowOffsetParent = getOffsetParent(arrowElement);
  var clientSize = arrowOffsetParent ? axis === 'y' ? arrowOffsetParent.clientHeight || 0 : arrowOffsetParent.clientWidth || 0 : 0;
  var centerToReference = endDiff / 2 - startDiff / 2; // Make sure the arrow doesn't overflow the popper if the center point is
  // outside of the popper bounds

  var min = paddingObject[minProp];
  var max = clientSize - arrowRect[len] - paddingObject[maxProp];
  var center = clientSize / 2 - arrowRect[len] / 2 + centerToReference;
  var offset = within(min, center, max); // Prevents breaking syntax highlighting...

  var axisProp = axis;
  state.modifiersData[name] = (_state$modifiersData$ = {}, _state$modifiersData$[axisProp] = offset, _state$modifiersData$.centerOffset = offset - center, _state$modifiersData$);
}

function effect$1(_ref2) {
  var state = _ref2.state,
      options = _ref2.options;
  var _options$element = options.element,
      arrowElement = _options$element === void 0 ? '[data-popper-arrow]' : _options$element;

  if (arrowElement == null) {
    return;
  } // CSS selector


  if (typeof arrowElement === 'string') {
    arrowElement = state.elements.popper.querySelector(arrowElement);

    if (!arrowElement) {
      return;
    }
  }

  if (!contains(state.elements.popper, arrowElement)) {
    return;
  }

  state.elements.arrow = arrowElement;
} // eslint-disable-next-line import/no-unused-modules


var arrow$1 = {
  name: 'arrow',
  enabled: true,
  phase: 'main',
  fn: arrow,
  effect: effect$1,
  requires: ['popperOffsets'],
  requiresIfExists: ['preventOverflow']
};

function getVariation(placement) {
  return placement.split('-')[1];
}

var unsetSides = {
  top: 'auto',
  right: 'auto',
  bottom: 'auto',
  left: 'auto'
}; // Round the offsets to the nearest suitable subpixel based on the DPR.
// Zooming can change the DPR, but it seems to report a value that will
// cleanly divide the values into the appropriate subpixels.

function roundOffsetsByDPR(_ref, win) {
  var x = _ref.x,
      y = _ref.y;
  var dpr = win.devicePixelRatio || 1;
  return {
    x: round(x * dpr) / dpr || 0,
    y: round(y * dpr) / dpr || 0
  };
}

function mapToStyles(_ref2) {
  var _Object$assign2;

  var popper = _ref2.popper,
      popperRect = _ref2.popperRect,
      placement = _ref2.placement,
      variation = _ref2.variation,
      offsets = _ref2.offsets,
      position = _ref2.position,
      gpuAcceleration = _ref2.gpuAcceleration,
      adaptive = _ref2.adaptive,
      roundOffsets = _ref2.roundOffsets,
      isFixed = _ref2.isFixed;
  var _offsets$x = offsets.x,
      x = _offsets$x === void 0 ? 0 : _offsets$x,
      _offsets$y = offsets.y,
      y = _offsets$y === void 0 ? 0 : _offsets$y;

  var _ref3 = typeof roundOffsets === 'function' ? roundOffsets({
    x: x,
    y: y
  }) : {
    x: x,
    y: y
  };

  x = _ref3.x;
  y = _ref3.y;
  var hasX = offsets.hasOwnProperty('x');
  var hasY = offsets.hasOwnProperty('y');
  var sideX = left;
  var sideY = top;
  var win = window;

  if (adaptive) {
    var offsetParent = getOffsetParent(popper);
    var heightProp = 'clientHeight';
    var widthProp = 'clientWidth';

    if (offsetParent === getWindow(popper)) {
      offsetParent = getDocumentElement(popper);

      if (getComputedStyle(offsetParent).position !== 'static' && position === 'absolute') {
        heightProp = 'scrollHeight';
        widthProp = 'scrollWidth';
      }
    } // $FlowFixMe[incompatible-cast]: force type refinement, we compare offsetParent with window above, but Flow doesn't detect it


    offsetParent = offsetParent;

    if (placement === top || (placement === left || placement === right) && variation === end) {
      sideY = bottom;
      var offsetY = isFixed && offsetParent === win && win.visualViewport ? win.visualViewport.height : // $FlowFixMe[prop-missing]
      offsetParent[heightProp];
      y -= offsetY - popperRect.height;
      y *= gpuAcceleration ? 1 : -1;
    }

    if (placement === left || (placement === top || placement === bottom) && variation === end) {
      sideX = right;
      var offsetX = isFixed && offsetParent === win && win.visualViewport ? win.visualViewport.width : // $FlowFixMe[prop-missing]
      offsetParent[widthProp];
      x -= offsetX - popperRect.width;
      x *= gpuAcceleration ? 1 : -1;
    }
  }

  var commonStyles = Object.assign({
    position: position
  }, adaptive && unsetSides);

  var _ref4 = roundOffsets === true ? roundOffsetsByDPR({
    x: x,
    y: y
  }, getWindow(popper)) : {
    x: x,
    y: y
  };

  x = _ref4.x;
  y = _ref4.y;

  if (gpuAcceleration) {
    var _Object$assign;

    return Object.assign({}, commonStyles, (_Object$assign = {}, _Object$assign[sideY] = hasY ? '0' : '', _Object$assign[sideX] = hasX ? '0' : '', _Object$assign.transform = (win.devicePixelRatio || 1) <= 1 ? "translate(" + x + "px, " + y + "px)" : "translate3d(" + x + "px, " + y + "px, 0)", _Object$assign));
  }

  return Object.assign({}, commonStyles, (_Object$assign2 = {}, _Object$assign2[sideY] = hasY ? y + "px" : '', _Object$assign2[sideX] = hasX ? x + "px" : '', _Object$assign2.transform = '', _Object$assign2));
}

function computeStyles(_ref5) {
  var state = _ref5.state,
      options = _ref5.options;
  var _options$gpuAccelerat = options.gpuAcceleration,
      gpuAcceleration = _options$gpuAccelerat === void 0 ? true : _options$gpuAccelerat,
      _options$adaptive = options.adaptive,
      adaptive = _options$adaptive === void 0 ? true : _options$adaptive,
      _options$roundOffsets = options.roundOffsets,
      roundOffsets = _options$roundOffsets === void 0 ? true : _options$roundOffsets;
  var commonStyles = {
    placement: getBasePlacement(state.placement),
    variation: getVariation(state.placement),
    popper: state.elements.popper,
    popperRect: state.rects.popper,
    gpuAcceleration: gpuAcceleration,
    isFixed: state.options.strategy === 'fixed'
  };

  if (state.modifiersData.popperOffsets != null) {
    state.styles.popper = Object.assign({}, state.styles.popper, mapToStyles(Object.assign({}, commonStyles, {
      offsets: state.modifiersData.popperOffsets,
      position: state.options.strategy,
      adaptive: adaptive,
      roundOffsets: roundOffsets
    })));
  }

  if (state.modifiersData.arrow != null) {
    state.styles.arrow = Object.assign({}, state.styles.arrow, mapToStyles(Object.assign({}, commonStyles, {
      offsets: state.modifiersData.arrow,
      position: 'absolute',
      adaptive: false,
      roundOffsets: roundOffsets
    })));
  }

  state.attributes.popper = Object.assign({}, state.attributes.popper, {
    'data-popper-placement': state.placement
  });
} // eslint-disable-next-line import/no-unused-modules


var computeStyles$1 = {
  name: 'computeStyles',
  enabled: true,
  phase: 'beforeWrite',
  fn: computeStyles,
  data: {}
};

var passive = {
  passive: true
};

function effect(_ref) {
  var state = _ref.state,
      instance = _ref.instance,
      options = _ref.options;
  var _options$scroll = options.scroll,
      scroll = _options$scroll === void 0 ? true : _options$scroll,
      _options$resize = options.resize,
      resize = _options$resize === void 0 ? true : _options$resize;
  var window = getWindow(state.elements.popper);
  var scrollParents = [].concat(state.scrollParents.reference, state.scrollParents.popper);

  if (scroll) {
    scrollParents.forEach(function (scrollParent) {
      scrollParent.addEventListener('scroll', instance.update, passive);
    });
  }

  if (resize) {
    window.addEventListener('resize', instance.update, passive);
  }

  return function () {
    if (scroll) {
      scrollParents.forEach(function (scrollParent) {
        scrollParent.removeEventListener('scroll', instance.update, passive);
      });
    }

    if (resize) {
      window.removeEventListener('resize', instance.update, passive);
    }
  };
} // eslint-disable-next-line import/no-unused-modules


var eventListeners = {
  name: 'eventListeners',
  enabled: true,
  phase: 'write',
  fn: function fn() {},
  effect: effect,
  data: {}
};

var hash$1 = {
  left: 'right',
  right: 'left',
  bottom: 'top',
  top: 'bottom'
};
function getOppositePlacement(placement) {
  return placement.replace(/left|right|bottom|top/g, function (matched) {
    return hash$1[matched];
  });
}

var hash = {
  start: 'end',
  end: 'start'
};
function getOppositeVariationPlacement(placement) {
  return placement.replace(/start|end/g, function (matched) {
    return hash[matched];
  });
}

function getWindowScroll(node) {
  var win = getWindow(node);
  var scrollLeft = win.pageXOffset;
  var scrollTop = win.pageYOffset;
  return {
    scrollLeft: scrollLeft,
    scrollTop: scrollTop
  };
}

function getWindowScrollBarX(element) {
  // If <html> has a CSS width greater than the viewport, then this will be
  // incorrect for RTL.
  // Popper 1 is broken in this case and never had a bug report so let's assume
  // it's not an issue. I don't think anyone ever specifies width on <html>
  // anyway.
  // Browsers where the left scrollbar doesn't cause an issue report `0` for
  // this (e.g. Edge 2019, IE11, Safari)
  return getBoundingClientRect(getDocumentElement(element)).left + getWindowScroll(element).scrollLeft;
}

function getViewportRect(element, strategy) {
  var win = getWindow(element);
  var html = getDocumentElement(element);
  var visualViewport = win.visualViewport;
  var width = html.clientWidth;
  var height = html.clientHeight;
  var x = 0;
  var y = 0;

  if (visualViewport) {
    width = visualViewport.width;
    height = visualViewport.height;
    var layoutViewport = isLayoutViewport();

    if (layoutViewport || !layoutViewport && strategy === 'fixed') {
      x = visualViewport.offsetLeft;
      y = visualViewport.offsetTop;
    }
  }

  return {
    width: width,
    height: height,
    x: x + getWindowScrollBarX(element),
    y: y
  };
}

// of the `<html>` and `<body>` rect bounds if horizontally scrollable

function getDocumentRect(element) {
  var _element$ownerDocumen;

  var html = getDocumentElement(element);
  var winScroll = getWindowScroll(element);
  var body = (_element$ownerDocumen = element.ownerDocument) == null ? void 0 : _element$ownerDocumen.body;
  var width = max(html.scrollWidth, html.clientWidth, body ? body.scrollWidth : 0, body ? body.clientWidth : 0);
  var height = max(html.scrollHeight, html.clientHeight, body ? body.scrollHeight : 0, body ? body.clientHeight : 0);
  var x = -winScroll.scrollLeft + getWindowScrollBarX(element);
  var y = -winScroll.scrollTop;

  if (getComputedStyle(body || html).direction === 'rtl') {
    x += max(html.clientWidth, body ? body.clientWidth : 0) - width;
  }

  return {
    width: width,
    height: height,
    x: x,
    y: y
  };
}

function isScrollParent(element) {
  // Firefox wants us to check `-x` and `-y` variations as well
  var _getComputedStyle = getComputedStyle(element),
      overflow = _getComputedStyle.overflow,
      overflowX = _getComputedStyle.overflowX,
      overflowY = _getComputedStyle.overflowY;

  return /auto|scroll|overlay|hidden/.test(overflow + overflowY + overflowX);
}

function getScrollParent(node) {
  if (['html', 'body', '#document'].indexOf(getNodeName(node)) >= 0) {
    // $FlowFixMe[incompatible-return]: assume body is always available
    return node.ownerDocument.body;
  }

  if (isHTMLElement(node) && isScrollParent(node)) {
    return node;
  }

  return getScrollParent(getParentNode(node));
}

/*
given a DOM element, return the list of all scroll parents, up the list of ancesors
until we get to the top window object. This list is what we attach scroll listeners
to, because if any of these parent elements scroll, we'll need to re-calculate the
reference element's position.
*/

function listScrollParents(element, list) {
  var _element$ownerDocumen;

  if (list === void 0) {
    list = [];
  }

  var scrollParent = getScrollParent(element);
  var isBody = scrollParent === ((_element$ownerDocumen = element.ownerDocument) == null ? void 0 : _element$ownerDocumen.body);
  var win = getWindow(scrollParent);
  var target = isBody ? [win].concat(win.visualViewport || [], isScrollParent(scrollParent) ? scrollParent : []) : scrollParent;
  var updatedList = list.concat(target);
  return isBody ? updatedList : // $FlowFixMe[incompatible-call]: isBody tells us target will be an HTMLElement here
  updatedList.concat(listScrollParents(getParentNode(target)));
}

function rectToClientRect(rect) {
  return Object.assign({}, rect, {
    left: rect.x,
    top: rect.y,
    right: rect.x + rect.width,
    bottom: rect.y + rect.height
  });
}

function getInnerBoundingClientRect(element, strategy) {
  var rect = getBoundingClientRect(element, false, strategy === 'fixed');
  rect.top = rect.top + element.clientTop;
  rect.left = rect.left + element.clientLeft;
  rect.bottom = rect.top + element.clientHeight;
  rect.right = rect.left + element.clientWidth;
  rect.width = element.clientWidth;
  rect.height = element.clientHeight;
  rect.x = rect.left;
  rect.y = rect.top;
  return rect;
}

function getClientRectFromMixedType(element, clippingParent, strategy) {
  return clippingParent === viewport ? rectToClientRect(getViewportRect(element, strategy)) : isElement(clippingParent) ? getInnerBoundingClientRect(clippingParent, strategy) : rectToClientRect(getDocumentRect(getDocumentElement(element)));
} // A "clipping parent" is an overflowable container with the characteristic of
// clipping (or hiding) overflowing elements with a position different from
// `initial`


function getClippingParents(element) {
  var clippingParents = listScrollParents(getParentNode(element));
  var canEscapeClipping = ['absolute', 'fixed'].indexOf(getComputedStyle(element).position) >= 0;
  var clipperElement = canEscapeClipping && isHTMLElement(element) ? getOffsetParent(element) : element;

  if (!isElement(clipperElement)) {
    return [];
  } // $FlowFixMe[incompatible-return]: https://github.com/facebook/flow/issues/1414


  return clippingParents.filter(function (clippingParent) {
    return isElement(clippingParent) && contains(clippingParent, clipperElement) && getNodeName(clippingParent) !== 'body';
  });
} // Gets the maximum area that the element is visible in due to any number of
// clipping parents


function getClippingRect(element, boundary, rootBoundary, strategy) {
  var mainClippingParents = boundary === 'clippingParents' ? getClippingParents(element) : [].concat(boundary);
  var clippingParents = [].concat(mainClippingParents, [rootBoundary]);
  var firstClippingParent = clippingParents[0];
  var clippingRect = clippingParents.reduce(function (accRect, clippingParent) {
    var rect = getClientRectFromMixedType(element, clippingParent, strategy);
    accRect.top = max(rect.top, accRect.top);
    accRect.right = min(rect.right, accRect.right);
    accRect.bottom = min(rect.bottom, accRect.bottom);
    accRect.left = max(rect.left, accRect.left);
    return accRect;
  }, getClientRectFromMixedType(element, firstClippingParent, strategy));
  clippingRect.width = clippingRect.right - clippingRect.left;
  clippingRect.height = clippingRect.bottom - clippingRect.top;
  clippingRect.x = clippingRect.left;
  clippingRect.y = clippingRect.top;
  return clippingRect;
}

function computeOffsets(_ref) {
  var reference = _ref.reference,
      element = _ref.element,
      placement = _ref.placement;
  var basePlacement = placement ? getBasePlacement(placement) : null;
  var variation = placement ? getVariation(placement) : null;
  var commonX = reference.x + reference.width / 2 - element.width / 2;
  var commonY = reference.y + reference.height / 2 - element.height / 2;
  var offsets;

  switch (basePlacement) {
    case top:
      offsets = {
        x: commonX,
        y: reference.y - element.height
      };
      break;

    case bottom:
      offsets = {
        x: commonX,
        y: reference.y + reference.height
      };
      break;

    case right:
      offsets = {
        x: reference.x + reference.width,
        y: commonY
      };
      break;

    case left:
      offsets = {
        x: reference.x - element.width,
        y: commonY
      };
      break;

    default:
      offsets = {
        x: reference.x,
        y: reference.y
      };
  }

  var mainAxis = basePlacement ? getMainAxisFromPlacement(basePlacement) : null;

  if (mainAxis != null) {
    var len = mainAxis === 'y' ? 'height' : 'width';

    switch (variation) {
      case start:
        offsets[mainAxis] = offsets[mainAxis] - (reference[len] / 2 - element[len] / 2);
        break;

      case end:
        offsets[mainAxis] = offsets[mainAxis] + (reference[len] / 2 - element[len] / 2);
        break;
    }
  }

  return offsets;
}

function detectOverflow(state, options) {
  if (options === void 0) {
    options = {};
  }

  var _options = options,
      _options$placement = _options.placement,
      placement = _options$placement === void 0 ? state.placement : _options$placement,
      _options$strategy = _options.strategy,
      strategy = _options$strategy === void 0 ? state.strategy : _options$strategy,
      _options$boundary = _options.boundary,
      boundary = _options$boundary === void 0 ? clippingParents : _options$boundary,
      _options$rootBoundary = _options.rootBoundary,
      rootBoundary = _options$rootBoundary === void 0 ? viewport : _options$rootBoundary,
      _options$elementConte = _options.elementContext,
      elementContext = _options$elementConte === void 0 ? popper : _options$elementConte,
      _options$altBoundary = _options.altBoundary,
      altBoundary = _options$altBoundary === void 0 ? false : _options$altBoundary,
      _options$padding = _options.padding,
      padding = _options$padding === void 0 ? 0 : _options$padding;
  var paddingObject = mergePaddingObject(typeof padding !== 'number' ? padding : expandToHashMap(padding, basePlacements));
  var altContext = elementContext === popper ? reference : popper;
  var popperRect = state.rects.popper;
  var element = state.elements[altBoundary ? altContext : elementContext];
  var clippingClientRect = getClippingRect(isElement(element) ? element : element.contextElement || getDocumentElement(state.elements.popper), boundary, rootBoundary, strategy);
  var referenceClientRect = getBoundingClientRect(state.elements.reference);
  var popperOffsets = computeOffsets({
    reference: referenceClientRect,
    element: popperRect,
    placement: placement
  });
  var popperClientRect = rectToClientRect(Object.assign({}, popperRect, popperOffsets));
  var elementClientRect = elementContext === popper ? popperClientRect : referenceClientRect; // positive = overflowing the clipping rect
  // 0 or negative = within the clipping rect

  var overflowOffsets = {
    top: clippingClientRect.top - elementClientRect.top + paddingObject.top,
    bottom: elementClientRect.bottom - clippingClientRect.bottom + paddingObject.bottom,
    left: clippingClientRect.left - elementClientRect.left + paddingObject.left,
    right: elementClientRect.right - clippingClientRect.right + paddingObject.right
  };
  var offsetData = state.modifiersData.offset; // Offsets can be applied only to the popper element

  if (elementContext === popper && offsetData) {
    var offset = offsetData[placement];
    Object.keys(overflowOffsets).forEach(function (key) {
      var multiply = [right, bottom].indexOf(key) >= 0 ? 1 : -1;
      var axis = [top, bottom].indexOf(key) >= 0 ? 'y' : 'x';
      overflowOffsets[key] += offset[axis] * multiply;
    });
  }

  return overflowOffsets;
}

function computeAutoPlacement(state, options) {
  if (options === void 0) {
    options = {};
  }

  var _options = options,
      placement = _options.placement,
      boundary = _options.boundary,
      rootBoundary = _options.rootBoundary,
      padding = _options.padding,
      flipVariations = _options.flipVariations,
      _options$allowedAutoP = _options.allowedAutoPlacements,
      allowedAutoPlacements = _options$allowedAutoP === void 0 ? placements : _options$allowedAutoP;
  var variation = getVariation(placement);
  var placements$1 = variation ? flipVariations ? variationPlacements : variationPlacements.filter(function (placement) {
    return getVariation(placement) === variation;
  }) : basePlacements;
  var allowedPlacements = placements$1.filter(function (placement) {
    return allowedAutoPlacements.indexOf(placement) >= 0;
  });

  if (allowedPlacements.length === 0) {
    allowedPlacements = placements$1;
  } // $FlowFixMe[incompatible-type]: Flow seems to have problems with two array unions...


  var overflows = allowedPlacements.reduce(function (acc, placement) {
    acc[placement] = detectOverflow(state, {
      placement: placement,
      boundary: boundary,
      rootBoundary: rootBoundary,
      padding: padding
    })[getBasePlacement(placement)];
    return acc;
  }, {});
  return Object.keys(overflows).sort(function (a, b) {
    return overflows[a] - overflows[b];
  });
}

function getExpandedFallbackPlacements(placement) {
  if (getBasePlacement(placement) === auto) {
    return [];
  }

  var oppositePlacement = getOppositePlacement(placement);
  return [getOppositeVariationPlacement(placement), oppositePlacement, getOppositeVariationPlacement(oppositePlacement)];
}

function flip(_ref) {
  var state = _ref.state,
      options = _ref.options,
      name = _ref.name;

  if (state.modifiersData[name]._skip) {
    return;
  }

  var _options$mainAxis = options.mainAxis,
      checkMainAxis = _options$mainAxis === void 0 ? true : _options$mainAxis,
      _options$altAxis = options.altAxis,
      checkAltAxis = _options$altAxis === void 0 ? true : _options$altAxis,
      specifiedFallbackPlacements = options.fallbackPlacements,
      padding = options.padding,
      boundary = options.boundary,
      rootBoundary = options.rootBoundary,
      altBoundary = options.altBoundary,
      _options$flipVariatio = options.flipVariations,
      flipVariations = _options$flipVariatio === void 0 ? true : _options$flipVariatio,
      allowedAutoPlacements = options.allowedAutoPlacements;
  var preferredPlacement = state.options.placement;
  var basePlacement = getBasePlacement(preferredPlacement);
  var isBasePlacement = basePlacement === preferredPlacement;
  var fallbackPlacements = specifiedFallbackPlacements || (isBasePlacement || !flipVariations ? [getOppositePlacement(preferredPlacement)] : getExpandedFallbackPlacements(preferredPlacement));
  var placements = [preferredPlacement].concat(fallbackPlacements).reduce(function (acc, placement) {
    return acc.concat(getBasePlacement(placement) === auto ? computeAutoPlacement(state, {
      placement: placement,
      boundary: boundary,
      rootBoundary: rootBoundary,
      padding: padding,
      flipVariations: flipVariations,
      allowedAutoPlacements: allowedAutoPlacements
    }) : placement);
  }, []);
  var referenceRect = state.rects.reference;
  var popperRect = state.rects.popper;
  var checksMap = new Map();
  var makeFallbackChecks = true;
  var firstFittingPlacement = placements[0];

  for (var i = 0; i < placements.length; i++) {
    var placement = placements[i];

    var _basePlacement = getBasePlacement(placement);

    var isStartVariation = getVariation(placement) === start;
    var isVertical = [top, bottom].indexOf(_basePlacement) >= 0;
    var len = isVertical ? 'width' : 'height';
    var overflow = detectOverflow(state, {
      placement: placement,
      boundary: boundary,
      rootBoundary: rootBoundary,
      altBoundary: altBoundary,
      padding: padding
    });
    var mainVariationSide = isVertical ? isStartVariation ? right : left : isStartVariation ? bottom : top;

    if (referenceRect[len] > popperRect[len]) {
      mainVariationSide = getOppositePlacement(mainVariationSide);
    }

    var altVariationSide = getOppositePlacement(mainVariationSide);
    var checks = [];

    if (checkMainAxis) {
      checks.push(overflow[_basePlacement] <= 0);
    }

    if (checkAltAxis) {
      checks.push(overflow[mainVariationSide] <= 0, overflow[altVariationSide] <= 0);
    }

    if (checks.every(function (check) {
      return check;
    })) {
      firstFittingPlacement = placement;
      makeFallbackChecks = false;
      break;
    }

    checksMap.set(placement, checks);
  }

  if (makeFallbackChecks) {
    // `2` may be desired in some cases – research later
    var numberOfChecks = flipVariations ? 3 : 1;

    var _loop = function _loop(_i) {
      var fittingPlacement = placements.find(function (placement) {
        var checks = checksMap.get(placement);

        if (checks) {
          return checks.slice(0, _i).every(function (check) {
            return check;
          });
        }
      });

      if (fittingPlacement) {
        firstFittingPlacement = fittingPlacement;
        return "break";
      }
    };

    for (var _i = numberOfChecks; _i > 0; _i--) {
      var _ret = _loop(_i);

      if (_ret === "break") break;
    }
  }

  if (state.placement !== firstFittingPlacement) {
    state.modifiersData[name]._skip = true;
    state.placement = firstFittingPlacement;
    state.reset = true;
  }
} // eslint-disable-next-line import/no-unused-modules


var flip$1 = {
  name: 'flip',
  enabled: true,
  phase: 'main',
  fn: flip,
  requiresIfExists: ['offset'],
  data: {
    _skip: false
  }
};

function getSideOffsets(overflow, rect, preventedOffsets) {
  if (preventedOffsets === void 0) {
    preventedOffsets = {
      x: 0,
      y: 0
    };
  }

  return {
    top: overflow.top - rect.height - preventedOffsets.y,
    right: overflow.right - rect.width + preventedOffsets.x,
    bottom: overflow.bottom - rect.height + preventedOffsets.y,
    left: overflow.left - rect.width - preventedOffsets.x
  };
}

function isAnySideFullyClipped(overflow) {
  return [top, right, bottom, left].some(function (side) {
    return overflow[side] >= 0;
  });
}

function hide(_ref) {
  var state = _ref.state,
      name = _ref.name;
  var referenceRect = state.rects.reference;
  var popperRect = state.rects.popper;
  var preventedOffsets = state.modifiersData.preventOverflow;
  var referenceOverflow = detectOverflow(state, {
    elementContext: 'reference'
  });
  var popperAltOverflow = detectOverflow(state, {
    altBoundary: true
  });
  var referenceClippingOffsets = getSideOffsets(referenceOverflow, referenceRect);
  var popperEscapeOffsets = getSideOffsets(popperAltOverflow, popperRect, preventedOffsets);
  var isReferenceHidden = isAnySideFullyClipped(referenceClippingOffsets);
  var hasPopperEscaped = isAnySideFullyClipped(popperEscapeOffsets);
  state.modifiersData[name] = {
    referenceClippingOffsets: referenceClippingOffsets,
    popperEscapeOffsets: popperEscapeOffsets,
    isReferenceHidden: isReferenceHidden,
    hasPopperEscaped: hasPopperEscaped
  };
  state.attributes.popper = Object.assign({}, state.attributes.popper, {
    'data-popper-reference-hidden': isReferenceHidden,
    'data-popper-escaped': hasPopperEscaped
  });
} // eslint-disable-next-line import/no-unused-modules


var hide$1 = {
  name: 'hide',
  enabled: true,
  phase: 'main',
  requiresIfExists: ['preventOverflow'],
  fn: hide
};

function distanceAndSkiddingToXY(placement, rects, offset) {
  var basePlacement = getBasePlacement(placement);
  var invertDistance = [left, top].indexOf(basePlacement) >= 0 ? -1 : 1;

  var _ref = typeof offset === 'function' ? offset(Object.assign({}, rects, {
    placement: placement
  })) : offset,
      skidding = _ref[0],
      distance = _ref[1];

  skidding = skidding || 0;
  distance = (distance || 0) * invertDistance;
  return [left, right].indexOf(basePlacement) >= 0 ? {
    x: distance,
    y: skidding
  } : {
    x: skidding,
    y: distance
  };
}

function offset(_ref2) {
  var state = _ref2.state,
      options = _ref2.options,
      name = _ref2.name;
  var _options$offset = options.offset,
      offset = _options$offset === void 0 ? [0, 0] : _options$offset;
  var data = placements.reduce(function (acc, placement) {
    acc[placement] = distanceAndSkiddingToXY(placement, state.rects, offset);
    return acc;
  }, {});
  var _data$state$placement = data[state.placement],
      x = _data$state$placement.x,
      y = _data$state$placement.y;

  if (state.modifiersData.popperOffsets != null) {
    state.modifiersData.popperOffsets.x += x;
    state.modifiersData.popperOffsets.y += y;
  }

  state.modifiersData[name] = data;
} // eslint-disable-next-line import/no-unused-modules


var offset$1 = {
  name: 'offset',
  enabled: true,
  phase: 'main',
  requires: ['popperOffsets'],
  fn: offset
};

function popperOffsets(_ref) {
  var state = _ref.state,
      name = _ref.name;
  // Offsets are the actual position the popper needs to have to be
  // properly positioned near its reference element
  // This is the most basic placement, and will be adjusted by
  // the modifiers in the next step
  state.modifiersData[name] = computeOffsets({
    reference: state.rects.reference,
    element: state.rects.popper,
    placement: state.placement
  });
} // eslint-disable-next-line import/no-unused-modules


var popperOffsets$1 = {
  name: 'popperOffsets',
  enabled: true,
  phase: 'read',
  fn: popperOffsets,
  data: {}
};

function getAltAxis(axis) {
  return axis === 'x' ? 'y' : 'x';
}

function preventOverflow(_ref) {
  var state = _ref.state,
      options = _ref.options,
      name = _ref.name;
  var _options$mainAxis = options.mainAxis,
      checkMainAxis = _options$mainAxis === void 0 ? true : _options$mainAxis,
      _options$altAxis = options.altAxis,
      checkAltAxis = _options$altAxis === void 0 ? false : _options$altAxis,
      boundary = options.boundary,
      rootBoundary = options.rootBoundary,
      altBoundary = options.altBoundary,
      padding = options.padding,
      _options$tether = options.tether,
      tether = _options$tether === void 0 ? true : _options$tether,
      _options$tetherOffset = options.tetherOffset,
      tetherOffset = _options$tetherOffset === void 0 ? 0 : _options$tetherOffset;
  var overflow = detectOverflow(state, {
    boundary: boundary,
    rootBoundary: rootBoundary,
    padding: padding,
    altBoundary: altBoundary
  });
  var basePlacement = getBasePlacement(state.placement);
  var variation = getVariation(state.placement);
  var isBasePlacement = !variation;
  var mainAxis = getMainAxisFromPlacement(basePlacement);
  var altAxis = getAltAxis(mainAxis);
  var popperOffsets = state.modifiersData.popperOffsets;
  var referenceRect = state.rects.reference;
  var popperRect = state.rects.popper;
  var tetherOffsetValue = typeof tetherOffset === 'function' ? tetherOffset(Object.assign({}, state.rects, {
    placement: state.placement
  })) : tetherOffset;
  var normalizedTetherOffsetValue = typeof tetherOffsetValue === 'number' ? {
    mainAxis: tetherOffsetValue,
    altAxis: tetherOffsetValue
  } : Object.assign({
    mainAxis: 0,
    altAxis: 0
  }, tetherOffsetValue);
  var offsetModifierState = state.modifiersData.offset ? state.modifiersData.offset[state.placement] : null;
  var data = {
    x: 0,
    y: 0
  };

  if (!popperOffsets) {
    return;
  }

  if (checkMainAxis) {
    var _offsetModifierState$;

    var mainSide = mainAxis === 'y' ? top : left;
    var altSide = mainAxis === 'y' ? bottom : right;
    var len = mainAxis === 'y' ? 'height' : 'width';
    var offset = popperOffsets[mainAxis];
    var min$1 = offset + overflow[mainSide];
    var max$1 = offset - overflow[altSide];
    var additive = tether ? -popperRect[len] / 2 : 0;
    var minLen = variation === start ? referenceRect[len] : popperRect[len];
    var maxLen = variation === start ? -popperRect[len] : -referenceRect[len]; // We need to include the arrow in the calculation so the arrow doesn't go
    // outside the reference bounds

    var arrowElement = state.elements.arrow;
    var arrowRect = tether && arrowElement ? getLayoutRect(arrowElement) : {
      width: 0,
      height: 0
    };
    var arrowPaddingObject = state.modifiersData['arrow#persistent'] ? state.modifiersData['arrow#persistent'].padding : getFreshSideObject();
    var arrowPaddingMin = arrowPaddingObject[mainSide];
    var arrowPaddingMax = arrowPaddingObject[altSide]; // If the reference length is smaller than the arrow length, we don't want
    // to include its full size in the calculation. If the reference is small
    // and near the edge of a boundary, the popper can overflow even if the
    // reference is not overflowing as well (e.g. virtual elements with no
    // width or height)

    var arrowLen = within(0, referenceRect[len], arrowRect[len]);
    var minOffset = isBasePlacement ? referenceRect[len] / 2 - additive - arrowLen - arrowPaddingMin - normalizedTetherOffsetValue.mainAxis : minLen - arrowLen - arrowPaddingMin - normalizedTetherOffsetValue.mainAxis;
    var maxOffset = isBasePlacement ? -referenceRect[len] / 2 + additive + arrowLen + arrowPaddingMax + normalizedTetherOffsetValue.mainAxis : maxLen + arrowLen + arrowPaddingMax + normalizedTetherOffsetValue.mainAxis;
    var arrowOffsetParent = state.elements.arrow && getOffsetParent(state.elements.arrow);
    var clientOffset = arrowOffsetParent ? mainAxis === 'y' ? arrowOffsetParent.clientTop || 0 : arrowOffsetParent.clientLeft || 0 : 0;
    var offsetModifierValue = (_offsetModifierState$ = offsetModifierState == null ? void 0 : offsetModifierState[mainAxis]) != null ? _offsetModifierState$ : 0;
    var tetherMin = offset + minOffset - offsetModifierValue - clientOffset;
    var tetherMax = offset + maxOffset - offsetModifierValue;
    var preventedOffset = within(tether ? min(min$1, tetherMin) : min$1, offset, tether ? max(max$1, tetherMax) : max$1);
    popperOffsets[mainAxis] = preventedOffset;
    data[mainAxis] = preventedOffset - offset;
  }

  if (checkAltAxis) {
    var _offsetModifierState$2;

    var _mainSide = mainAxis === 'x' ? top : left;

    var _altSide = mainAxis === 'x' ? bottom : right;

    var _offset = popperOffsets[altAxis];

    var _len = altAxis === 'y' ? 'height' : 'width';

    var _min = _offset + overflow[_mainSide];

    var _max = _offset - overflow[_altSide];

    var isOriginSide = [top, left].indexOf(basePlacement) !== -1;

    var _offsetModifierValue = (_offsetModifierState$2 = offsetModifierState == null ? void 0 : offsetModifierState[altAxis]) != null ? _offsetModifierState$2 : 0;

    var _tetherMin = isOriginSide ? _min : _offset - referenceRect[_len] - popperRect[_len] - _offsetModifierValue + normalizedTetherOffsetValue.altAxis;

    var _tetherMax = isOriginSide ? _offset + referenceRect[_len] + popperRect[_len] - _offsetModifierValue - normalizedTetherOffsetValue.altAxis : _max;

    var _preventedOffset = tether && isOriginSide ? withinMaxClamp(_tetherMin, _offset, _tetherMax) : within(tether ? _tetherMin : _min, _offset, tether ? _tetherMax : _max);

    popperOffsets[altAxis] = _preventedOffset;
    data[altAxis] = _preventedOffset - _offset;
  }

  state.modifiersData[name] = data;
} // eslint-disable-next-line import/no-unused-modules


var preventOverflow$1 = {
  name: 'preventOverflow',
  enabled: true,
  phase: 'main',
  fn: preventOverflow,
  requiresIfExists: ['offset']
};

function getHTMLElementScroll(element) {
  return {
    scrollLeft: element.scrollLeft,
    scrollTop: element.scrollTop
  };
}

function getNodeScroll(node) {
  if (node === getWindow(node) || !isHTMLElement(node)) {
    return getWindowScroll(node);
  } else {
    return getHTMLElementScroll(node);
  }
}

function isElementScaled(element) {
  var rect = element.getBoundingClientRect();
  var scaleX = round(rect.width) / element.offsetWidth || 1;
  var scaleY = round(rect.height) / element.offsetHeight || 1;
  return scaleX !== 1 || scaleY !== 1;
} // Returns the composite rect of an element relative to its offsetParent.
// Composite means it takes into account transforms as well as layout.


function getCompositeRect(elementOrVirtualElement, offsetParent, isFixed) {
  if (isFixed === void 0) {
    isFixed = false;
  }

  var isOffsetParentAnElement = isHTMLElement(offsetParent);
  var offsetParentIsScaled = isHTMLElement(offsetParent) && isElementScaled(offsetParent);
  var documentElement = getDocumentElement(offsetParent);
  var rect = getBoundingClientRect(elementOrVirtualElement, offsetParentIsScaled, isFixed);
  var scroll = {
    scrollLeft: 0,
    scrollTop: 0
  };
  var offsets = {
    x: 0,
    y: 0
  };

  if (isOffsetParentAnElement || !isOffsetParentAnElement && !isFixed) {
    if (getNodeName(offsetParent) !== 'body' || // https://github.com/popperjs/popper-core/issues/1078
    isScrollParent(documentElement)) {
      scroll = getNodeScroll(offsetParent);
    }

    if (isHTMLElement(offsetParent)) {
      offsets = getBoundingClientRect(offsetParent, true);
      offsets.x += offsetParent.clientLeft;
      offsets.y += offsetParent.clientTop;
    } else if (documentElement) {
      offsets.x = getWindowScrollBarX(documentElement);
    }
  }

  return {
    x: rect.left + scroll.scrollLeft - offsets.x,
    y: rect.top + scroll.scrollTop - offsets.y,
    width: rect.width,
    height: rect.height
  };
}

function order(modifiers) {
  var map = new Map();
  var visited = new Set();
  var result = [];
  modifiers.forEach(function (modifier) {
    map.set(modifier.name, modifier);
  }); // On visiting object, check for its dependencies and visit them recursively

  function sort(modifier) {
    visited.add(modifier.name);
    var requires = [].concat(modifier.requires || [], modifier.requiresIfExists || []);
    requires.forEach(function (dep) {
      if (!visited.has(dep)) {
        var depModifier = map.get(dep);

        if (depModifier) {
          sort(depModifier);
        }
      }
    });
    result.push(modifier);
  }

  modifiers.forEach(function (modifier) {
    if (!visited.has(modifier.name)) {
      // check for visited object
      sort(modifier);
    }
  });
  return result;
}

function orderModifiers(modifiers) {
  // order based on dependencies
  var orderedModifiers = order(modifiers); // order based on phase

  return modifierPhases.reduce(function (acc, phase) {
    return acc.concat(orderedModifiers.filter(function (modifier) {
      return modifier.phase === phase;
    }));
  }, []);
}

function debounce(fn) {
  var pending;
  return function () {
    if (!pending) {
      pending = new Promise(function (resolve) {
        Promise.resolve().then(function () {
          pending = undefined;
          resolve(fn());
        });
      });
    }

    return pending;
  };
}

function mergeByName(modifiers) {
  var merged = modifiers.reduce(function (merged, current) {
    var existing = merged[current.name];
    merged[current.name] = existing ? Object.assign({}, existing, current, {
      options: Object.assign({}, existing.options, current.options),
      data: Object.assign({}, existing.data, current.data)
    }) : current;
    return merged;
  }, {}); // IE11 does not support Object.values

  return Object.keys(merged).map(function (key) {
    return merged[key];
  });
}

var DEFAULT_OPTIONS = {
  placement: 'bottom',
  modifiers: [],
  strategy: 'absolute'
};

function areValidElements() {
  for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
    args[_key] = arguments[_key];
  }

  return !args.some(function (element) {
    return !(element && typeof element.getBoundingClientRect === 'function');
  });
}

function popperGenerator(generatorOptions) {
  if (generatorOptions === void 0) {
    generatorOptions = {};
  }

  var _generatorOptions = generatorOptions,
      _generatorOptions$def = _generatorOptions.defaultModifiers,
      defaultModifiers = _generatorOptions$def === void 0 ? [] : _generatorOptions$def,
      _generatorOptions$def2 = _generatorOptions.defaultOptions,
      defaultOptions = _generatorOptions$def2 === void 0 ? DEFAULT_OPTIONS : _generatorOptions$def2;
  return function createPopper(reference, popper, options) {
    if (options === void 0) {
      options = defaultOptions;
    }

    var state = {
      placement: 'bottom',
      orderedModifiers: [],
      options: Object.assign({}, DEFAULT_OPTIONS, defaultOptions),
      modifiersData: {},
      elements: {
        reference: reference,
        popper: popper
      },
      attributes: {},
      styles: {}
    };
    var effectCleanupFns = [];
    var isDestroyed = false;
    var instance = {
      state: state,
      setOptions: function setOptions(setOptionsAction) {
        var options = typeof setOptionsAction === 'function' ? setOptionsAction(state.options) : setOptionsAction;
        cleanupModifierEffects();
        state.options = Object.assign({}, defaultOptions, state.options, options);
        state.scrollParents = {
          reference: isElement(reference) ? listScrollParents(reference) : reference.contextElement ? listScrollParents(reference.contextElement) : [],
          popper: listScrollParents(popper)
        }; // Orders the modifiers based on their dependencies and `phase`
        // properties

        var orderedModifiers = orderModifiers(mergeByName([].concat(defaultModifiers, state.options.modifiers))); // Strip out disabled modifiers

        state.orderedModifiers = orderedModifiers.filter(function (m) {
          return m.enabled;
        });
        runModifierEffects();
        return instance.update();
      },
      // Sync update – it will always be executed, even if not necessary. This
      // is useful for low frequency updates where sync behavior simplifies the
      // logic.
      // For high frequency updates (e.g. `resize` and `scroll` events), always
      // prefer the async Popper#update method
      forceUpdate: function forceUpdate() {
        if (isDestroyed) {
          return;
        }

        var _state$elements = state.elements,
            reference = _state$elements.reference,
            popper = _state$elements.popper; // Don't proceed if `reference` or `popper` are not valid elements
        // anymore

        if (!areValidElements(reference, popper)) {
          return;
        } // Store the reference and popper rects to be read by modifiers


        state.rects = {
          reference: getCompositeRect(reference, getOffsetParent(popper), state.options.strategy === 'fixed'),
          popper: getLayoutRect(popper)
        }; // Modifiers have the ability to reset the current update cycle. The
        // most common use case for this is the `flip` modifier changing the
        // placement, which then needs to re-run all the modifiers, because the
        // logic was previously ran for the previous placement and is therefore
        // stale/incorrect

        state.reset = false;
        state.placement = state.options.placement; // On each update cycle, the `modifiersData` property for each modifier
        // is filled with the initial data specified by the modifier. This means
        // it doesn't persist and is fresh on each update.
        // To ensure persistent data, use `${name}#persistent`

        state.orderedModifiers.forEach(function (modifier) {
          return state.modifiersData[modifier.name] = Object.assign({}, modifier.data);
        });

        for (var index = 0; index < state.orderedModifiers.length; index++) {
          if (state.reset === true) {
            state.reset = false;
            index = -1;
            continue;
          }

          var _state$orderedModifie = state.orderedModifiers[index],
              fn = _state$orderedModifie.fn,
              _state$orderedModifie2 = _state$orderedModifie.options,
              _options = _state$orderedModifie2 === void 0 ? {} : _state$orderedModifie2,
              name = _state$orderedModifie.name;

          if (typeof fn === 'function') {
            state = fn({
              state: state,
              options: _options,
              name: name,
              instance: instance
            }) || state;
          }
        }
      },
      // Async and optimistically optimized update – it will not be executed if
      // not necessary (debounced to run at most once-per-tick)
      update: debounce(function () {
        return new Promise(function (resolve) {
          instance.forceUpdate();
          resolve(state);
        });
      }),
      destroy: function destroy() {
        cleanupModifierEffects();
        isDestroyed = true;
      }
    };

    if (!areValidElements(reference, popper)) {
      return instance;
    }

    instance.setOptions(options).then(function (state) {
      if (!isDestroyed && options.onFirstUpdate) {
        options.onFirstUpdate(state);
      }
    }); // Modifiers have the ability to execute arbitrary code before the first
    // update cycle runs. They will be executed in the same order as the update
    // cycle. This is useful when a modifier adds some persistent data that
    // other modifiers need to use, but the modifier is run after the dependent
    // one.

    function runModifierEffects() {
      state.orderedModifiers.forEach(function (_ref) {
        var name = _ref.name,
            _ref$options = _ref.options,
            options = _ref$options === void 0 ? {} : _ref$options,
            effect = _ref.effect;

        if (typeof effect === 'function') {
          var cleanupFn = effect({
            state: state,
            name: name,
            instance: instance,
            options: options
          });

          var noopFn = function noopFn() {};

          effectCleanupFns.push(cleanupFn || noopFn);
        }
      });
    }

    function cleanupModifierEffects() {
      effectCleanupFns.forEach(function (fn) {
        return fn();
      });
      effectCleanupFns = [];
    }

    return instance;
  };
}

var defaultModifiers = [eventListeners, popperOffsets$1, computeStyles$1, applyStyles$1, offset$1, flip$1, preventOverflow$1, arrow$1, hide$1];
var createPopper = /*#__PURE__*/popperGenerator({
  defaultModifiers: defaultModifiers
}); // eslint-disable-next-line import/no-unused-modules

function styleInject(css, ref) {
  if ( ref === void 0 ) ref = {};
  var insertAt = ref.insertAt;

  if (!css || typeof document === 'undefined') { return; }

  var head = document.head || document.getElementsByTagName('head')[0];
  var style = document.createElement('style');
  style.type = 'text/css';

  if (insertAt === 'top') {
    if (head.firstChild) {
      head.insertBefore(style, head.firstChild);
    } else {
      head.appendChild(style);
    }
  } else {
    head.appendChild(style);
  }

  if (style.styleSheet) {
    style.styleSheet.cssText = css;
  } else {
    style.appendChild(document.createTextNode(css));
  }
}

var css_248z$1$1 = ".basicui-select__ul {\n    list-style: none;\n    margin: 0px;\n    padding: 8px 0px;\n    max-height: 250px;\n    overflow: hidden auto;\n    /* border: 1px solid rgba(0, 0, 0, 0.175); */\n    border-radius: 4px;\n}\n\n.basicui-select__ul {\n    background-color: var(--basicui-bg-accent);\n    color: var(--basicui-fg);\n}\n\n.basicui-select__ul__search {\n    padding: 0 6px 6px 6px;\n}\n\n.basicui-select__ul__search input {\n    width: 100%;\n}\n\n.basicui-select__ul__li {\n    /* border-bottom: 1px solid #00000020; */\n}\n\n.basicui-select__ul__li:last-child {\n    border-bottom: none;\n}\n\n.basicui-select__ul__li__link {\n    width: 100%;\n    padding: 6px 6px;\n    font-size: var(--basicui-formelement-font-size);\n    font-weight: var(--basicui-formelement-font-weight);\n    text-align: left;\n    background-color: transparent;\n    color: var(--theme-black-900);\n    display: grid;\n    grid-template-columns: auto 1fr;\n    column-gap: 8px;\n    justify-items: flex-start;\n    align-items: center;\n    border: none;\n    box-shadow: none;\n    line-height: 1.5;\n    transition: 250ms background-color ease-in-out, 250ms color ease-in-out;\n}\n\n.basicui-dark .basicui-select__ul__li__link {\n    color: var(--theme-white-50);\n}\n\n.basicui-select__ul__li__indicator {\n    width: 16px;\n}\n\n.basicui-select__ul__li__indicator div {\n    display: flex;\n}\n\n.basicui-select__ul__li__indicator svg {\n    fill: var(--theme-black-900);\n}\n\n.basicui-dark .basicui-select__ul__li__indicator svg {\n    fill: var(--theme-white-50);\n}\n\n.basicui-select__ul__li__link--active,\n.basicui-select__ul__li__link:hover {\n    background-color: var(--basicui-bg-default-transparent);\n    /* color: var(--theme-primary-transparent-50i); */\n}\n\n/* .basicui-dark .basicui-select__ul__li__link--active,\n.basicui-dark .basicui-select__ul__li__link:hover {\n    background-color: var(--basicui-bg-default);\n    color: var(--basicui-fg-default);\n} */\n";
styleInject(css_248z$1$1);

var OptionsList = function (props) {
    var _a;
    var _b = React.useState(0), currentIndex = _b[0], setCurrentIndex = _b[1];
    var currentIndexRef = React.useRef(0);
    var searchReferenceElement = React.useRef(null);
    var optionsRef = React.useRef([]);
    React.useEffect(function () {
        setCurrentIndex(0);
        currentIndexRef.current = 0;
        optionsRef.current = props.options;
    }, [props.options]);
    React.useEffect(function () {
        if (props.referenceElement.current) {
            props.referenceElement.current.addEventListener('keydown', keydownEventHandler);
        }
        // if (props.popperElement.current) {
        //     props.popperElement.current.addEventListener('keydown', keydownEventHandler);
        // }
        return function () {
            if (props.referenceElement.current) {
                props.referenceElement.current.removeEventListener('keydown', keydownEventHandler);
            }
        };
    }, [props.referenceElement]);
    React.useEffect(function () {
        if (searchReferenceElement.current) {
            searchReferenceElement.current.addEventListener('keydown', keydownEventHandler);
        }
        // if (props.popperElement.current) {
        //     props.popperElement.current.addEventListener('keydown', keydownEventHandler);
        // }
        return function () {
            if (searchReferenceElement.current) {
                searchReferenceElement.current.removeEventListener('keydown', keydownEventHandler);
            }
        };
    }, [searchReferenceElement]);
    var keydownEventHandler = function (event) {
        switch (event.key) {
            case 'ArrowDown':
                event.preventDefault();
                navigateDown();
                break;
            case 'ArrowUp':
                event.preventDefault();
                navigateUp();
                break;
            case 'Enter':
                event.preventDefault();
                props.handleChange(event, currentIndexRef.current, optionsRef.current[currentIndexRef.current].value);
                break;
            case 'Tab':
                event.preventDefault();
                break;
            case 'Escape':
                event.preventDefault();
                props.handleClose();
                break;
        }
    };
    var navigateUp = function () {
        var _current = 0;
        if (currentIndexRef.current !== 0) {
            _current = currentIndexRef.current - 1;
        }
        else {
            optionsRef.current.length - 1;
        }
        currentIndexRef.current = _current;
        setCurrentIndex(_current);
    };
    var navigateDown = function () {
        var _current = 0;
        if (currentIndexRef.current < optionsRef.current.length - 1) {
            _current = currentIndexRef.current + 1;
        }
        currentIndexRef.current = _current;
        setCurrentIndex(_current);
    };
    var handleClick = function (event, index, option) {
        props.handleChange(event, index, option);
    };
    var handleSearchTextChange = function (event) {
        if (props.handleSearchTextChange) {
            props.handleSearchTextChange(event.target.value);
        }
    };
    return React.createElement("div", null,
        React.createElement("ul", { role: "listbox", className: "basicui-select__ul basicui-popup" },
            props.handleSearchTextChange && React.createElement("div", { className: "basicui-select__ul__search" },
                React.createElement("input", { ref: searchReferenceElement, className: "basicui-input", autoFocus: true, onInput: handleSearchTextChange, autoComplete: "none" })), (_a = props.options) === null || _a === void 0 ? void 0 :
            _a.map(function (option, index) { return (React.createElement("li", { key: index, role: "option", className: "basicui-select__ul__li" },
                React.createElement("button", { className: "basicui-select__ul__li__link ".concat(currentIndex === index ? 'basicui-select__ul__li__link--active' : ''), onClick: function (event) { return handleClick(event, index, option.value); } },
                    React.createElement("div", { className: "basicui-select__ul__li__indicator" }, props.value.includes(option.value + "") && React.createElement("div", null,
                        React.createElement("svg", { height: "16", viewBox: "0 0 16 16", version: "1.1", width: "16", "aria-hidden": "true" },
                            React.createElement("path", { fillRule: "evenodd", d: "M13.78 4.22a.75.75 0 010 1.06l-7.25 7.25a.75.75 0 01-1.06 0L2.22 9.28a.75.75 0 011.06-1.06L6 10.94l6.72-6.72a.75.75 0 011.06 0z" })))),
                    React.createElement("div", { className: "basicui-select__ul__li__text" }, option.label)))); })));
};

function isEmptyOrSpaces$1(str) {
    if (typeof str === 'number') {
        return !str || str === 0;
    }
    return !str || str.match(/^ *$/) !== null;
}

var css_248z$i = "";
styleInject(css_248z$i);

/**
 * FormElementMessage component
 */
var FormElementMessage = function (props) {
    return (React.createElement("div", { className: "basicui-form-element-".concat(props.type) }, props.text));
};

/**
 * Component to render input form element. For using it with standard html input, add css class basicui-input
 */
var Label = function (props) {
    return (React.createElement(React.Fragment, null,
        props.children && !isEmptyOrSpaces$1(props.children) && React.createElement(FormElementMessage, { text: props.children, type: "label" }),
        props.labelDesc && !isEmptyOrSpaces$1(props.labelDesc) && React.createElement(FormElementMessage, { text: props.labelDesc, type: "labeldesc" })));
};

/**
 * Component to render drop down input form element. Supports multi select and auto complete features
 */
var Select$1 = function (props) {
    var valueRef = React.useRef([]);
    var _a = React.useState([]), valuesText = _a[0], setValuesText = _a[1];
    var _b = React.useState(false), isVisible = _b[0], setIsVisible = _b[1];
    var referenceElement = React.useRef(null);
    var popperElement = React.useRef(null);
    var _c = React.useState(''), searchText = _c[0], setSearchText = _c[1];
    var _d = React.useState([]), options = _d[0], setOptions = _d[1];
    React.useEffect(function () {
        valueRef.current = props.value || [];
    }, [props.value]);
    React.useEffect(function () {
        if (!isVisible) {
            setSearchText("");
        }
    }, [isVisible]);
    React.useEffect(function () {
        var _searchText = searchText.toLowerCase();
        if (isEmptyOrSpaces$1(_searchText)) {
            setOptions(props.options);
        }
        else {
            var _options = props.options.filter(function (item) { return (item.value + "").toLowerCase().includes(_searchText); });
            if (props.allowNewValues && !_options.find(function (item) { return item.value === _searchText; })) {
                _options.unshift({ value: searchText, label: searchText });
            }
            setOptions(_options);
        }
    }, [searchText, props.options]);
    React.useEffect(function () {
        var _optionsAsMap = {};
        props.options.forEach(function (item) { return (_optionsAsMap[item.value] = item.label); });
        var _valuesText = [];
        props.value.forEach(function (item) { return _valuesText.push(_optionsAsMap[item] || item); });
        setValuesText(_valuesText);
    }, [props.value]);
    React.useEffect(function () {
        // listen for clicks and close select on body
        document.addEventListener("mousedown", handleDocumentClick);
        return function () {
            document.removeEventListener("mousedown", handleDocumentClick);
        };
    }, []);
    React.useEffect(function () {
        if (referenceElement.current && popperElement.current) {
            createPopper(referenceElement.current, popperElement.current, {
                placement: 'bottom-start',
                modifiers: [preventOverflow$1, flip$1,
                    {
                        name: 'offset',
                        options: {
                            offset: [0, 6],
                        },
                    }
                ],
            });
        }
    }, [referenceElement, popperElement]);
    var handleDocumentClick = function (event) {
        var _a, _b;
        if (((_a = referenceElement.current) === null || _a === void 0 ? void 0 : _a.contains(event.target)) || ((_b = popperElement.current) === null || _b === void 0 ? void 0 : _b.contains(event.target))) {
            return;
        }
        setIsVisible(false);
    };
    var handleSelectClick = function (event) {
        setIsVisible(!isVisible);
    };
    var handleChange = function (event, index, option) {
        var _value = __spreadArray([], valueRef.current, true);
        if (!props.multiple && _value.includes(option)) {
            _value = [];
        }
        else if (!props.multiple && !_value.includes(option)) {
            _value = [option];
        }
        else if (_value.includes(option)) {
            _value = _value.filter(function (item) { return item !== option; });
        }
        else {
            _value = __spreadArray(__spreadArray([], _value, true), [option], false);
        }
        var _event = {
            preventDefault: event.preventDefault,
            currentTarget: {
                values: _value,
                value: _value,
                name: props.name
            }
        };
        if (!props.multiple) {
            _event.currentTarget.value = _value.length > 0 ? _value[0] : null;
        }
        if (props.onChange) {
            props.onChange(_event);
        }
        if (props.onInput) {
            props.onInput(_event);
        }
        if (!props.multiple) {
            setIsVisible(false);
        }
    };
    var handleSearchTextChange = function (_searchText) {
        setSearchText(_searchText);
    };
    return (React.createElement("div", { className: ["basicui-select"].join(" ") },
        props.label && React.createElement(Label, { labelDesc: props.labelDesc }, props.label),
        React.createElement("button", { className: "basicui-input basicui-select__button", type: "button", ref: referenceElement, onClick: handleSelectClick }, valuesText.join(', ') || props.placeholder || "-"),
        React.createElement("div", { ref: popperElement, className: "basicui-select__popper" }, isVisible && React.createElement(OptionsList, { value: props.value, options: options, referenceElement: referenceElement, handleChange: handleChange, handleClose: function () { return setIsVisible(false); }, handleSearchTextChange: props.autocomplete ? handleSearchTextChange : null }))));
};

/**
 * Component to render input form element. For using it with standard html input, add css class basicui-input
 */
var Input = function (_a) {
    var id = _a.id, type = _a.type, label = _a.label, labelDesc = _a.labelDesc, value = _a.value, placeholder = _a.placeholder, tooltip = _a.tooltip, errorMessage = _a.errorMessage, warningMessage = _a.warningMessage, successMessage = _a.successMessage, className = _a.className, wrapperClassName = _a.wrapperClassName, restProps = __rest(_a, ["id", "type", "label", "labelDesc", "value", "placeholder", "tooltip", "errorMessage", "warningMessage", "successMessage", "className", "wrapperClassName"]);
    return (React.createElement("div", { className: "basicui-input-el ".concat(wrapperClassName || "") },
        label && React.createElement(Label, { labelDesc: labelDesc }, label),
        React.createElement("input", __assign({ id: id, className: "basicui-input ".concat(className || "", " ").concat(errorMessage ? "basicui-input--error" : "", " ").concat(warningMessage ? "basicui-input--warning" : "", " ").concat(successMessage ? "basicui-input--success" : ""), value: value, type: type, placeholder: placeholder, autoComplete: "off" }, restProps)),
        tooltip && React.createElement(FormElementMessage, { text: tooltip, type: "info" }),
        errorMessage && React.createElement(FormElementMessage, { text: errorMessage, type: "error" }),
        warningMessage && React.createElement(FormElementMessage, { text: warningMessage, type: "warning" }),
        successMessage && React.createElement(FormElementMessage, { text: successMessage, type: "success" })));
};

var ButtonVariantType;
(function (ButtonVariantType) {
    ButtonVariantType["default"] = "default";
    ButtonVariantType["outline"] = "outline";
    ButtonVariantType["fill"] = "fill";
    ButtonVariantType["chroma"] = "chroma";
    ButtonVariantType["transparent"] = "transparent";
})(ButtonVariantType || (ButtonVariantType = {}));
var ButtonVariantType$1 = ButtonVariantType;

var ThemeType;
(function (ThemeType) {
    ThemeType["default"] = "default";
    ThemeType["primary"] = "primary";
    ThemeType["secondary"] = "secondary";
    ThemeType["success"] = "success";
    ThemeType["warning"] = "warning";
    ThemeType["danger"] = "danger";
})(ThemeType || (ThemeType = {}));
var ThemeType$1 = ThemeType;

/**
 * Component to render drop down input form element. Supports multi select and auto complete features
 */
var Button = function (_a) {
    var type = _a.type, theme = _a.theme, variant = _a.variant, loading = _a.loading, children = _a.children, disabled = _a.disabled, className = _a.className, restProps = __rest(_a, ["type", "theme", "variant", "loading", "children", "disabled", "className"]);
    return (React.createElement("button", __assign({ className: "".concat(className || "", " basicui-button basicui-button--theme-").concat(theme || ThemeType$1.default, " ").concat(loading ? "basicui-button--loading" : "", " basicui-button--variant-").concat(variant || ButtonVariantType$1.default), type: type || "button", disabled: disabled || loading }, restProps),
        loading && (React.createElement("svg", { className: "basicui-button__svg--loading", xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 512 512" },
            React.createElement("path", { d: "M304 48a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zm0 416a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zM48 304a48 48 0 1 0 0-96 48 48 0 1 0 0 96zm464-48a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zM142.9 437A48 48 0 1 0 75 369.1 48 48 0 1 0 142.9 437zm0-294.2A48 48 0 1 0 75 75a48 48 0 1 0 67.9 67.9zM369.1 437A48 48 0 1 0 437 369.1 48 48 0 1 0 369.1 437z" }))),
        children));
};

/**
 * Component to render drop down input form element. Supports multi select and auto complete features
 */
var IconButton = React.forwardRef(function (_a, ref) {
    var type = _a.type, theme = _a.theme, variant = _a.variant, loading = _a.loading, circle = _a.circle, children = _a.children, className = _a.className, restProps = __rest(_a, ["type", "theme", "variant", "loading", "circle", "children", "className"]);
    return (React.createElement("button", __assign({ ref: ref, className: "".concat(className || "", " basicui-button basicui-icon-button ").concat(circle ? "basicui-icon-button--circle" : "", " basicui-button--theme-").concat(theme || ThemeType$1.default, " basicui-button--variant-").concat(variant || ButtonVariantType$1.default, " ").concat(loading ? "basicui-button--loading" : ""), type: type || "button" }, restProps),
        loading && (React.createElement("svg", { className: "basicui-button__svg--loading", xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 512 512" },
            React.createElement("path", { d: "M304 48a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zm0 416a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zM48 304a48 48 0 1 0 0-96 48 48 0 1 0 0 96zm464-48a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zM142.9 437A48 48 0 1 0 75 369.1 48 48 0 1 0 142.9 437zm0-294.2A48 48 0 1 0 75 75a48 48 0 1 0 67.9 67.9zM369.1 437A48 48 0 1 0 437 369.1 48 48 0 1 0 369.1 437z" }))),
        !loading && children));
});

/**
 * Component to render checkbox form element. For using it with standard html input, add css class basicui-input
 */
var Checkbox = function (_a) {
    var id = _a.id, label = _a.label, theme = _a.theme, checked = _a.checked, circle = _a.circle, restProps = __rest(_a, ["id", "label", "theme", "checked", "circle"]);
    return (React.createElement("label", { className: "basicui-checkbox ".concat(checked ? "basicui-checkbox--checked" : "", " basicui-checkbox--theme-").concat(theme || ThemeType$1.default), htmlFor: id },
        React.createElement("input", __assign({ className: "basicui-checkbox__input".concat(circle ? " basicui-checkbox__input--circle" : ""), id: id, checked: checked, type: "checkbox" }, restProps)),
        label && React.createElement("span", { className: "basicui-checkbox__span" }, label)));
};

var TabShapeType;
(function (TabShapeType) {
    TabShapeType["default"] = "default";
    TabShapeType["round"] = "round";
    TabShapeType["rectangle"] = "rectangle";
})(TabShapeType || (TabShapeType = {}));

var TabHeaderAlignmentType;
(function (TabHeaderAlignmentType) {
    TabHeaderAlignmentType["default"] = "default";
    TabHeaderAlignmentType["column"] = "column";
})(TabHeaderAlignmentType || (TabHeaderAlignmentType = {}));

// Default props value.
var defaultPortalProps = {
    wrapperId: "basicui-portal"
};
// Render component.
var Portal = function (_a) {
    var children = _a.children, wrapperId = _a.wrapperId;
    // Manage state of portal-wrapper.
    var _b = React.useState(null), wrapper = _b[0], setWrapper = _b[1];
    React.useLayoutEffect(function () {
        // Find the container-element (if exist).       
        var element = document.getElementById(wrapperId);
        // Bool flag whether container-element has been created.       
        var created = false;
        if (!element) {
            created = true;
            var wrapper_1 = document.createElement('div');
            wrapper_1.setAttribute("id", wrapperId);
            document.body.appendChild(wrapper_1);
            element = wrapper_1;
        }
        // Set wrapper state.
        setWrapper(element);
        // Cleanup effect.
        return function () {
            if (created && (element === null || element === void 0 ? void 0 : element.parentNode)) {
                element.parentNode.removeChild(element);
            }
        };
    }, [wrapperId]);
    // Return null on initial rendering.
    if (wrapper === null)
        return null;
    // Return portal-wrapper component.
    return reactDom.createPortal(children, wrapper);
};
Portal.defaultProps = defaultPortalProps;

var Modal = function (props) {
    var _a = React.useState(props.isOpen), shouldRender = _a[0], setShouldRender = _a[1];
    var _b = React.useState(false), isClosing = _b[0], setIsClosing = _b[1];
    React.useEffect(function () {
        var handleKeyDown = function (event) {
            if (event.key === 'Escape') {
                props.onClose();
            }
        };
        if (props.isOpen) {
            document.addEventListener('keydown', handleKeyDown);
        }
        return function () {
            document.removeEventListener('keydown', handleKeyDown);
        };
    }, [props.isOpen, props.onClose]);
    React.useEffect(function () {
        if (!props.isOpen) {
            setIsClosing(true);
            var timeoutId_1 = setTimeout(function () {
                setShouldRender(false);
            }, 250);
            return function () { return clearTimeout(timeoutId_1); };
        }
        else {
            setIsClosing(false);
            setShouldRender(true);
        }
    }, [props.isOpen]);
    if (!shouldRender)
        return null;
    var handleOverlayClick = function (e) {
        if (e.target === e.currentTarget) {
            props.onClose();
        }
    };
    return (React.createElement(Portal, { wrapperId: "basicui-modal" },
        React.createElement("div", { className: "basicui-modal ".concat(props.isOpen ? 'basicui-modal--open' : 'basicui-modal--close') },
            React.createElement("div", { className: "basicui-modal__overlay", onClick: handleOverlayClick },
                React.createElement("div", { className: "basicui-modal__base \n                            ".concat(isClosing ? 'basicui-modal__base--closing' : 'basicui-modal__base--opening', "\n                            basicui-modal__base--size-").concat(props.size || "default", " basicui-modal__base--placement-").concat(props.placement || "default") }, props.children)))));
};

var ModalHeader = function (props) {
    return (React.createElement("div", { className: "basicui-modal-header ".concat(props.border ? "basicui-modal-header--show-border" : "") },
        React.createElement("div", { className: "basicui-modal-header__heading" }, props.heading),
        React.createElement("button", { className: "basicui-modal-header__close", onClick: props.onClose },
            React.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 384 512" },
                React.createElement("path", { d: "M342.6 150.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192 210.7 86.6 105.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L146.7 256 41.4 361.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192 301.3 297.4 406.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L237.3 256 342.6 150.6z" })))));
};

var ModalFooter = function (props) {
    return (React.createElement("div", { className: "basicui-modal-footer ".concat(props.border ? "basicui-modal-footer--show-border" : "", " basicui-modal-footer--alignment-").concat(props.alignment || ThemeType$1.default) }, props.children));
};

var ModalBody = function (props) {
    return (React.createElement("div", { className: "basicui-modal-body" }, props.children));
};

function SvgIcon(_a) {
    var _this = this;
    var _b;
    var children = _a.children, src = _a.src, className = _a.className, width = _a.width, height = _a.height, fill = _a.fill;
    var _c = React.useState(null), svgContent = _c[0], setSvgContent = _c[1];
    var wrapperStyle = {
        width: width || "20px",
        height: height || "20px",
        fill: fill || "var(--basicui-fg)",
    };
    // Fetch SVG from remote source if src is provided
    React.useEffect(function () {
        var fetchSVG = function () { return __awaiter(_this, void 0, void 0, function () {
            var response, text, error_1;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 3, , 4]);
                        return [4 /*yield*/, fetch(src || "")];
                    case 1:
                        response = _a.sent();
                        return [4 /*yield*/, response.text()];
                    case 2:
                        text = _a.sent();
                        setSvgContent(text.replace(/<svg([^>]+)>/, function (match, group) {
                            var widthAttr = width ? "width=\"".concat(width, "\" ") : "";
                            var heightAttr = height ? "height=\"".concat(height, "\" ") : "";
                            return "<svg ".concat(group, " ").concat(widthAttr).concat(heightAttr, ">");
                        }));
                        return [3 /*break*/, 4];
                    case 3:
                        error_1 = _a.sent();
                        console.error("Failed to fetch SVG:", error_1);
                        return [3 /*break*/, 4];
                    case 4: return [2 /*return*/];
                }
            });
        }); };
        if (src) {
            fetchSVG();
        }
    }, [src, width, height]);
    // Utility: Check if string looks like SVG content
    var isSvgString = function (content) {
        return typeof content === "string" && content.trim().startsWith("<svg");
    };
    // Render logic
    if (!src && !children)
        return null;
    // 1. If children is a React node or component
    if (React.isValidElement(children)) {
        var existingStyle = ((_b = children === null || children === void 0 ? void 0 : children.props) === null || _b === void 0 ? void 0 : _b.style) || {};
        var styledChild = React.cloneElement(children, {
            style: __assign(__assign({}, existingStyle), { width: width, height: height }),
        });
        return (React.createElement("div", { className: "basicui-svgicon ".concat(className || ""), style: wrapperStyle }, styledChild));
    }
    // 2. If children is an inline SVG string
    if (!src && isSvgString(children)) {
        var parsed = children.replace(/<svg([^>]+)>/, function (match, group) {
            var widthAttr = width ? "width=\"".concat(width, "\" ") : "";
            var heightAttr = height ? "height=\"".concat(height, "\" ") : "";
            return "<svg ".concat(group, " ").concat(widthAttr).concat(heightAttr, ">");
        });
        return (React.createElement("div", { className: "basicui-svgicon ".concat(className || ""), style: wrapperStyle, dangerouslySetInnerHTML: { __html: parsed } }));
    }
    // 3. If src was provided and fetched SVG
    if (!children && svgContent) {
        return (React.createElement("div", { className: "basicui-svgicon ".concat(className || ""), style: wrapperStyle, dangerouslySetInnerHTML: { __html: svgContent } }));
    }
    // 4. Fallback: Render plain content
    return (React.createElement("div", { className: "basicui-svgicon ".concat(className || ""), style: wrapperStyle }, children));
}

/**
 * Component to render an accordion with optional custom header.
 * Allows parent to fully control expand/collapse behavior.
 */
var Accordion = function (props) {
    var bodyRef = React.useRef(null);
    var isAnimationCompletedRef = React.useRef(true);
    var handleChange = function () {
        if (isAnimationCompletedRef.current && props.onChange) {
            props.onChange();
        }
    };
    React.useEffect(function () {
        updateScrollHeight();
    }, [props.expanded]);
    var updateScrollHeight = function () {
        if (!bodyRef.current)
            return;
        if (props.expanded) {
            bodyRef.current.style.height = bodyRef.current.scrollHeight + 'px';
            bodyRef.current.style.overflowY = 'hidden';
            bodyRef.current.style.visibility = 'visible';
            isAnimationCompletedRef.current = false;
            setTimeout(function () {
                if (bodyRef.current) {
                    bodyRef.current.style.overflowY = 'visible';
                    bodyRef.current.style.height = 'auto';
                }
                isAnimationCompletedRef.current = true;
            }, 300);
        }
        else {
            isAnimationCompletedRef.current = false;
            bodyRef.current.style.height = bodyRef.current.scrollHeight + 'px';
            setTimeout(function () {
                bodyRef.current.style.height = '0px';
            }, 0);
            bodyRef.current.style.overflowY = 'hidden';
            setTimeout(function () {
                if (bodyRef.current) {
                    bodyRef.current.style.visibility = 'hidden';
                }
                isAnimationCompletedRef.current = true;
            }, 300);
        }
    };
    var renderHeader = function () {
        if (props.header) {
            return React.createElement("div", { className: "basicui-accordion__header-custom" }, props.header);
        }
        if (props.heading && props.onChange) {
            return (React.createElement("button", { className: "basicui-accordion__header", onClick: handleChange },
                React.createElement("div", null, props.heading),
                React.createElement(SvgIcon, { className: "basicui-accordion__header__arrow", src: "/icons/fontawesome/down.svg", height: "12px", width: "12px" })));
        }
        return null; // No header
    };
    return (React.createElement("div", { className: "basicui-accordion ".concat(props.expanded ? "accordion-active" : "", " ").concat(props.bordered ? "accordion-bordered" : "", " theme-").concat(props.theme || ThemeType$1.default, " ").concat(props.className || "") },
        renderHeader(),
        React.createElement("div", { className: "basicui-accordion__body", ref: bodyRef },
            React.createElement("div", { className: "basicui-accordion__body__content" }, props.children))));
};

var Popover = function (_a) {
    var visible = _a.visible, anchorRef = _a.anchorRef, onClose = _a.onClose, children = _a.children, _b = _a.placement, placement = _b === void 0 ? "bottom-start" : _b;
    var popperRef = React.useRef(null);
    var popperInstance = React.useRef(null);
    React.useEffect(function () {
        if (anchorRef.current && popperRef.current && visible) {
            popperInstance.current = createPopper(anchorRef.current, popperRef.current, {
                placement: placement,
                modifiers: [
                    preventOverflow$1,
                    flip$1,
                    {
                        name: "offset",
                        options: {
                            offset: [0, 6],
                        },
                    },
                ],
            });
        }
        return function () {
            if (popperInstance.current) {
                popperInstance.current.destroy();
                popperInstance.current = null;
            }
        };
    }, [visible, anchorRef, placement]);
    React.useEffect(function () {
        console.log(anchorRef.current, popperRef.current);
        var handleClickOutside = function (event) {
            var _a, _b, _c, _d;
            console.log("***clikc outside");
            console.log(anchorRef.current, popperRef.current, event.target, (_a = anchorRef.current) === null || _a === void 0 ? void 0 : _a.contains(event.target), (_b = popperRef.current) === null || _b === void 0 ? void 0 : _b.contains(event.target));
            if (!((_c = anchorRef.current) === null || _c === void 0 ? void 0 : _c.contains(event.target)) &&
                !((_d = popperRef.current) === null || _d === void 0 ? void 0 : _d.contains(event.target))) {
                onClose === null || onClose === void 0 ? void 0 : onClose();
            }
        };
        if (visible) {
            setTimeout(function () {
                document.addEventListener("mousedown", handleClickOutside);
            }, 0);
        }
        return function () {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [visible, anchorRef, onClose]);
    if (!visible)
        return null;
    return (React.createElement("div", { ref: popperRef, className: "popover-container", style: { zIndex: 99 } }, children));
};

var AlignmentType;
(function (AlignmentType) {
    AlignmentType["default"] = "default";
    AlignmentType["left"] = "left";
    AlignmentType["center"] = "center";
})(AlignmentType || (AlignmentType = {}));

var ModalPlacement;
(function (ModalPlacement) {
    ModalPlacement["default"] = "default";
    ModalPlacement["top"] = "top";
    ModalPlacement["bottom"] = "bottom";
    ModalPlacement["side"] = "side";
})(ModalPlacement || (ModalPlacement = {}));

var ModalSizeType;
(function (ModalSizeType) {
    ModalSizeType["default"] = "default";
    ModalSizeType["small"] = "small";
    ModalSizeType["large"] = "large";
    ModalSizeType["xlarge"] = "xlarge";
})(ModalSizeType || (ModalSizeType = {}));
var ModalSizeType$1 = ModalSizeType;

var Logo$1 = function (props) {
    return (React.createElement("div", { className: "basicui-logo" },
        React.createElement("div", { className: "basicui-logo__icon" },
            React.createElement("img", { src: props.isDarkMode ? props.logoIconWhite : props.logoIconBlack, alt: "Logo" })),
        props.showText && (React.createElement("div", { className: "basicui-logo__text" },
            React.createElement("img", { src: props.isDarkMode ? props.logoTextWhite : props.logoTextBlack, alt: "Logo" })))));
};

var NavbarHeader = function (props) {
    return (React.createElement("div", { className: "basicui-appshellsentinel-navbar-header" },
        React.createElement(Logo$1, { isDarkMode: props.isDarkMode, logoIconBlack: props.logoIconBlack, logoIconWhite: props.logoIconWhite, logoTextBlack: props.logoTextBlack, logoTextWhite: props.logoTextWhite, showText: props.isSidebarExpanded }),
        props.isSidebarExpanded && React.createElement("div", null, props.children)));
};
NavbarHeader.displayName = "NavbarHeader";

var NavbarFooter = function (props) {
    return (React.createElement("div", { className: "basicui-appshellsentinel-navbar-footer ".concat(props.isSidebarExpanded
            ? "basicui-appshellsentinel-navbar-footer--expanded"
            : "basicui-appshellsentinel-navbar-footer--collapsed") },
        React.createElement("div", { className: "basicui-appshellsentinel-navbar-footer__left" },
            props.userName && (React.createElement("button", { className: "button", onClick: props.onSignout }, "SO")),
            !props.userName && (React.createElement("button", { className: "button", onClick: props.onSignin }, "SI")),
            props.isSidebarExpanded && React.createElement("div", null, props.userName)),
        props.isSidebarExpanded && (React.createElement("div", { className: "basicui-appshellsentinel-navbar-footer__right", onClick: props.onDarkModeToggle },
            React.createElement("svg", { "aria-hidden": "true", focusable: "false", "data-prefix": "fas", "data-icon": "sun", className: "svg-inline--fa fa-sun ", role: "img", xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 512 512" },
                React.createElement("path", { fill: "currentColor", d: "M361.5 1.2c5 2.1 8.6 6.6 9.6 11.9L391 121l107.9 19.8c5.3 1 9.8 4.6 11.9 9.6s1.5 10.7-1.6 15.2L446.9 256l62.3 90.3c3.1 4.5 3.7 10.2 1.6 15.2s-6.6 8.6-11.9 9.6L391 391 371.1 498.9c-1 5.3-4.6 9.8-9.6 11.9s-10.7 1.5-15.2-1.6L256 446.9l-90.3 62.3c-4.5 3.1-10.2 3.7-15.2 1.6s-8.6-6.6-9.6-11.9L121 391 13.1 371.1c-5.3-1-9.8-4.6-11.9-9.6s-1.5-10.7 1.6-15.2L65.1 256 2.8 165.7c-3.1-4.5-3.7-10.2-1.6-15.2s6.6-8.6 11.9-9.6L121 121 140.9 13.1c1-5.3 4.6-9.8 9.6-11.9s10.7-1.5 15.2 1.6L256 65.1 346.3 2.8c4.5-3.1 10.2-3.7 15.2-1.6zM160 256a96 96 0 1 1 192 0 96 96 0 1 1 -192 0zm224 0a128 128 0 1 0 -256 0 128 128 0 1 0 256 0z" }))))));
};
NavbarFooter.displayName = "NavbarFooter";

var NavbarBody = function (props) {
    return (React.createElement("div", { className: "basicui-appshellsentinel-navbar-body" },
        React.createElement("button", { className: "basicui-appshellsentinel-navbar-body__toggle", onClick: props.onSidebarToggle },
            props.isSidebarExpanded && (React.createElement("svg", { "aria-hidden": "true", focusable: "false", "data-prefix": "fas", "data-icon": "chevron-left", className: "svg-inline--fa fa-chevron-left ", role: "img", xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 320 512" },
                React.createElement("path", { fill: "currentColor", d: "M9.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l192 192c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L77.3 256 246.6 86.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-192 192z" }))),
            !props.isSidebarExpanded && (React.createElement("svg", { "aria-hidden": "true", focusable: "false", "data-prefix": "fas", "data-icon": "chevron-right", className: "svg-inline--fa fa-chevron-right ", role: "img", xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 320 512" },
                React.createElement("path", { fill: "currentColor", d: "M310.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L242.7 256 73.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z" })))),
        props.children));
};
NavbarBody.displayName = "NavbarBody";

var Navbar$1 = function (_a) {
    var children = _a.children, props = __rest(_a, ["children"]);
    var _b = React.useState(), appShellNavbarHeader = _b[0], setNavbarHeader = _b[1];
    var _c = React.useState(), appShellNavbarBody = _c[0], setNavbarBody = _c[1];
    var _d = React.useState(), appShellNavbarFooter = _d[0], setNavbarFooter = _d[1];
    React.useEffect(function () {
        children.forEach(function (item) {
            var clonedChild = React.cloneElement(item, __assign({}, props));
            if (item.type.displayName === "NavbarHeader" ||
                item.type.name === "NavbarHeader") {
                setNavbarHeader(clonedChild);
            }
            if (item.type.displayName === "NavbarBody" ||
                item.type.name === "NavbarBody") {
                setNavbarBody(clonedChild);
            }
            if (item.type.displayName === "NavbarFooter" ||
                item.type.name === "NavbarFooter") {
                setNavbarFooter(clonedChild);
            }
        });
    }, [children]);
    return (React.createElement("div", { className: "basicui-appshellsentinel-navbar" },
        appShellNavbarHeader,
        appShellNavbarBody,
        appShellNavbarFooter));
};
Navbar$1.Header = NavbarHeader;
Navbar$1.Footer = NavbarFooter;
Navbar$1.Body = NavbarBody;
Navbar$1.displayName = "Navbar";

var Topbar$1 = function (props) {
    var _a = React.useState(false), isMobileNavOpen = _a[0], setIsMobileNavOpen = _a[1];
    React.useEffect(function () {
        var _a;
        console.log(props.location, "****location changed", (_a = props.location) === null || _a === void 0 ? void 0 : _a.pathname);
        setIsMobileNavOpen(false);
    }, [props.location]);
    return (React.createElement(React.Fragment, null,
        React.createElement("div", { className: "basicui-appshellsentinel-topbar" },
            React.createElement("div", { className: "basicui-appshellsentinel-topbar__left" },
                React.createElement(Logo$1, { isDarkMode: props.isDarkMode, logoIconBlack: props.logoIconBlack, logoIconWhite: props.logoIconWhite, logoTextBlack: props.logoTextBlack, logoTextWhite: props.logoTextWhite, showText: true })),
            React.createElement("div", { className: "basicui-appshellsentinel-topbar__right" },
                React.createElement("button", { className: "basicui-appshellsentinel-topbar__right__toggle", onClick: function () { return setIsMobileNavOpen(!isMobileNavOpen); } },
                    React.createElement("svg", { "aria-hidden": "true", focusable: "false", "data-prefix": "fas", "data-icon": "bars", className: "svg-inline--fa fa-bars ", role: "img", xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 448 512" },
                        React.createElement("path", { fill: "currentColor", d: "M0 96C0 78.3 14.3 64 32 64H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32C14.3 128 0 113.7 0 96zM0 256c0-17.7 14.3-32 32-32H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32c-17.7 0-32-14.3-32-32zM448 416c0 17.7-14.3 32-32 32H32c-17.7 0-32-14.3-32-32s14.3-32 32-32H416c17.7 0 32 14.3 32 32z" }))))),
        isMobileNavOpen && props.children));
};
Topbar$1.displayName = "Topbar";

var Body$1 = function (props) {
    return React.createElement("div", { className: "basicui-appshellsentinel-body" }, props.children);
};
Body$1.displayName = "Body";

var MobileNavbarBody = function (props) {
    return (React.createElement("div", { className: "basicui-appshellsentinel-mobile-navbar-body" }, props.children));
};
MobileNavbarBody.displayName = "MobileNavbarBody";

var MobileNavbarFooter = function (props) {
    return (React.createElement("div", { className: "basicui-appshellsentinel-mobile-navbar-footer" },
        React.createElement("div", { className: "basicui-appshellsentinel-mobile-navbar-footer__left" },
            props.userName && (React.createElement("button", { className: "button", onClick: props.onSignout }, "SO")),
            !props.userName && (React.createElement("button", { className: "button", onClick: props.onSignin }, "SI")),
            props.isSidebarExpanded && React.createElement("div", null, props.userName)),
        props.isSidebarExpanded && (React.createElement("div", { className: "basicui-appshellsentinel-mobile-navbar-footer__right", onClick: props.onDarkModeToggle },
            React.createElement("svg", { "aria-hidden": "true", focusable: "false", "data-prefix": "fas", "data-icon": "sun", className: "svg-inline--fa fa-sun ", role: "img", xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 512 512" },
                React.createElement("path", { fill: "currentColor", d: "M361.5 1.2c5 2.1 8.6 6.6 9.6 11.9L391 121l107.9 19.8c5.3 1 9.8 4.6 11.9 9.6s1.5 10.7-1.6 15.2L446.9 256l62.3 90.3c3.1 4.5 3.7 10.2 1.6 15.2s-6.6 8.6-11.9 9.6L391 391 371.1 498.9c-1 5.3-4.6 9.8-9.6 11.9s-10.7 1.5-15.2-1.6L256 446.9l-90.3 62.3c-4.5 3.1-10.2 3.7-15.2 1.6s-8.6-6.6-9.6-11.9L121 391 13.1 371.1c-5.3-1-9.8-4.6-11.9-9.6s-1.5-10.7 1.6-15.2L65.1 256 2.8 165.7c-3.1-4.5-3.7-10.2-1.6-15.2s6.6-8.6 11.9-9.6L121 121 140.9 13.1c1-5.3 4.6-9.8 9.6-11.9s10.7-1.5 15.2 1.6L256 65.1 346.3 2.8c4.5-3.1 10.2-3.7 15.2-1.6zM160 256a96 96 0 1 1 192 0 96 96 0 1 1 -192 0zm224 0a128 128 0 1 0 -256 0 128 128 0 1 0 256 0z" }))))));
};
MobileNavbarFooter.displayName = "MobileNavbarFooter";

var MobileNavbar$1 = function (_a) {
    var children = _a.children, props = __rest(_a, ["children"]);
    var _b = React.useState(), appShellMobileNavbarBody = _b[0], setMobileNavbarBody = _b[1];
    var _c = React.useState(), appShellMobileNavbarFooter = _c[0], setMobileNavbarFooter = _c[1];
    React.useEffect(function () {
        children.forEach(function (item) {
            var clonedChild = React.cloneElement(item, __assign({}, props));
            if (item.type.displayName === "MobileNavbarBody" ||
                item.type.name === "MobileNavbarBody") {
                setMobileNavbarBody(clonedChild);
            }
            if (item.type.displayName === "MobileNavbarFooter" ||
                item.type.name === "MobileNavbarFooter") {
                setMobileNavbarFooter(clonedChild);
            }
        });
    }, [children]);
    return (React.createElement("div", { className: "basicui-appshellsentinel-mobile-navbar" },
        appShellMobileNavbarBody,
        appShellMobileNavbarFooter));
};
MobileNavbar$1.Body = MobileNavbarBody;
MobileNavbar$1.Footer = MobileNavbarFooter;
MobileNavbar$1.displayName = "MobileNavbar";

var AppShellSentinel = function (_a) {
    var children = _a.children, props = __rest(_a, ["children"]);
    var _b = React.useState(false); _b[0]; _b[1];
    var _c = React.useState(), navbar = _c[0], setNavbar = _c[1];
    var _d = React.useState(), topbar = _d[0], setTopbar = _d[1];
    var _e = React.useState(), body = _e[0], setBody = _e[1];
    var _f = React.useState(), mobileNavbarBody = _f[0], setMobileNavbar = _f[1];
    React.useEffect(function () {
        children.forEach(function (item) {
            var clonedChild = React.cloneElement(item, __assign({}, props));
            if (item.type.displayName === "Navbar" ||
                item.type.name === "Navbar") {
                setNavbar(clonedChild);
            }
            if (item.type.displayName === "Body" ||
                item.type.name === "Body") {
                setBody(clonedChild);
            }
            if (item.type.displayName === "MobileNavbar" ||
                item.type.name === "MobileNavbar") {
                setMobileNavbar(clonedChild);
            }
        });
    }, [children]);
    React.useEffect(function () {
        children.forEach(function (item) {
            var clonedChild = React.cloneElement(item, __assign(__assign({}, props), { children: mobileNavbarBody }));
            if (item.type.displayName === "Topbar" ||
                item.type.name === "Topbar") {
                setTopbar(clonedChild);
            }
        });
    }, [children, mobileNavbarBody]);
    return (React.createElement("div", { className: "basicui-appshellsentinel ".concat(props.isSidebarExpanded
            ? "basicui-appshellsentinel--expanded"
            : "basicui-appshellsentinel--collapsed") },
        !props.hideNavbar && (React.createElement("div", { className: "basicui-appshellsentinel__left  desktop-only" }, navbar)),
        React.createElement("div", { className: "basicui-appshellsentinel__right ".concat(props.hideNavbar ? "basicui-appshellsentinel__right--" + "hide-navbar" : "") },
            topbar,
            body)));
};
AppShellSentinel.Navbar = Navbar$1;
AppShellSentinel.Topbar = Topbar$1;
AppShellSentinel.Body = Body$1;
AppShellSentinel.MobileNavbar = MobileNavbar$1;
AppShellSentinel.displayName = "AppShellSentinel";

var Navbar = function (_a) {
    var children = _a.children; __rest(_a, ["children"]);
    return (React.createElement("div", { className: "basicui-appshellreveal-navbar" }, children));
};
Navbar.displayName = "Navbar";

var Logo = function (props) {
    return (React.createElement("div", { className: "basicui-logo" },
        React.createElement("div", { className: "basicui-logo__icon" },
            React.createElement("img", { src: props.isDarkMode ? props.logoIconWhite : props.logoIconBlack, alt: "Logo" })),
        props.showText && (React.createElement("div", { className: "basicui-logo__text" },
            React.createElement("img", { src: props.isDarkMode ? props.logoTextWhite : props.logoTextBlack, alt: "Logo" })))));
};

var Topbar = function (props) {
    var _a = React.useState(false), isMobileNavOpen = _a[0], setIsMobileNavOpen = _a[1];
    React.useEffect(function () {
        var _a;
        console.log(props.location, "****location changed", (_a = props.location) === null || _a === void 0 ? void 0 : _a.pathname);
        setIsMobileNavOpen(false);
    }, [props.location]);
    return (React.createElement(React.Fragment, null,
        React.createElement("div", { className: "basicui-appshellreveal-topbar" },
            React.createElement("div", { className: "basicui-appshellreveal-topbar__left" },
                React.createElement(Logo, { isDarkMode: props.isDarkMode, logoIconBlack: props.logoIconBlack, logoIconWhite: props.logoIconWhite, logoTextBlack: props.logoTextBlack, logoTextWhite: props.logoTextWhite, showText: true })),
            React.createElement("div", { className: "basicui-appshellreveal-topbar__right" },
                React.createElement("button", { className: "basicui-appshellreveal-topbar__right__toggle", onClick: function () { return setIsMobileNavOpen(!isMobileNavOpen); } },
                    React.createElement("svg", { "aria-hidden": "true", focusable: "false", "data-prefix": "fas", "data-icon": "bars", className: "svg-inline--fa fa-bars ", role: "img", xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 448 512" },
                        React.createElement("path", { fill: "currentColor", d: "M0 96C0 78.3 14.3 64 32 64H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32C14.3 128 0 113.7 0 96zM0 256c0-17.7 14.3-32 32-32H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32c-17.7 0-32-14.3-32-32zM448 416c0 17.7-14.3 32-32 32H32c-17.7 0-32-14.3-32-32s14.3-32 32-32H416c17.7 0 32 14.3 32 32z" }))))),
        isMobileNavOpen && props.children));
};
Topbar.displayName = "Topbar";

var Body = function (props) {
    return React.createElement("div", { className: "basicui-appshellreveal-body" }, props.children);
};
Body.displayName = "Body";

var MobileNavbar = function (_a) {
    var children = _a.children; __rest(_a, ["children"]);
    return (React.createElement("div", { className: "basicui-appshellreveal-mobile-navbar" }, children));
};
MobileNavbar.displayName = "MobileNavbar";

var AppShellReveal = function (_a) {
    var children = _a.children, props = __rest(_a, ["children"]);
    var _b = React.useState(false), shouldRenderMenu = _b[0], setShouldRenderMenu = _b[1];
    var _c = React.useState(), navbar = _c[0], setNavbar = _c[1];
    var _d = React.useState(), body = _d[0], setBody = _d[1];
    var _e = React.useState(), mobileNavbarBody = _e[0], setMobileNavbar = _e[1];
    var animationTimeout = React.useRef(null);
    React.useEffect(function () {
        children.forEach(function (item) {
            var clonedChild = React.cloneElement(item, __assign({}, props));
            if (item.type.displayName === "Navbar" || item.type.name === "Navbar") {
                setNavbar(clonedChild);
            }
            if (item.type.displayName === "Body" || item.type.name === "Body") {
                setBody(clonedChild);
            }
            if (item.type.displayName === "MobileNavbar" || item.type.name === "MobileNavbar") {
                setMobileNavbar(clonedChild);
            }
        });
    }, [children]);
    React.useEffect(function () {
        if (props.isMenuActive) {
            setShouldRenderMenu(true);
        }
        else {
            if (animationTimeout.current)
                clearTimeout(animationTimeout.current);
            animationTimeout.current = setTimeout(function () {
                setShouldRenderMenu(false);
            }, 300);
        }
        return function () {
            if (animationTimeout.current)
                clearTimeout(animationTimeout.current);
        };
    }, [props.isMenuActive]);
    return (React.createElement("div", { className: "basicui-appshellreveal" },
        React.createElement("header", { className: "basicui-appshellreveal__header" },
            React.createElement("div", { className: "basicui-appshellreveal__header__left" },
                React.createElement(Logo, { logoIconBlack: props.logoIconBlack, logoIconWhite: props.logoIconWhite, logoTextBlack: props.logoTextBlack, logoTextWhite: props.logoTextWhite, showText: true, isDarkMode: props.isDarkMode })),
            props.userName && (React.createElement("button", { className: "basicui-internal-button basicui-appshellreveal__header__user", onClick: props.onSignout },
                React.createElement(SvgIcon, { src: "/icons/fontawesome/signout.svg" }),
                " ",
                props.userName)),
            !props.userName && (React.createElement("button", { className: "basicui-internal-button basicui-appshellreveal__header__user", onClick: props.onSignin },
                React.createElement(SvgIcon, { src: "/icons/fontawesome/signin.svg" }),
                " Login")),
            React.createElement("button", { className: "basicui-internal-button basicui-appshellreveal__header__right", onClick: function () { return props.setIsMenuActive(!props.isMenuActive); } },
                React.createElement("div", { className: "basicui-appshellreveal__header__right__icon ".concat(props.isMenuActive ? "basicui-appshellreveal__header__right__icon--open" : "") },
                    React.createElement("span", null),
                    React.createElement("span", null)))),
        React.createElement("div", { className: "basicui-appshellreveal__main" }, body),
        shouldRenderMenu && (React.createElement("div", { className: "basicui-appshellreveal__menupanel basicui-webonly ".concat(props.isMenuActive ? "slide-down" : "slide-up") },
            React.createElement("div", { className: "basicui-appshellreveal__menupanel__menucontent" }, navbar))),
        shouldRenderMenu && (React.createElement("div", { className: "basicui-appshellreveal__menupanel basicui-mobileonly ".concat(props.isMenuActive ? "slide-down" : "slide-up") },
            React.createElement("div", { className: "basicui-appshellreveal__menupanel__menucontent" }, mobileNavbarBody)))));
};
AppShellReveal.Navbar = Navbar;
AppShellReveal.Topbar = Topbar;
AppShellReveal.Body = Body;
AppShellReveal.MobileNavbar = MobileNavbar;
AppShellReveal.displayName = "AppShellReveal";

var Accordion_1 = Accordion;
var Button_1 = Button;
var ButtonVariantType_1 = ButtonVariantType$1;
var Checkbox_1 = Checkbox;
var IconButton_1 = IconButton;
var Input_1 = Input;
var Modal_1 = Modal;
var ModalBody_1 = ModalBody;
var ModalFooter_1 = ModalFooter;
var ModalHeader_1 = ModalHeader;
var ModalSizeType_1 = ModalSizeType$1;
var Popover_1 = Popover;
var Select_1 = Select$1;
var SvgIcon_1 = SvgIcon;
var ThemeType_1 = ThemeType$1;

var FilterSection = function (_a) {
    var _b;
    var fieldLabel = _a.fieldLabel, fieldName = _a.fieldName, fieldValues = _a.fieldValues, selectedFilters = _a.selectedFilters, toggleFilter = _a.toggleFilter;
    var _c = useState(false), isOpen = _c[0], setIsOpen = _c[1];
    var _d = useState("0px"); _d[0]; var setHeight = _d[1];
    var contentRef = useRef(null);
    var selectedCount = ((_b = selectedFilters[fieldName]) === null || _b === void 0 ? void 0 : _b.length) || 0;
    useEffect(function () {
        if (contentRef.current) {
            if (isOpen) {
                setHeight("".concat(contentRef.current.scrollHeight, "px"));
                setTimeout(function () {
                    setHeight("auto");
                }, 250);
            }
            else {
                setHeight("".concat(contentRef.current.scrollHeight, "px"));
                setTimeout(function () {
                    setHeight("0px");
                }, 100);
            }
        }
    }, [isOpen]);
    return (React$1.createElement(Accordion_1, { className: "basicui-searchbar-filtersection", expanded: isOpen, onChange: function () { return setIsOpen(!isOpen); }, heading: "".concat(fieldLabel).concat(selectedCount > 0 ? " (".concat(selectedCount, ")") : "") },
        React$1.createElement("div", { className: "basicui-searchbar-filtersection__content" }, fieldValues.map(function (val) {
            var _a;
            return (React$1.createElement(Checkbox_1, { key: val.id, theme: ThemeType_1.primary, checked: ((_a = selectedFilters[fieldName]) === null || _a === void 0 ? void 0 : _a.includes(val.id)) || false, onChange: function () { return toggleFilter(fieldName, val.id); }, label: val.label }));
        }))));
};

/**
 * Component to render search bar with advanced options.
 */
var SearchBar = function (props) {
    var _a = useState(''), searchText = _a[0], setSearchText = _a[1];
    var _b = useState(false), showAdvanced = _b[0], setShowAdvanced = _b[1];
    var _c = useState({}), selectedFilters = _c[0], setSelectedFilters = _c[1];
    var _d = useState(''), advancedSearchText = _d[0], setAdvancedSearchText = _d[1]; // State for advanced section filter
    var toggleFilter = function (field, valueId) {
        setSelectedFilters(function (prev) {
            var _a;
            var currentValues = prev[field] || [];
            var newValues = currentValues.includes(valueId)
                ? currentValues.filter(function (id) { return id !== valueId; })
                : __spreadArray$1(__spreadArray$1([], currentValues, true), [valueId], false);
            return __assign$1(__assign$1({}, prev), (_a = {}, _a[field] = newValues, _a));
        });
    };
    var handleSearch = function () {
        var resultFilters = Object.entries(selectedFilters).map(function (_a) {
            var fieldName = _a[0], selectedValueList = _a[1];
            return ({
                fieldName: fieldName,
                selectedValueList: selectedValueList
            });
        });
        props.onSearch({ searchText: searchText, filters: resultFilters });
        setShowAdvanced(false);
    };
    var clearFilters = function () {
        setSelectedFilters({});
        // setShowAdvanced(false);
    };
    // Filter the filters' field values based on advancedSearchText
    var filteredFilters = props.filters.map(function (filter) { return (__assign$1(__assign$1({}, filter), { fieldValues: filter.fieldValues.filter(function (value) {
            return value.label.toLowerCase().includes(advancedSearchText.toLowerCase());
        }) })); });
    return (React$1.createElement("div", { className: "basicui-searchbar" },
        React$1.createElement("div", { className: "basicui-searchbar__input" },
            React$1.createElement("button", { className: "basicui-searchbar__input__action-left", onClick: function () { return setShowAdvanced(function (prev) { return !prev; }); } },
                React$1.createElement(SvgIcon_1, { src: showAdvanced ? "/icons/fontawesome/up.svg" : "/icons/fontawesome/down.svg", height: "16px", width: "16px" })),
            React$1.createElement("input", { className: "basicui-searchbar__input__text", placeholder: props.placeholder || "Search...", value: searchText, autoFocus: true, onChange: function (e) { return setSearchText(e.target.value); }, onKeyDown: function (e) {
                    if (e.key === 'Enter')
                        handleSearch();
                } }),
            searchText && searchText !== "" && React$1.createElement("button", { className: "basicui-searchbar__input__action-beforeright", onClick: function () { return setSearchText(""); } },
                React$1.createElement(SvgIcon_1, { src: "/icons/fontawesome/close.svg", height: "14px", width: "14px" })),
            React$1.createElement("button", { className: "basicui-searchbar__input__action-right", onClick: handleSearch },
                React$1.createElement(SvgIcon_1, { src: "/icons/fontawesome/search.svg", height: "16px", width: "16px" }))),
        showAdvanced && (React$1.createElement("div", { className: "basicui-searchbar__advanced" },
            React$1.createElement("div", { className: "basicui-searchbar__advanced__header" },
                React$1.createElement("div", { className: "basicui-searchbar__advanced__header__action" },
                    React$1.createElement(Button_1, { onClick: clearFilters, variant: ButtonVariantType_1.fill },
                        React$1.createElement(SvgIcon_1, { src: "/icons/fontawesome/filter-close.svg", height: "14px", width: "14px" }),
                        "Clear")),
                React$1.createElement(Input_1, { className: "basicui-searchbar__advanced__header__searchtext", type: "text", placeholder: "Search filters...", value: advancedSearchText, onChange: function (e) { return setAdvancedSearchText(e.currentTarget.value); } })),
            React$1.createElement("div", { className: "basicui-searchbar__advanced__main" }, filteredFilters.map(function (filter) { return (React$1.createElement(FilterSection, { key: filter.fieldName, fieldLabel: filter.fieldLabel, fieldName: filter.fieldName, fieldValues: filter.fieldValues, selectedFilters: selectedFilters, toggleFilter: toggleFilter })); }))))));
};

var css_248z$h = ".powerui-list {\n    display: flex;\n    row-gap: 12px;\n    flex-direction: column;\n}\n\n\n.powerui-list__actionheader {\n    display: grid;\n    grid-auto-flow: column;\n    justify-content: space-between;\n    align-items: center;\n}\n\n.powerui-list__actionheader__actions {\n    display: flex;\n    flex-direction: row;\n    column-gap: 12px;\n}";
styleInject$1(css_248z$h);

var getClassName = function (baseClassName, section, variants, additionalClassName) {
    if (section === void 0) { section = []; }
    if (variants === void 0) { variants = []; }
    if (additionalClassName === void 0) { additionalClassName = ''; }
    var base = section.length > 0
        ? "".concat(baseClassName, "__").concat(section.join('__'))
        : baseClassName;
    var classNames = [base];
    if (variants.length > 0) {
        variants.forEach(function (variant) {
            classNames.push("".concat(base, "--").concat(variant));
        });
    }
    if (additionalClassName) {
        classNames.push(additionalClassName);
    }
    return classNames.join(' ');
};

var css_248z$g = ".powerui-list-item {\n    display: grid;\n    grid-template-columns: auto 1fr;\n    align-items: flex-start;\n    column-gap: 12px;\n    padding: 12px 12px;\n    border-radius: 12px;\n    border: 1px solid transparent;\n    background-color: var(--basicui-bg-surface);\n}\n\n.powerui-list-item--checked {\n    border-color: var(--basicui-bg-primary);\n}\n\n.powerui-list-item__checkbox {\n    margin-right: 12px;\n}\n\n.powerui-list-item__main {\n    /* text-align: left; */\n    display: flex;\n    flex-direction: column;\n    row-gap: 6px;\n    align-items: flex-start;\n    text-wrap: auto;\n    text-align: left;\n    cursor: auto;\n}";
styleInject$1(css_248z$g);

var css_248z$f = ".powerui-list-textfield__value {\n    text-wrap: auto;\n    text-align: left;\n}\n\n.powerui-list-textfield__edit {}\n\n.powerui-list-textfield__edit__reply {\n    display: flex;\n    align-items: center;\n    border-radius: 6px;\n    padding: 12px;\n    border: 1px solid var(--powerui-list-border-color);\n    background-color: var(--powerui-list-bg-field-input);\n    color: var(--basicui-fg);\n    gap: 12px;\n}\n\n.powerui-list-textfield__edit__reply__input {\n    border: none;\n    width: 100%;\n    outline: none;\n    background-color: transparent;\n    color: var(--basicui-fg);\n}\n\n.powerui-list-textfield__edit__reply__send svg {\n    fill: var(--basicui-bg-primary);\n}\n\n.powerui-list-textfield__edit__reply__cancel svg {\n    fill: var(--basicui-bg-default);\n}\n\n.powerui-list-textfield__label {\n    color: var(--basicui-fg-disabled);\n}";
styleInject$1(css_248z$f);

function isEmptyOrSpaces(str) {
    return str === null || str === undefined || String(str).trim() === '';
}

var BASE_CLASS$f = "powerui-list-textfield";
var TextField$1 = function (_a) {
    _a.field; _a.fieldPath; var value = _a.value;
    return (React$1.createElement(React$1.Fragment, null, !isEmptyOrSpaces(value) && React$1.createElement("span", { className: getClassName(BASE_CLASS$f, ["value"]) }, value)));
};

var css_248z$e = ".powerui-list-selectfield__edit {}\n\n.powerui-list-selectfield__edit__reply {\n    display: grid;\n    grid-template-columns: 1fr auto auto;\n    border-radius: 6px;\n    padding: 4px 12px;\n    border: 1px solid var(--powerui-list-border-color);\n    background-color: var(--powerui-list-bg-field-input);\n    color: var(--basicui-fg);\n    gap: 12px;\n}\n\n.powerui-list-selectfield__edit__reply .basicui-select__button {\n    border: none;\n}\n\n.powerui-list-selectfield__edit__reply__input {\n    border: none;\n    width: 100%;\n    outline: none;\n    background-color: transparent;\n    color: var(--basicui-fg);\n}\n\n.powerui-list-selectfield__edit__reply__send svg {\n    fill: var(--basicui-bg-primary);\n}\n\n.powerui-list-selectfield__edit__reply__cancel svg {\n    fill: var(--basicui-bg-default);\n}\n\n.powerui-list-selectfield__label {\n    color: var(--basicui-fg-disabled);\n}";
styleInject$1(css_248z$e);

var BASE_CLASS$e = "powerui-list-selectfield";
var SelectField$1 = function (_a) {
    var field = _a.field; _a.fieldPath; var value = _a.value;
    return (React$1.createElement(React$1.Fragment, null, Array.isArray(value) && value.length > 0 && React$1.createElement("span", { className: getClassName(BASE_CLASS$e, ["value"]) }, value.map(function (val) { var _a, _b; return ((_b = (_a = field.options) === null || _a === void 0 ? void 0 : _a.find(function (opt) { return opt.value === val; })) === null || _b === void 0 ? void 0 : _b.label) || val; }).join(', ') || '')));
};

var css_248z$d = ".powerui-field-renderer {\n    margin-right: 16px;\n    display: inline-block;\n}\n\n.powerui-field-renderer--text {\n    font-weight: normal;\n}\n\n.powerui-field-renderer--boolean {\n    font-style: italic;\n}\n\n.powerui-field-renderer--select {\n}\n";
styleInject$1(css_248z$d);

var css_248z$c = ".powerui-list-tagfield__read {\n    display: flex;\n}\n\n.powerui-list-tagfield__read__label {\n    line-height: 2;\n}\n.powerui-list-tagfield__read__tags,\n.powerui-list-tagfield__edit__reply__tags {\n    display: flex;\n    flex-wrap: wrap;\n    gap: 6px;\n}\n.powerui-list-tagfield__edit__reply__tags__tag,\n.powerui-list-tagfield__read__tags__tag {\n    display: inline-flex;\n    align-items: center;\n    background-color: var(--basicui-bg-accent);\n    border-radius: 24px;\n    padding: 2px 10px;\n    font-size: 0.85rem;\n}\n\n.powerui-list-tagfield__edit__reply__tags__tag__delete {\n    margin-left: 6px;\n    cursor: pointer;\n    color: var(--basicui-fg-disabled);\n}\n\n.powerui-list-tagfield__edit .tag-input-wrapper {\n    display: flex;\n    flex-wrap: wrap;\n    gap: 4px;\n    align-items: center;\n    min-height: 40px;\n    padding: 4px 0;\n}\n\n.powerui-list-tagfield__edit__reply__tags__input {\n    border: none;\n    width: 100%;\n    outline: none;\n    background-color: transparent;\n    color: var(--basicui-fg);\n    border-radius: 6px;\n    border: 1px solid var(--powerui-list-border-color);\n    padding: 12px;\n}\n\n.powerui-list-tagfield__edit__reply__tags__actions {\n    display: flex;\n    column-gap: 12px;\n    justify-content: flex-end;\n    padding-top: 12px;\n}\n\n.powerui-list-tagfield__edit__reply__tags__actions__cancel svg {\n    fill: var(--basicui-bg-default);\n}\n\n\n.powerui-list-tagfield__edit__reply__tags__actions__send svg {\n    fill: var(--basicui-bg-primary);\n}\n\n.powerui-list-tagfield__read__label {\n    color: var(--basicui-fg-disabled);\n}";
styleInject$1(css_248z$c);

var BASE_CLASS$d = 'powerui-list-tagfield';
var TagField$1 = function (_a) {
    _a.field; _a.fieldPath; var _b = _a.value, value = _b === void 0 ? [] : _b;
    var _c = useState(Array.isArray(value) ? value : []), localValue = _c[0], setLocalValue = _c[1];
    useEffect(function () {
        setLocalValue(value || '');
    }, [value]);
    return (React$1.createElement(React$1.Fragment, null,
        "  ",
        localValue.length > 0 && React$1.createElement("div", { className: getClassName(BASE_CLASS$d, ['read', 'tags']) }, localValue.map(function (tag, idx) { return (React$1.createElement("span", { key: idx, className: getClassName(BASE_CLASS$d, ['read', 'tags', "tag"]) }, tag.value)); }))));
};

var FieldRenderer$1 = function (props) {
    var field = props.field;
    switch (field.type) {
        case 'text':
        case 'email':
        case 'number':
        case 'phone':
        case 'password':
        case 'textarea':
            return React$1.createElement(TextField$1, __assign$1({}, props));
        case 'tag':
            return React$1.createElement(TagField$1, __assign$1({}, props));
        case 'select':
        case 'multiselect':
            return React$1.createElement(SelectField$1, __assign$1({}, props));
        default:
            return React$1.createElement("div", null,
                "Unsupported field type: ",
                field.type);
    }
};

var css_248z$b = ".powerui-actionbar {\n    display: flex;\n    flex-direction: column;\n    row-gap: 6px;\n}\n\n.powerui-actionbar__popover {\n    background-color: var(--basicui-bg-card);\n    border-radius: 4px;\n    border: 1px solid var(--basicui-border-color);\n    padding: 6px 6px;\n    display: flex;\n    flex-direction: column;\n\n}\n\n\n.powerui-actionbar__popover__button {\n    display: flex;\n    justify-content: flex-start;\n    padding: 12px 12px;\n    border-radius: 4px;\n    column-gap: 12px;\n}\n\n.powerui-actionbar__popover__button:hover {\n    background-color: var(--basicui-bg-accent);\n}";
styleInject$1(css_248z$b);

var BASE_CLASS$c = 'powerui-actionbar';
var ActionBar = function (props) {
    var _a, _b, _c, _d, _e;
    var popoverRef = useRef(null);
    var _f = useState(false), isOpen = _f[0], setIsOpen = _f[1];
    var _g = useState(false), loading = _g[0], setLoading = _g[1];
    var handleCheck = function () {
        var _a;
        (_a = props.onCheck) === null || _a === void 0 ? void 0 : _a.call(props, !props.isChecked);
    };
    var handleClick = function (e) { return __awaiter$1(void 0, void 0, void 0, function () {
        var _a;
        return __generator$1(this, function (_b) {
            switch (_b.label) {
                case 0:
                    setLoading(true);
                    return [4 /*yield*/, ((_a = props.onActionClick) === null || _a === void 0 ? void 0 : _a.call(props, e))];
                case 1:
                    _b.sent();
                    setLoading(false);
                    return [2 /*return*/];
            }
        });
    }); };
    return (React$1.createElement("div", { className: BASE_CLASS$c },
        props.onCheck && React$1.createElement(IconButton_1, { theme: props.isChecked ? ThemeType_1.primary : ThemeType_1.default, variant: props.isChecked ? ButtonVariantType_1.default : ButtonVariantType_1.outline, circle: true, onClick: handleCheck },
            React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 448 512" },
                React$1.createElement("path", { d: "M438.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L160 338.7 393.4 105.4c12.5-12.5 32.8-12.5 45.3 0z" }))), (_b = (_a = props.schema.actions) === null || _a === void 0 ? void 0 : _a.primaryMenu) === null || _b === void 0 ? void 0 :
        _b.map(function (item, index) {
            return React$1.createElement(IconButton_1, { key: index, loading: loading, circle: true, onClick: function () { return handleClick(item); } },
                React$1.createElement(SvgIcon_1, { height: 16, width: 16 }, item.icon));
        }),
        ((_c = props.schema.actions) === null || _c === void 0 ? void 0 : _c.contextMenu) && React$1.createElement("div", null,
            React$1.createElement(IconButton_1, { loading: loading, ref: popoverRef, circle: true, onClick: function () { return setIsOpen(true); } }, "..."),
            React$1.createElement(Popover_1, { anchorRef: popoverRef, visible: isOpen, onClose: function () { return setIsOpen(false); } },
                React$1.createElement("div", { className: getClassName(BASE_CLASS$c, ["popover"]) }, (_e = (_d = props.schema.actions) === null || _d === void 0 ? void 0 : _d.contextMenu) === null || _e === void 0 ? void 0 : _e.map(function (item, index) {
                    return React$1.createElement("button", { className: getClassName(BASE_CLASS$c, ["popover", "button"], [], "basicui-clean-button"), key: index, onClick: function () { return handleClick(item); } },
                        React$1.createElement(SvgIcon_1, { width: 12, height: 12 },
                            React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 448 512" },
                                React$1.createElement("path", { d: "M438.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L160 338.7 393.4 105.4c12.5-12.5 32.8-12.5 45.3 0z" }))),
                        item.label);
                }))))));
};

var BASE_CLASS$b = 'powerui-list-item';
var ListItem = function (props) {
    var getValueAtPath = function (path) {
        return path.split('.').reduce(function (acc, key) { return acc === null || acc === void 0 ? void 0 : acc[key]; }, props.data);
    };
    var handleActionClick = function (e) { return __awaiter$1(void 0, void 0, void 0, function () {
        var _a;
        return __generator$1(this, function (_b) {
            switch (_b.label) {
                case 0: return [4 /*yield*/, ((_a = props.onActionClick) === null || _a === void 0 ? void 0 : _a.call(props, e, props.data.reference))];
                case 1:
                    _b.sent();
                    return [2 /*return*/];
            }
        });
    }); };
    return (React$1.createElement("div", { className: getClassName(BASE_CLASS$b, [], props.isChecked ? ["checked"] : []) },
        React$1.createElement(ActionBar, { isChecked: props.isChecked, schema: props.schema, onCheck: props.onCheck, onActionClick: handleActionClick }),
        React$1.createElement("button", { className: getClassName(BASE_CLASS$b, ["main"], [], "basicui-clean-button"), onClick: props.onClick }, props.schema.fields.map(function (field) { return (React$1.createElement(FieldRenderer$1, { key: field.name, field: field, fieldPath: field.name, value: getValueAtPath(field.name) })); }))));
};

var BASE_CLASS$a = 'powerui-list';
var List = function (props) {
    var _a, _b, _c, _d;
    var handleCheck = function (reference, checked) {
        if (!props.setCheckedItems)
            return;
        if (checked) {
            if (!props.checkedItems.includes(reference)) {
                props.setCheckedItems(__spreadArray$1(__spreadArray$1([], props.checkedItems, true), [reference], false));
            }
        }
        else {
            props.setCheckedItems(props.checkedItems.filter(function (item) { return item !== reference; }));
        }
    };
    return (React$1.createElement("div", { className: BASE_CLASS$a },
        ((_a = props.listSchema.header) === null || _a === void 0 ? void 0 : _a.title) && React$1.createElement("h2", null, getValue((_b = props.listSchema.header) === null || _b === void 0 ? void 0 : _b.title, props.data)),
        ((_c = props.listSchema.header) === null || _c === void 0 ? void 0 : _c.subtitle) && React$1.createElement("p", null, getValue((_d = props.listSchema.header) === null || _d === void 0 ? void 0 : _d.subtitle, props.data)),
        React$1.createElement("div", { className: getClassName(BASE_CLASS$a, ["actionheader"]) },
            React$1.createElement("div", { className: getClassName(BASE_CLASS$a, ["actionheader", "pagination"]) }, "pagination"),
            React$1.createElement("div", { className: getClassName(BASE_CLASS$a, ["actionheader", "actions"]) }, props.actions)),
        props.data.map(function (entry, index) {
            var _a;
            return (React$1.createElement(ListItem, __assign$1({ key: index, data: entry, schema: props.listSchema, isChecked: (_a = props.checkedItems) === null || _a === void 0 ? void 0 : _a.includes(entry.reference), onClick: function () { var _a; return (_a = props.onItemClick) === null || _a === void 0 ? void 0 : _a.call(props, entry.reference); } }, (props.setCheckedItems && {
                onCheck: function (checked) { return handleCheck(entry.reference, checked); },
            }), { onActionClick: props.onActionClick })));
        })));
};
var getValue = function (dataSpec, data) {
    if (!dataSpec || !data) {
        return undefined;
    }
    if (dataSpec.type === "static") {
        return dataSpec.value;
    }
    if (!dataSpec.field) {
        return undefined;
    }
    var path = dataSpec.field.split(".");
    var result = path.reduce(function (acc, key) {
        if (acc && typeof acc === "object" && key in acc) {
            return acc[key];
        }
        return undefined;
    }, data);
    return result != null ? String(result) : undefined;
};

var css_248z$a = ".powerui-cf-chatbubble {\n  background-color: var(--powerui-cf-bg-field);\n  padding: 1rem 1.25rem;\n  border-radius: 12px;\n  opacity: 1;\n  transition: background-color 250ms ease-in-out, color 250ms ease-in-out, opacity 500ms ease-in-out, 250ms ease-in-out;\n  border: 1px dotted var(--powerui-cf-border-color);\n  /* border-left: 4px solid var(--basicui-bg-primary); */\n}\n\n.powerui-cf-chatbubble--editing {\n  /* border-color: var(--basicui-bg-primary); */\n}\n\n.powerui-cf-chatbubble--not-editing {\n  flex-direction: column;\n  justify-content: flex-start;\n  align-items: flex-start;\n  cursor: default;\n  row-gap: 6px;\n}\n\n.powerui-cf-chatbubble--disabled {\n  opacity: 0.25;\n}";
styleInject$1(css_248z$a);

var BASE_CLASS$9 = "powerui-cf-chatbubble";
var lastActiveBubbleId = null;
var ChatBubble = function (props) {
    var _a = useState(), addClass = _a[0], setAddClass = _a[1];
    var containerRef = useRef(null);
    var instanceId = useRef(Math.random().toString(36).substring(2));
    useEffect(function () {
        if (props.isEdit) {
            lastActiveBubbleId = instanceId.current;
        }
    }, [props.isEdit]);
    useEffect(function () {
        var _addClass = [];
        if (props.isEdit) {
            _addClass.push("editing");
        }
        else {
            _addClass.push("not-editing");
        }
        if (props.role) {
            _addClass.push(props.role);
        }
        if (props.disabled) {
            _addClass.push("disabled");
        }
        setAddClass(_addClass);
    }, [props.role, props.isEdit, props.disabled]);
    useEffect(function () {
        if (!props.isEdit)
            return;
        var handleKeyDown = function (event) {
            if (event.key === 'Escape') {
                if (props.isEdit && lastActiveBubbleId === instanceId.current) {
                    props.onCancel();
                }
            }
        };
        document.addEventListener('keydown', handleKeyDown);
        return function () {
            document.removeEventListener('keydown', handleKeyDown);
        };
    }, [props.isEdit]);
    var handleClick = function () {
        var _a;
        lastActiveBubbleId = instanceId.current;
        (_a = props.onEdit) === null || _a === void 0 ? void 0 : _a.call(props);
    };
    return (React$1.createElement(React$1.Fragment, null,
        props.isEdit && React$1.createElement("div", { className: getClassName(BASE_CLASS$9, [], addClass), onClickCapture: handleClick, ref: containerRef }, props.children),
        !props.isEdit && React$1.createElement("button", { className: getClassName(BASE_CLASS$9, [], addClass, "basicui-clean-button"), onClick: props.onEdit }, props.children)));
};

var css_248z$9 = ".powerui-cf-textfield__value {\n    text-wrap: auto;\n    text-align: left;\n}\n\n.powerui-cf-textfield__edit {}\n\n.powerui-cf-textfield__edit__reply {\n    display: flex;\n    align-items: center;\n    /* border-radius: 6px; */\n    /* border: 1px solid var(--powerui-cf-border-color); */\n    /* border-bottom: 1px solid var(--powerui-cf-border-color); */\n    background-color: var(--powerui-cf-bg-field-input);\n    color: var(--basicui-fg);\n    gap: 12px;\n}\n\n.powerui-cf-textfield__edit__reply__input {\n    border: none;\n    width: 100%;\n    outline: none;\n    background-color: transparent;\n    color: var(--basicui-fg);\n    border-bottom: 2px solid var(--powerui-cf-border-color);\n    transition: border-color 250ms ease-in-out;\n    padding: 12px 0;\n    font-size: 20px;\n}\n\n.powerui-cf-textfield__edit__reply__input:focus {\n    /* border-color: var(--basicui-bg-primary) */\n}\n\n.powerui-cf-textfield__edit__reply__input::placeholder {\n    /* color: var(--basicui-bg-primary); */\n    opacity: 0.4;\n}\n\n.powerui-cf-textfield__label {\n    color: var(--basicui-fg-disabled);\n}";
styleInject$1(css_248z$9);

var css_248z$8 = ".powerui-cf-replyaction {\n    display: flex;\n    align-items: center;\n    justify-content: space-between;\n    margin-top: 24px;\n}\n.powerui-cf-replyaction__left {\n    display: flex;\n    column-gap: 12px;\n    align-items: center;\n}\n\n.powerui-cf-replyaction__left__ok {\n    background-color: var(--basicui-bg-primary);\n    border: 1px solid var(--basicui-bg-primary);\n    color: var(--basicui-fg-primary);\n    padding: 6px 6px;\n    border-radius: 4px;\n}\n\n.powerui-cf-replyaction__left__ok svg {\n    fill: var(--basicui-fg-primary);\n}\n\n.powerui-cf-replyaction__left__assist {\n    /* background-color: var(--basicui-bg-warning); */\n    color: var(--basicui-bg-primary);\n    /* border: 1px solid var(--basicui-border-color); */\n    padding: 6px 6px;\n    border-radius: 4px;\n}\n\n.powerui-cf-replyaction__left__assist svg {\n    fill: var(--basicui-bg-primary);\n}\n\n.powerui-cf-replyaction__cancel {\n    /* border: 1px solid var(--basicui-fg); */\n    color: var(--basicui-fg);\n    opacity: 0.4;\n    padding: 6px 6px;\n    border-radius: 4px;\n}\n\n.powerui-cf-replyaction__cancel svg {\n    fill: var(--basicui-fg);\n}";
styleInject$1(css_248z$8);

var BASE_CLASS$8 = "powerui-cf-replyaction";
var ReplyAction = function (props) {
    return (React$1.createElement("div", { className: getClassName(BASE_CLASS$8) },
        React$1.createElement("div", { className: getClassName(BASE_CLASS$8, ["left"]) },
            React$1.createElement("button", { className: getClassName(BASE_CLASS$8, ["left", "ok"], [], "basicui-clean-button"), onClick: props.onSave },
                "OK",
                React$1.createElement(SvgIcon_1, { height: "16px", width: "16px" },
                    React$1.createElement("svg", { width: "800px", height: "800px", viewBox: "0 0 24 24", version: "1.1", xmlns: "http://www.w3.org/2000/svg" },
                        React$1.createElement("g", { id: "\uD83D\uDD0D-System-Icons", stroke: "none", "stroke-width": "1", fill: "none", "fill-rule": "evenodd" },
                            React$1.createElement("g", { id: "ic_fluent_arrow_enter_24_filled", fill: "#212121", "fill-rule": "nonzero" },
                                React$1.createElement("path", { d: "M21,4 C21.5128358,4 21.9355072,4.38604019 21.9932723,4.88337887 L22,5 L22,11.5 C22,13.3685634 20.5357224,14.8951264 18.6920352,14.9948211 L18.5,15 L5.415,15 L8.70710678,18.2928932 C9.06759074,18.6533772 9.09532028,19.2206082 8.79029539,19.6128994 L8.70710678,19.7071068 C8.34662282,20.0675907 7.77939176,20.0953203 7.38710056,19.7902954 L7.29289322,19.7071068 L2.29289322,14.7071068 C2.25749917,14.6717127 2.22531295,14.6343256 2.19633458,14.5953066 L2.12467117,14.4840621 L2.12467117,14.4840621 L2.07122549,14.371336 L2.07122549,14.371336 L2.03584514,14.265993 L2.03584514,14.265993 L2.0110178,14.1484669 L2.0110178,14.1484669 L2.00397748,14.0898018 L2.00397748,14.0898018 L2,14 L2.00278786,13.9247615 L2.00278786,13.9247615 L2.02024007,13.7992742 L2.02024007,13.7992742 L2.04973809,13.6878575 L2.04973809,13.6878575 L2.09367336,13.5767785 L2.09367336,13.5767785 L2.14599545,13.4792912 L2.14599545,13.4792912 L2.20970461,13.3871006 L2.20970461,13.3871006 L2.29289322,13.2928932 L2.29289322,13.2928932 L7.29289322,8.29289322 C7.68341751,7.90236893 8.31658249,7.90236893 8.70710678,8.29289322 C9.06759074,8.65337718 9.09532028,9.22060824 8.79029539,9.61289944 L8.70710678,9.70710678 L5.415,13 L18.5,13 C19.2796961,13 19.9204487,12.4051119 19.9931334,11.64446 L20,11.5 L20,5 C20,4.44771525 20.4477153,4 21,4 Z", id: "\uD83C\uDFA8-Color" })))))),
            React$1.createElement("button", { className: getClassName(BASE_CLASS$8, ["left", "assist"], [], "basicui-clean-button"), onClick: props.onAssist },
                "Assist",
                React$1.createElement(SvgIcon_1, { height: "16px", width: "16px" },
                    React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 640 640" },
                        React$1.createElement("path", { d: "M528 70.1C537.5 61.6 552 62 561 71L569 79C578 88 578.4 102.5 569.9 112L484.1 207.9C481.5 210.8 480 214.6 480 218.6L480 240C480 248.8 472.8 256 464 256L448.2 256C443.6 256 439.3 257.9 436.3 261.3L164.7 564.9C158.4 572 149.4 576 139.9 576C131.1 576 122.6 572.5 116.4 566.2L73.7 523.7C67.5 517.5 64 509 64 500.2C64 490.7 68 481.7 75.1 475.4L186.7 375.6C190.1 372.6 192 368.2 192 363.7L192 336.1C192 327.3 199.2 320.1 208 320.1L242.6 320.1C246.5 320.1 250.3 318.6 253.3 316L528 70.1zM496 352C499.6 352 502.7 354.4 503.7 357.8L518.5 409.5L570.2 424.3C573.6 425.3 576 428.4 576 432C576 435.6 573.6 438.7 570.2 439.7L518.5 454.5L503.7 506.2C502.7 509.6 499.6 512 496 512C492.4 512 489.3 509.6 488.3 506.2L473.5 454.5L421.8 439.7C418.4 438.7 416 435.6 416 432C416 428.4 418.4 425.3 421.8 424.3L473.5 409.5L488.3 357.8C489.3 354.4 492.4 352 496 352zM151.7 133.8L166.5 185.5L218.2 200.3C221.6 201.3 224 204.4 224 208C224 211.6 221.6 214.7 218.2 215.7L166.5 230.5L151.7 282.2C150.7 285.6 147.6 288 144 288C140.4 288 137.3 285.6 136.3 282.2L121.5 230.5L69.8 215.7C66.4 214.7 64 211.6 64 208C64 204.4 66.4 201.3 69.8 200.3L121.5 185.5L136.3 133.8C137.3 130.4 140.4 128 144 128C147.6 128 150.7 130.4 151.7 133.8zM272 64C275.7 64 278.9 66.5 279.8 70.1L286.6 97.4L313.9 104.2C317.5 105.1 320 108.3 320 112C320 115.7 317.5 118.9 313.9 119.8L286.6 126.6L279.8 153.9C278.9 157.5 275.7 160 272 160C268.3 160 265.1 157.5 264.2 153.9L257.4 126.6L230.1 119.8C226.5 118.9 224 115.7 224 112C224 108.3 226.5 105.1 230.1 104.2L257.4 97.4L264.2 70.1C265.1 66.5 268.3 64 272 64z" }))))),
        React$1.createElement("button", { className: getClassName(BASE_CLASS$8, ["cancel"], [], "basicui-clean-button"), onClick: props.onCancel },
            "Cancel",
            React$1.createElement(SvgIcon_1, { height: "16px", width: "16px" },
                React$1.createElement("svg", { width: "800px", height: "800px", viewBox: "0 0 16 16", version: "1.1", xmlns: "http://www.w3.org/2000/svg" },
                    React$1.createElement("path", { d: "M8 12c-0.726-0.029-1.409-0.177-2.043-0.425l0.403-0.915c0.435 0.202 0.945 0.319 1.482 0.319 0.326 0 0.643-0.043 0.943-0.125 0.121-0.109 0.215-0.285 0.215-0.484 0-0 0-0 0-0 0.070-0.43-0.22-0.62-1.17-1-0.83-0.29-2.040-0.76-1.83-2.080 0.072-0.594 0.46-1.082 0.989-1.296 0.223-0.053 0.466-0.081 0.715-0.081 0.724 0 1.393 0.235 1.934 0.633l-0.569 0.754c-0.366-0.248-0.817-0.396-1.302-0.396-0.123 0-0.243 0.009-0.361 0.028-0.215 0.084-0.377 0.296-0.387 0.547-0.080 0.401 0.14 0.581 1.15 1.001 0.85 0.33 2 0.77 1.8 2.080-0.067 0.511-0.364 0.94-0.782 1.186-0.323 0.163-0.696 0.256-1.090 0.256-0.034 0-0.069-0.001-0.103-0.002z" }),
                    React$1.createElement("path", { d: "M13.71 12c-0.027 0.001-0.058 0.001-0.089 0.001-0.583 0-1.124-0.18-1.57-0.488-0.646-0.548-1.059-1.37-1.059-2.289 0-0.079 0.003-0.157 0.009-0.235-0.011-0.079-0.016-0.183-0.016-0.288 0-0.899 0.413-1.701 1.060-2.228 0.5-0.282 1.091-0.446 1.72-0.446 0.443 0 0.868 0.081 1.259 0.23l-0.374 0.922c-0.276-0.111-0.595-0.176-0.93-0.176-0.388 0-0.756 0.087-1.086 0.242-0.395 0.361-0.652 0.893-0.652 1.485 0 0.095 0.007 0.188 0.019 0.279-0.010 0.063-0.016 0.148-0.016 0.234 0 0.599 0.255 1.138 0.663 1.514 0.346 0.177 0.754 0.28 1.185 0.28 0.292 0 0.573-0.047 0.835-0.134l0.331 0.905c-0.383 0.121-0.823 0.19-1.279 0.19-0.004 0-0.008 0-0.012-0z" }),
                    React$1.createElement("path", { d: "M5 4v-1h-4v9h4v-1h-3v-3h3v-1h-3v-3h3z" }))))));
};

var css_248z$7 = ".powerui-cf-messagesection {\n    /* color: var(--basicui-bg-danger-muted); */\n    /* color: var(--basicui-bg-default-text); */\n    margin-top: 6px;\n    display: flex;\n    flex-direction: column;\n    row-gap: 4px;\n}\n\n.powerui-cf-messagesection__message {\n    display: inline-flex;\n    align-items: center;\n    gap: 4px;\n}\n\n.powerui-cf-messagesection__message svg {\n    fill: var(--basicui-bg-danger-muted);\n}";
styleInject$1(css_248z$7);

var BASE_CLASS$7 = "powerui-cf-messagesection";
var MessageSection = function (props) {
    return (React$1.createElement("div", { className: getClassName(BASE_CLASS$7, [], [], "small") },
        Object.keys(props.validationOutcome).map(function (item) { return (React$1.createElement(React$1.Fragment, null, props.validationOutcome[item] && React$1.createElement("div", { className: getClassName(BASE_CLASS$7, ["message"]) },
            React$1.createElement(SvgIcon_1, { width: 12, height: 12 },
                React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 640 640" },
                    React$1.createElement("path", { d: "M320 64C334.7 64 348.2 72.1 355.2 85L571.2 485C577.9 497.4 577.6 512.4 570.4 524.5C563.2 536.6 550.1 544 536 544L104 544C89.9 544 76.9 536.6 69.6 524.5C62.3 512.4 62.1 497.4 68.8 485L284.8 85C291.8 72.1 305.3 64 320 64zM320 232C306.7 232 296 242.7 296 256L296 368C296 381.3 306.7 392 320 392C333.3 392 344 381.3 344 368L344 256C344 242.7 333.3 232 320 232zM346.7 448C347.3 438.1 342.4 428.7 333.9 423.5C325.4 418.4 314.7 418.4 306.2 423.5C297.7 428.7 292.8 438.1 293.4 448C292.8 457.9 297.7 467.3 306.2 472.5C314.7 477.6 325.4 477.6 333.9 472.5C342.4 467.3 347.3 457.9 346.7 448z" }))),
            item))); }),
        React$1.createElement("div", { className: getClassName(BASE_CLASS$7, ["message"]) },
            React$1.createElement(SvgIcon_1, { width: 12, height: 12 },
                React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 640 640" },
                    React$1.createElement("path", { d: "M320 64C334.7 64 348.2 72.1 355.2 85L571.2 485C577.9 497.4 577.6 512.4 570.4 524.5C563.2 536.6 550.1 544 536 544L104 544C89.9 544 76.9 536.6 69.6 524.5C62.3 512.4 62.1 497.4 68.8 485L284.8 85C291.8 72.1 305.3 64 320 64zM320 232C306.7 232 296 242.7 296 256L296 368C296 381.3 306.7 392 320 392C333.3 392 344 381.3 344 368L344 256C344 242.7 333.3 232 320 232zM346.7 448C347.3 438.1 342.4 428.7 333.9 423.5C325.4 418.4 314.7 418.4 306.2 423.5C297.7 428.7 292.8 438.1 293.4 448C292.8 457.9 297.7 467.3 306.2 472.5C314.7 477.6 325.4 477.6 333.9 472.5C342.4 467.3 347.3 457.9 346.7 448z" }))),
            "This field is required"),
        React$1.createElement("div", { className: getClassName(BASE_CLASS$7, ["message"]) },
            React$1.createElement(SvgIcon_1, { width: 12, height: 12 },
                React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 640 640" },
                    React$1.createElement("path", { d: "M320 64C334.7 64 348.2 72.1 355.2 85L571.2 485C577.9 497.4 577.6 512.4 570.4 524.5C563.2 536.6 550.1 544 536 544L104 544C89.9 544 76.9 536.6 69.6 524.5C62.3 512.4 62.1 497.4 68.8 485L284.8 85C291.8 72.1 305.3 64 320 64zM320 232C306.7 232 296 242.7 296 256L296 368C296 381.3 306.7 392 320 392C333.3 392 344 381.3 344 368L344 256C344 242.7 333.3 232 320 232zM346.7 448C347.3 438.1 342.4 428.7 333.9 423.5C325.4 418.4 314.7 418.4 306.2 423.5C297.7 428.7 292.8 438.1 293.4 448C292.8 457.9 297.7 467.3 306.2 472.5C314.7 477.6 325.4 477.6 333.9 472.5C342.4 467.3 347.3 457.9 346.7 448z" }))),
            "Must be at least 100 characters"),
        React$1.createElement("div", { className: getClassName(BASE_CLASS$7, ["message"]) },
            React$1.createElement(SvgIcon_1, { width: 12, height: 12 },
                React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 640 640" },
                    React$1.createElement("path", { d: "M320 64C334.7 64 348.2 72.1 355.2 85L571.2 485C577.9 497.4 577.6 512.4 570.4 524.5C563.2 536.6 550.1 544 536 544L104 544C89.9 544 76.9 536.6 69.6 524.5C62.3 512.4 62.1 497.4 68.8 485L284.8 85C291.8 72.1 305.3 64 320 64zM320 232C306.7 232 296 242.7 296 256L296 368C296 381.3 306.7 392 320 392C333.3 392 344 381.3 344 368L344 256C344 242.7 333.3 232 320 232zM346.7 448C347.3 438.1 342.4 428.7 333.9 423.5C325.4 418.4 314.7 418.4 306.2 423.5C297.7 428.7 292.8 438.1 293.4 448C292.8 457.9 297.7 467.3 306.2 472.5C314.7 477.6 325.4 477.6 333.9 472.5C342.4 467.3 347.3 457.9 346.7 448z" }))),
            "This field is required This field is required This field is required This field is required This field is required This field is required This field is required This field is required This field is required This field is required This field is required")));
};

var requiredCheck = function (validationSpec, value) {
    if (!validationSpec || !validationSpec.required || !isEmptyOrSpaces(value))
        return false;
    return true;
};

var css_248z$6 = ".powerui-assistant {\n    display: flex;\n    flex-direction: column;\n    row-gap: 12px;\n}\n\n.powerui-assistant__content,\n.powerui-assistant__compose__input {\n    font-size: 16px;\n    width: 100%;\n    padding: 6px 6px;\n    border: 1px solid var(--basicui-border-color);\n    border-radius: 4px;\n    outline: none;\n    resize: none;\n    height: 200px;\n    background-color: transparent;\n    color: var(--basicui-fg);\n}\n\n.powerui-assistant__compose {\n    display: grid;\n    grid-template-columns: 1fr auto;\n    column-gap: 6px;\n    border-bottom: 1px solid var(--basicui-border-color);\n    align-items: flex-end;\n    padding: 12px 0px;\n}\n\n.powerui-assistant__compose__input {\n    border: none;\n    height: 50px;\n}\n\n.powerui-assistant__compose__send {\n\n}\n\n.powerui-assistant__compose__send svg {\n    fill: var(--basicui-bg-primary);\n}\n.powerui-assistant__compose__send:hover svg {\n    fill: var(--basicui-bg-primary-text);\n}\n\n.powerui-assistant__prompts {\n    display: flex;\n    flex-direction: row;\n    flex-wrap: wrap;\n    row-gap: 12px;\n    column-gap: 12px;\n}\n\n.powerui-assistant__prompts__button {\n    border: 1px solid var(--basicui-border-color);\n    border-radius: 24px;\n    padding: 4px 12px;\n    opacity: 0.6;\n    background-color: var(--basicui-bg-accent);\n    cursor: pointer;\n    transition: 250ms ease-in-out border-color, 250ms ease-in-out opacity;\n}\n\n.powerui-assistant__prompts__button:hover {\n    border-color: var(--basicui-bg-primary-transparent);\n    opacity: 1;\n}";
styleInject$1(css_248z$6);

var copyHtmlToClipboard = function (_a) {
    var htmlContent = _a.htmlContent, textContent = _a.textContent;
    if (!htmlContent || !textContent || isEmptyOrSpaces(htmlContent)) {
        return "";
    }
    var blobHtml = new Blob([htmlContent], { type: "text/html" });
    var blobText = new Blob([textContent], { type: "text/plain" });
    var data = [
        new ClipboardItem({
            "text/html": blobHtml,
            "text/plain": blobText,
        }),
    ];
    navigator.clipboard
        .write(data)
        .then(function () {
        console.log("HTML and text content copied to clipboard.");
    })
        .catch(function (err) {
        console.error("Failed to copy content:", err);
    });
};

var _PREDEFINED_PROMPTS = [
    {
        label: "Elaborate",
        value: "Elaborate the text with more detailed content",
    },
    {
        label: "Concise",
        value: "Make the text concise, reduce redundancy without loosing its essence",
    },
    {
        label: "Organize",
        value: "Group into appropriate paragraphs and reduce redundancy",
    },
    {
        label: "Headings",
        value: "Logically sort the content and add relevant section headings",
    },
    {
        label: "Grammar",
        value: "Apply correct grammar, spelling and sentence formations",
    },
];
var BASE_CLASS$6 = "powerui-assistant";
var Assistant = function (props) {
    var _a = useState(false); _a[0]; _a[1];
    var _b = useState(""), instruction = _b[0], setInstruction = _b[1];
    var _c = useState(""), content = _c[0], setContent = _c[1];
    var onCopy = function () {
        copyHtmlToClipboard({
            htmlContent: content,
            textContent: content
        });
        props.onCancel();
    };
    var applyPredefinedPrompt = function (instruction) {
        setInstruction(instruction);
    };
    useEffect(function () {
        var _a;
        if ((_a = props.pendingAction) === null || _a === void 0 ? void 0 : _a.initialText) {
            setContent(props.pendingAction.initialText);
        }
    }, [props.pendingAction]);
    var handleInstructionChange = function (e) {
        setInstruction(e.currentTarget.value);
    };
    var predict = function (event) { return __awaiter$1(void 0, void 0, void 0, function () {
        return __generator$1(this, function (_a) {
            switch (_a.label) {
                case 0:
                    event.preventDefault();
                    if (!props.pendingAction)
                        return [2 /*return*/];
                    return [4 /*yield*/, props.onAssist(props.pendingAction.assistantId, props.pendingAction.initialText, instruction, {
                            onOpen: function () {
                                console.log('[SSE] Opened');
                                setContent('');
                            },
                            onMessage: function (msg) {
                                var _a, _b;
                                try {
                                    var parsed = JSON.parse(msg);
                                    var delta_1 = (_b = (_a = parsed === null || parsed === void 0 ? void 0 : parsed.choices) === null || _a === void 0 ? void 0 : _a[0]) === null || _b === void 0 ? void 0 : _b.delta;
                                    if (delta_1 === null || delta_1 === void 0 ? void 0 : delta_1.role) {
                                        console.log(delta_1.role);
                                    }
                                    if (delta_1 === null || delta_1 === void 0 ? void 0 : delta_1.content) {
                                        setContent(function (prev) { return prev + delta_1.content; });
                                    }
                                }
                                catch (err) {
                                    console.warn('Failed to parse chunk:', msg);
                                }
                            },
                            onDone: function () {
                                console.log('[SSE] Done');
                            },
                            onError: function (err) {
                                console.error('[SSE] Error:', err);
                            }
                        })];
                case 1:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    }); };
    var handleApply = function () {
        props.onUpdate(content);
    };
    var handleContentChange = function (e) {
        setContent(e.currentTarget.value);
    };
    return (React$1.createElement(Modal_1, { isOpen: !!props.pendingAction, onClose: props.onCancel, size: ModalSizeType_1.large },
        React$1.createElement(ModalHeader_1, { onClose: props.onCancel, heading: "Generate content with AI assistance" }),
        React$1.createElement(ModalBody_1, null,
            React$1.createElement("div", { className: BASE_CLASS$6 },
                React$1.createElement("textarea", { className: getClassName(BASE_CLASS$6, ["content"]), name: "content", value: content, onChange: handleContentChange, placeholder: "Content to improvise" }),
                React$1.createElement("form", { className: getClassName(BASE_CLASS$6, ["compose"]), onSubmit: predict },
                    React$1.createElement("textarea", { className: getClassName(BASE_CLASS$6, ["compose", "input"]), name: "instruction", value: instruction, placeholder: "Describe on how to improvise the content?", onChange: handleInstructionChange }),
                    React$1.createElement("button", { type: "submit", className: getClassName(BASE_CLASS$6, ["compose", "send"], [], "basicui-clean-button") },
                        React$1.createElement(SvgIcon_1, null,
                            React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 640 640" },
                                React$1.createElement("path", { d: "M568.4 37.7C578.2 34.2 589 36.7 596.4 44C603.8 51.3 606.2 62.2 602.7 72L424.7 568.9C419.7 582.8 406.6 592 391.9 592C377.7 592 364.9 583.4 359.6 570.3L295.4 412.3C290.9 401.3 292.9 388.7 300.6 379.7L395.1 267.3C400.2 261.2 399.8 252.3 394.2 246.7C388.6 241.1 379.6 240.7 373.6 245.8L261.2 340.1C252.1 347.7 239.6 349.7 228.6 345.3L70.1 280.8C57 275.5 48.4 262.7 48.4 248.5C48.4 233.8 57.6 220.7 71.5 215.7L568.4 37.7z" }))))),
                React$1.createElement("div", { className: getClassName(BASE_CLASS$6, ["prompts"]) }, _PREDEFINED_PROMPTS.map(function (item) { return (React$1.createElement("button", { className: getClassName(BASE_CLASS$6, ["prompts", "button"], [], "basicui-clean-button"), onClick: function () { return applyPredefinedPrompt(item.value); } }, item.label)); })))),
        React$1.createElement(ModalFooter_1, null,
            React$1.createElement(Button_1, { onClick: handleApply, variant: ButtonVariantType_1.transparent }, "Apply"),
            React$1.createElement(Button_1, { onClick: onCopy, variant: ButtonVariantType_1.transparent }, "Copy"))));
};

var BASE_CLASS$5 = "powerui-cf-textfield";
var TextField = function (_a) {
    var field = _a.field, fieldPath = _a.fieldPath, value = _a.value, onChange = _a.onChange, editField = _a.editField, onStartEdit = _a.onStartEdit, onFinishEdit = _a.onFinishEdit, onCancelEdit = _a.onCancelEdit, errorMap = _a.errorMap, onAssist = _a.onAssist;
    var _b = useState([]), errors = _b[0], setErrors = _b[1];
    var _c = useState({}), validationOutcome = _c[0], setValidationOutcome = _c[1];
    var _d = useState(), pendingAssistant = _d[0], setPendingAssistant = _d[1];
    useEffect(function () {
        var _errors = [];
        if (errorMap === null || errorMap === void 0 ? void 0 : errorMap[fieldPath]) {
            _errors = errorMap[fieldPath];
        }
        setErrors(_errors);
    }, [errorMap]);
    var _e = useState(''), localValue = _e[0], setLocalValue = _e[1];
    useEffect(function () {
        setLocalValue(value || '');
    }, [value]);
    useEffect(function () {
        var _validationOutcome = {};
        _validationOutcome.required = requiredCheck(field.validation, localValue);
        // other checks for minLength and maxLength
        console.log(localValue, _validationOutcome.required);
        setValidationOutcome(_validationOutcome);
    }, [field, localValue]);
    var handleSubmit = function () {
        onChange(localValue);
        onFinishEdit();
    };
    var handleAssist = function () {
        if (field.assistant && onAssist) {
            setPendingAssistant({
                assistantId: field.assistant.id,
                initialText: localValue
            });
        }
    };
    var handleCancel = function () {
        setLocalValue(value || '');
        onCancelEdit();
    };
    var handleRequestEdit = function () {
        if (!editField) {
            onStartEdit(fieldPath);
        }
    };
    var handleAssistantApply = function (e) {
        setLocalValue(e);
        setPendingAssistant(undefined);
    };
    return (React$1.createElement(React$1.Fragment, null,
        React$1.createElement(ChatBubble, { isEdit: editField === fieldPath, onEdit: handleRequestEdit, onCancel: onCancelEdit, disabled: !!editField && editField !== fieldPath }, editField !== fieldPath ? (React$1.createElement(React$1.Fragment, null,
            React$1.createElement("span", { className: getClassName(BASE_CLASS$5, ["label"]) },
                field.label,
                " "),
            !isEmptyOrSpaces(value) && React$1.createElement("span", { className: getClassName(BASE_CLASS$5, ["value"]) }, value))) : (React$1.createElement("div", { className: getClassName(BASE_CLASS$5, ["edit"]) },
            React$1.createElement("div", { className: getClassName(BASE_CLASS$5, ["edit", "prompt"], [], getClassName(BASE_CLASS_FIELD_RENDERER_SHARED, ["prompt"])) }, field.conversationalPrompt || "Enter ".concat(prettify$4(fieldPath), ":")),
            React$1.createElement("form", { onSubmit: function (e) {
                    e.preventDefault();
                    handleSubmit();
                }, className: getClassName(BASE_CLASS$5, ["edit", "reply"], [], getClassName(BASE_CLASS_FIELD_RENDERER_SHARED, ["reply"])), onClick: function (e) { return e.stopPropagation(); } },
                React$1.createElement("input", { name: fieldPath, autoComplete: "off", autoFocus: true, type: "text", value: localValue, placeholder: field.placeholder, className: getClassName(BASE_CLASS$5, ["edit", "reply", "input"], []), onChange: function (e) { return setLocalValue(e.target.value); } })),
            React$1.createElement(MessageSection, { errors: errors, validation: field.validation, validationOutcome: validationOutcome }),
            React$1.createElement(ReplyAction, { onSave: handleSubmit, onCancel: handleCancel, onAssist: handleAssist })))),
        onAssist && React$1.createElement(Assistant, { pendingAction: pendingAssistant, onAssist: onAssist, onCancel: function () { setPendingAssistant(undefined); }, onUpdate: handleAssistantApply })));
};
var prettify$4 = function (key) {
    return key
        .replace(/\.(\d+)/g, function (_, d) { return " #".concat(+d + 1); })
        .replace(/\./g, ' > ')
        .replace(/([a-z])([A-Z])/g, '$1 $2')
        .replace(/\b\w/g, function (l) { return l.toUpperCase(); });
};

var css_248z$5 = ".powerui-cf-selectfield__edit {}\n\n.powerui-cf-selectfield__edit__reply {\n    display: grid;\n    grid-template-columns: 1fr auto auto;\n    border-radius: 6px;\n    padding: 4px 12px;\n    border: 1px solid var(--powerui-cf-border-color);\n    background-color: var(--powerui-cf-bg-field-input);\n    color: var(--basicui-fg);\n    gap: 12px;\n}\n\n.powerui-cf-selectfield__edit__reply .basicui-select__button {\n    border: none;\n}\n\n.powerui-cf-selectfield__edit__reply__input {\n    border: none;\n    width: 100%;\n    outline: none;\n    background-color: transparent;\n    color: var(--basicui-fg);\n}\n\n.powerui-cf-selectfield__label {\n    color: var(--basicui-fg-disabled);\n}";
styleInject$1(css_248z$5);

var BASE_CLASS$4 = "powerui-cf-selectfield";
var SelectField = function (_a) {
    var _b, _c;
    var field = _a.field, fieldPath = _a.fieldPath, value = _a.value, editField = _a.editField, onStartEdit = _a.onStartEdit, onFinishEdit = _a.onFinishEdit, onCancelEdit = _a.onCancelEdit, onChange = _a.onChange;
    var _d = useState(""), localValue = _d[0], setLocalValue = _d[1];
    var _e = useState([]), localValues = _e[0], setLocalValues = _e[1];
    useEffect(function () {
        _reset();
    }, [value]);
    var handleSubmit = function () {
        onChange(localValue);
        onFinishEdit();
    };
    var handleChange = function (e) {
        if (field.multiple) {
            setLocalValues(e.currentTarget.values || []);
        }
        else {
            setLocalValue(e.currentTarget.value);
        }
    };
    var _reset = function () {
        if (field.multiple) {
            setLocalValues(Array.isArray(value) ? value : []);
        }
        else {
            setLocalValue(value);
        }
    };
    var handleCancel = function () {
        _reset();
        onCancelEdit();
    };
    var handleRequestEdit = function () {
        if (!editField) {
            onStartEdit(fieldPath);
        }
    };
    return (React$1.createElement(ChatBubble, { isEdit: editField === fieldPath, onEdit: handleRequestEdit, onCancel: onCancelEdit, disabled: !!editField && editField !== fieldPath }, editField !== fieldPath ? (React$1.createElement(React$1.Fragment, null,
        React$1.createElement("span", { className: getClassName(BASE_CLASS$4, ["label"]) }, field.label),
        Array.isArray(value) && value.length > 0 && React$1.createElement("span", { className: getClassName(BASE_CLASS$4, ["value"]) }, value.map(function (val) { var _a, _b; return ((_b = (_a = field.options) === null || _a === void 0 ? void 0 : _a.find(function (opt) { return opt.value === val; })) === null || _b === void 0 ? void 0 : _b.label) || val; }).join(', ') || ''))) : (React$1.createElement("div", { className: getClassName(BASE_CLASS$4, ["edit"]) },
        React$1.createElement("div", { className: getClassName(BASE_CLASS$4, ["edit", "prompt"], [], getClassName(BASE_CLASS_FIELD_RENDERER_SHARED, ["prompt"])) }, field.conversationalPrompt || "Select ".concat(prettify$3(fieldPath), ":")),
        React$1.createElement("div", { className: getClassName(BASE_CLASS$4, ["edit", "reply"], [], getClassName(BASE_CLASS_FIELD_RENDERER_SHARED, ["reply"])), onClick: function (e) { return e.stopPropagation(); } },
            field.multiple && React$1.createElement(Select_1, { multiple: true, autocomplete: field.options && ((_b = field.options) === null || _b === void 0 ? void 0 : _b.length) > 4, value: localValues, options: field.options || [], onChange: handleChange }),
            !field.multiple && React$1.createElement(Select_1, { autocomplete: field.options && ((_c = field.options) === null || _c === void 0 ? void 0 : _c.length) > 4, value: [localValue], options: field.options || [], onChange: handleChange })),
        React$1.createElement(ReplyAction, { onSave: handleSubmit, onCancel: handleCancel })))));
};
var prettify$3 = function (key) {
    return key
        .replace(/\.(\d+)/g, function (_, d) { return " #".concat(+d + 1); })
        .replace(/\./g, ' > ')
        .replace(/([a-z])([A-Z])/g, '$1 $2')
        .replace(/\b\w/g, function (l) { return l.toUpperCase(); });
};

var css_248z$4 = ".powerui-cf-groupfield {\n    display: flex;\n    flex-direction: column;\n    padding: 12px;\n    background-color: var(--powerui-cf-bg-group-odd);\n    border-radius: 12px;\n}\n\n.powerui-cf-groupfield__main {\n    display: flex;\n    flex-direction: column;\n    gap: 1rem;\n}\n\n.powerui-cf-groupfield--even {\n    background-color: var(--powerui-cf-bg-group-even);\n}\n.powerui-cf-groupfield__header {\n    display: flex;\n    justify-content: space-between;\n    align-items: center;\n    opacity: 1;\n    transition: opacity 500ms ease-in-out;\n    /* padding-bottom: 12px; */\n}\n\n.powerui-cf-groupfield__header h6 {\n    margin: 0;\n}\n\n.powerui-cf-groupfield__header--disabled {\n    opacity: 0.25;\n}\n\n.powerui-cf-groupfield__main {\n    overflow: hidden;\n    margin-top: 12px;\n}\n\n.powerui-cf-groupfield__main--expanded {\n    visibility: visible;\n}\n\n.powerui-cf-groupfield__main--collapsed {\n    max-height: 0;\n    pointer-events: none;\n    margin-top: 0;\n}";
styleInject$1(css_248z$4);

var BASE_CLASS$3 = "powerui-cf-groupfield";
var GroupField = function (props) {
    var _a;
    var _b = useState(false), isCollapsed = _b[0], setIsCollapsed = _b[1];
    var updateNestedValue = function (subPath, subVal) {
        var _a;
        props.onChange(__assign$1(__assign$1({}, (props.value || {})), (_a = {}, _a[subPath] = subVal, _a)));
    };
    var toggleCollapse = function () {
        setIsCollapsed(!isCollapsed);
    };
    return (React$1.createElement("div", { className: getClassName(BASE_CLASS$3, [], props.isEven ? ["even"] : []) },
        React$1.createElement("div", { className: getClassName(BASE_CLASS$3, ["header"], (!!props.editField && props.editField !== props.fieldPath) ? ["disabled"] : []) },
            React$1.createElement("h6", null, prettify$2("".concat(props.fieldPath))),
            React$1.createElement("button", { onClick: toggleCollapse, className: getClassName(BASE_CLASS$3, ["collapse-button"], [], "basicui-clean-button"), "aria-label": isCollapsed ? 'Expand section' : 'Collapse section' },
                React$1.createElement(SvgIcon_1, { height: "12px", width: "12px" }, isCollapsed ? (React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 448 512" },
                    React$1.createElement("path", { d: "M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32v112H80c-17.7 0-32 14.3-32 32s14.3 32 32 32h112v112c0 17.7 14.3 32 32 32s32-14.3 32-32V256h112c17.7 0 32-14.3 32-32s-14.3-32-32-32H256V80z" }))) : (React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 448 512" },
                    React$1.createElement("path", { d: "M416 208H32c-17.7 0-32 14.3-32 32s14.3 32 32 32h384c17.7 0 32-14.3 32-32s-14.3-32-32-32z" })))))),
        React$1.createElement("div", { className: getClassName(BASE_CLASS$3, ["main"], isCollapsed ? ["collapsed"] : ["expanded"]) }, (_a = props.field.fields) === null || _a === void 0 ? void 0 : _a.map(function (subField) {
            var _a;
            return (React$1.createElement(FieldRenderer, { key: "".concat(props.fieldPath, ".").concat(subField.name), field: subField, fieldPath: "".concat(props.fieldPath, ".").concat(subField.name), value: (_a = props.value) === null || _a === void 0 ? void 0 : _a[subField.name], onChange: function (val) { return updateNestedValue(subField.name, val); }, isEven: !props.isEven, editField: props.editField, onStartEdit: props.onStartEdit, onFinishEdit: props.onFinishEdit, onCancelEdit: props.onCancelEdit }));
        }))));
};
var prettify$2 = function (key) {
    return key
        .replace(/\.(\d+)/g, function (_, d) { return " #".concat(+d + 1); })
        .replace(/\./g, ' > ')
        .replace(/([a-z])([A-Z])/g, '$1 $2')
        .replace(/\b\w/g, function (l) { return l.toUpperCase(); });
};

var css_248z$3 = ".powerui-cf-arrayfield {\n    display: flex;\n    flex-direction: column;\n    /* gap: 1rem; */\n    background-color: var(--powerui-cf-bg-group-odd);\n    padding: 12px;\n    border-radius: 12px;\n    /* margin-left: 24px; */\n}\n\n.powerui-cf-arrayfield--even {\n    background-color: var(--powerui-cf-bg-group-even);\n}\n\n.powerui-cf-arrayfield__header {\n    display: flex;\n    justify-content: space-between;\n    align-items: center;\n    opacity: 1;\n    transition: opacity 500ms ease-in-out;\n}\n\n.powerui-cf-arrayfield__header--disabled {\n    opacity: 0.25;\n}\n\n.powerui-cf-arrayfield__header h6 {\n    margin: 0;\n}\n\n.powerui-cf-arrayfield__fields__items {\n    display: flex;\n    flex-direction: column;\n    gap: 1rem;\n}\n\n.powerui-cf-arrayfield__fields__header {\n    display: grid;\n    grid-template-columns: 1fr auto;\n    align-items: center;\n    padding: 24px 0 6px 0;\n}\n\n.powerui-cf-arrayfield__fields__header__title {\n    color: var(--basicui-fg-disabled);\n}\n\n.powerui-cf-arrayfield__fields__header__action__delete,\n.powerui-cf-arrayfield__actions__addaction {\n    font-weight: bold;\n    text-transform: uppercase;\n    color: var(--basicui-bg-danger-muted);\n    font-size: 12px;\n    letter-spacing: 1.5;\n    transition: all 250ms ease-in-out;\n}\n\n.powerui-cf-arrayfield__fields__header__action__delete svg {\n    fill: var(--basicui-bg-danger-muted);\n}\n\n.powerui-cf-arrayfield__actions__addaction svg {\n    fill: var(--basicui-bg-primary-muted);\n}\n\n.powerui-cf-arrayfield__fields__header__action__delete:hover {\n    color: var(--basicui-bg-danger);\n}\n\n.powerui-cf-arrayfield__fields__header__action__delete:hover svg {\n    fill: var(--basicui-bg-danger);\n}\n\n.powerui-cf-arrayfield__actions {\n    display: grid;\n    grid-auto-flow: column;\n    justify-content: space-between;\n    padding: 24px 0 0px 0;\n}\n\n.powerui-cf-arrayfield__actions__addaction {\n    color: var(--basicui-bg-primary-muted);\n}\n\n.powerui-cf-arrayfield__actions__addaction:hover {\n    color: var(--basicui-bg-primary);\n}\n\n.powerui-cf-arrayfield__main {\n    overflow: hidden;\n}\n\n.powerui-cf-arrayfield__main--expanded {\n    visibility: visible;\n}\n\n.powerui-cf-arrayfield__main--collapsed {\n    max-height: 0;\n    pointer-events: none;\n}";
styleInject$1(css_248z$3);

var BASE_CLASS$2 = "powerui-cf-arrayfield";
var ArrayField = function (props) {
    var _a;
    var _b = useState(false), isCollapsed = _b[0], setIsCollapsed = _b[1];
    var handleAddItem = function () {
        var _a;
        var emptyItem = {};
        (_a = props.field.fields) === null || _a === void 0 ? void 0 : _a.forEach(function (sub) {
            emptyItem[sub.name] = '';
        });
        props.onChange(__spreadArray$1(__spreadArray$1([], (props.value || []), true), [emptyItem], false));
    };
    var updateItem = function (index, subName, subVal) {
        var _a;
        var newItems = __spreadArray$1([], (props.value || []), true);
        newItems[index] = __assign$1(__assign$1({}, newItems[index]), (_a = {}, _a[subName] = subVal, _a));
        props.onChange(newItems);
    };
    var handleRemoveItem = function (index) {
        var newItems = __spreadArray$1([], (props.value || []), true);
        newItems.splice(index, 1);
        props.onChange(newItems);
    };
    var toggleCollapse = function () {
        setIsCollapsed(!isCollapsed);
    };
    // useEffect(() => {
    //     if (props.editField === props.fieldPath) {
    //         props.onFinishEdit();
    //     }
    // }, [props.editField, props.fieldPath])
    return (React$1.createElement("div", { className: getClassName(BASE_CLASS$2, [], props.isEven ? ["even"] : []) },
        React$1.createElement("div", { className: getClassName(BASE_CLASS$2, ["header"], (!!props.editField && props.editField !== props.fieldPath) ? ["disabled"] : []) },
            React$1.createElement("h6", null, prettify$1("".concat(props.fieldPath))),
            React$1.createElement("button", { onClick: toggleCollapse, className: getClassName(BASE_CLASS$2, ["collapse-button"], [], "basicui-clean-button"), "aria-label": isCollapsed ? 'Expand section' : 'Collapse section' },
                React$1.createElement(SvgIcon_1, { height: "12px", width: "12px" }, isCollapsed ? (React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 448 512" },
                    React$1.createElement("path", { d: "M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32v112H80c-17.7 0-32 14.3-32 32s14.3 32 32 32h112v112c0 17.7 14.3 32 32 32s32-14.3 32-32V256h112c17.7 0 32-14.3 32-32s-14.3-32-32-32H256V80z" }))) : (React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 448 512" },
                    React$1.createElement("path", { d: "M416 208H32c-17.7 0-32 14.3-32 32s14.3 32 32 32h384c17.7 0 32-14.3 32-32s-14.3-32-32-32z" })))))),
        React$1.createElement("div", { className: getClassName(BASE_CLASS$2, ["main"], isCollapsed ? ["collapsed"] : ["expanded"]) }, (_a = props.value) === null || _a === void 0 ? void 0 :
            _a.map(function (item, index) {
                var _a;
                return (React$1.createElement("div", { key: "".concat(props.fieldPath, ".").concat(index), className: getClassName(BASE_CLASS$2, ["fields"]) },
                    React$1.createElement("div", { className: getClassName(BASE_CLASS$2, ["fields", "header"]) },
                        React$1.createElement("div", { className: getClassName(BASE_CLASS$2, ["fields", "header", "title"], [], "small") }, prettify$1("".concat(props.field.label, " #").concat(index + 1))),
                        React$1.createElement("div", { className: getClassName(BASE_CLASS$2, ["fields", "header", "action"]) },
                            React$1.createElement("button", { onClick: function () { return handleRemoveItem(index); }, className: getClassName(BASE_CLASS$2, ["fields", "header", "action", "delete"], [], "basicui-clean-button") },
                                React$1.createElement(SvgIcon_1, { height: "12px", width: "12px" },
                                    React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 448 512" },
                                        React$1.createElement("path", { d: "M135.2 17.7L128 32 32 32C14.3 32 0 46.3 0 64S14.3 96 32 96h384c17.7 0 32-14.3 32-32S433.7 32 416 32H320l-7.2-14.3C307.4 6.8 296.3 0 284.2 0H163.8c-12.1 0-23.2 6.8-28.6 17.7zM416 128H32l21.2 339c1.6 25.3 22.6 45 47.9 45h245.8c25.3 0 46.3-19.7 47.9-45L416 128z" }))),
                                "Remove"))),
                    React$1.createElement("div", { className: getClassName(BASE_CLASS$2, ["fields", "items"]) }, (_a = props.field.fields) === null || _a === void 0 ? void 0 : _a.map(function (subField) { return (React$1.createElement(FieldRenderer, { key: "".concat(props.fieldPath, ".").concat(index, ".").concat(subField.name), field: subField, fieldPath: "".concat(props.fieldPath, ".").concat(index, ".").concat(subField.name), value: item === null || item === void 0 ? void 0 : item[subField.name], onChange: function (val) { return updateItem(index, subField.name, val); }, isEven: !props.isEven, shortPathTitle: true, editField: props.editField, onStartEdit: props.onStartEdit, onFinishEdit: props.onFinishEdit, onCancelEdit: props.onCancelEdit })); }))));
            }),
            React$1.createElement("div", { className: getClassName(BASE_CLASS$2, ["actions"]) },
                React$1.createElement("div", { className: "small" }, (!props.value || props.value.length == 0) && "No data"),
                React$1.createElement("button", { onClick: handleAddItem, className: getClassName(BASE_CLASS$2, ["actions", "addaction"], [], "basicui-clean-button") },
                    React$1.createElement(SvgIcon_1, { height: "12px", width: "12px" },
                        React$1.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 448 512" },
                            React$1.createElement("path", { d: "M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32v144H48c-17.7 0-32 14.3-32 32s14.3 32 32 32h144v144c0 17.7 14.3 32 32 32s32-14.3 32-32V288h144c17.7 0 32-14.3 32-32s-14.3-32-32-32H256V80z" }))),
                    "Add ",
                    props.field.label)))));
};
var prettify$1 = function (key) {
    return key
        .replace(/\.(\d+)/g, function (_, d) { return " #".concat(+d + 1); })
        .replace(/\./g, ' > ')
        .replace(/([a-z])([A-Z])/g, '$1 $2')
        .replace(/\b\w/g, function (l) { return l.toUpperCase(); });
};

var css_248z$2 = ".powerui-cf-fieldrenderer-shared__prompt {\n    margin-bottom: 0.5rem;\n    font-size: 24px;\n    font-weight: 300;\n}\n\n.powerui-cf-fieldrenderer-shared__reply {\n\n}";
styleInject$1(css_248z$2);

var css_248z$1 = ".powerui-cf-tagfield__read {\n    display: flex;\n}\n\n.powerui-cf-tagfield__read__label {\n    line-height: 2;\n}\n.powerui-cf-tagfield__read__tags,\n.powerui-cf-tagfield__edit__reply__tags {\n    display: flex;\n    flex-wrap: wrap;\n    gap: 6px;\n}\n.powerui-cf-tagfield__edit__reply__tags__tag,\n.powerui-cf-tagfield__read__tags__tag {\n    display: inline-flex;\n    align-items: center;\n    background-color: var(--basicui-bg-accent);\n    border-radius: 24px;\n    padding: 2px 10px;\n    font-size: 0.85rem;\n}\n\n.powerui-cf-tagfield__edit__reply__tags__tag__delete {\n    margin-left: 6px;\n    cursor: pointer;\n    color: var(--basicui-fg-disabled);\n}\n\n.powerui-cf-tagfield__edit .tag-input-wrapper {\n    display: flex;\n    flex-wrap: wrap;\n    gap: 4px;\n    align-items: center;\n    min-height: 40px;\n    padding: 4px 0;\n}\n\n.powerui-cf-tagfield__edit__reply__tags__input {\n    border: none;\n    width: 100%;\n    outline: none;\n    background-color: transparent;\n    color: var(--basicui-fg);\n    border-radius: 6px;\n    border: 1px solid var(--powerui-cf-border-color);\n    padding: 12px;\n}\n\n.powerui-cf-tagfield__read__label {\n    color: var(--basicui-fg-disabled);\n}";
styleInject$1(css_248z$1);

var BASE_CLASS$1 = 'powerui-cf-tagfield';
var TagField = function (_a) {
    var field = _a.field, fieldPath = _a.fieldPath, _b = _a.value, value = _b === void 0 ? [] : _b, onChange = _a.onChange, editField = _a.editField, onStartEdit = _a.onStartEdit, onFinishEdit = _a.onFinishEdit, onCancelEdit = _a.onCancelEdit;
    var _c = useState(Array.isArray(value) ? value : []), localValue = _c[0], setLocalValue = _c[1];
    useEffect(function () {
        setLocalValue(value || '');
    }, [value]);
    var _d = useState(''), inputValue = _d[0], setInputValue = _d[1];
    var handleAddTag = function () {
        var entries = inputValue
            .split(',')
            .map(function (label) { return label.trim(); })
            .filter(function (label) { return label && !localValue.some(function (tag) { return tag.value === label; }); });
        if (entries.length) {
            var newTags = entries.map(function (value) { return ({ value: value }); });
            setLocalValue(__spreadArray$1(__spreadArray$1([], localValue, true), newTags, true));
            setInputValue('');
        }
    };
    var handleRemoveTag = function (tagToRemove) {
        setLocalValue(localValue.filter(function (tag) { return tag.value !== tagToRemove; }));
    };
    var handleSubmit = function () {
        onChange(localValue);
        onFinishEdit();
    };
    var handleCancel = function () {
        setLocalValue(Array.isArray(value) ? value : []);
        setInputValue('');
        onCancelEdit();
    };
    var handleKeyDown = function (e) {
        if (e.key === 'Enter' || e.key === ',') {
            e.preventDefault();
            handleAddTag();
        }
    };
    var handleRequestEdit = function () {
        if (!editField) {
            onStartEdit(fieldPath);
        }
    };
    return (React$1.createElement(ChatBubble, { isEdit: editField === fieldPath, onEdit: handleRequestEdit, onCancel: onCancelEdit, disabled: !!editField && editField !== fieldPath }, editField !== fieldPath ? (React$1.createElement(React$1.Fragment, null,
        React$1.createElement("div", { className: getClassName(BASE_CLASS$1, ['read', 'label']) }, field.label),
        localValue.length > 0 && React$1.createElement("div", { className: getClassName(BASE_CLASS$1, ['read', 'tags']) }, localValue.map(function (tag, idx) { return (React$1.createElement("span", { key: idx, className: getClassName(BASE_CLASS$1, ['read', 'tags', "tag"]) }, tag.value)); })))) : (React$1.createElement("div", { className: getClassName(BASE_CLASS$1, ['edit']) },
        React$1.createElement("div", { className: getClassName(BASE_CLASS$1, ['edit', 'prompt'], [], getClassName(BASE_CLASS_FIELD_RENDERER_SHARED, ['prompt'])) }, field.conversationalPrompt || "Enter ".concat(prettify(fieldPath), ":")),
        React$1.createElement("div", { className: getClassName(BASE_CLASS$1, ['edit', 'reply'], [], getClassName(BASE_CLASS_FIELD_RENDERER_SHARED, ['reply'])), onClick: function (e) { return e.stopPropagation(); } },
            React$1.createElement("div", { className: getClassName(BASE_CLASS$1, ['edit', 'reply', "tags"], []) },
                React$1.createElement("input", { type: "text", placeholder: "Add text with comma separated and press enter/return", value: inputValue, onChange: function (e) { return setInputValue(e.target.value); }, onKeyDown: handleKeyDown, className: getClassName(BASE_CLASS$1, ['edit', 'reply', "tags", "input"], []), autoFocus: true }),
                localValue.map(function (tag, index) { return (React$1.createElement("span", { className: getClassName(BASE_CLASS$1, ['edit', 'reply', "tags", "tag"], []), key: index },
                    tag.value,
                    React$1.createElement("span", { className: getClassName(BASE_CLASS$1, ['edit', 'reply', "tags", "tag", "delete"], []), onClick: function () { return handleRemoveTag(tag.value); } }, "\u00D7"))); }))),
        React$1.createElement(ReplyAction, { onSave: handleSubmit, onCancel: handleCancel })))));
};
var prettify = function (key) {
    return key
        .replace(/\.(\d+)/g, function (_, d) { return " #".concat(+d + 1); })
        .replace(/\./g, ' > ')
        .replace(/([a-z])([A-Z])/g, '$1 $2')
        .replace(/\b\w/g, function (l) { return l.toUpperCase(); });
};

var BASE_CLASS_FIELD_RENDERER_SHARED = "powerui-cf-fieldrenderer-shared";
var FieldRenderer = function (props) {
    var field = props.field;
    switch (field.type) {
        case 'text':
        case 'email':
        case 'number':
        case 'phone':
        case 'password':
        case 'textarea':
            return React$1.createElement(TextField, __assign$1({}, props));
        case 'tag':
            return React$1.createElement(TagField, __assign$1({}, props));
        case 'select':
        case 'multiselect':
            return React$1.createElement(SelectField, __assign$1({}, props));
        case 'group':
            return React$1.createElement(GroupField, __assign$1({}, props));
        case 'array':
            return React$1.createElement(ArrayField, __assign$1({}, props));
        default:
            return React$1.createElement("div", null,
                "Unsupported field type: ",
                field.type);
    }
};

var css_248z = ".powerui-cf {\n  display: flex;\n  flex-direction: column;\n  gap: 1rem;\n}\n\n.powerui-cf__actionheader {\n  display: grid;\n  grid-auto-flow: column;\n  justify-content: space-between;\n  align-items: center;\n}\n\n.powerui-cf__actionheader__actions {\n  display: flex;\n  flex-direction: row;\n  column-gap: 12px;\n}\n\n.powerui-cf__actionheader__search input {\n  padding: 12px;\n  border: 1px solid var(--basicui-border-color);\n  border-radius: 12px;\n  width: 240px;\n  background-color: var(--basicui-bg-card);\n  background-color: transparent;\n  color: var(--basicui-fg);\n  outline: none;\n}";
styleInject$1(css_248z);

var BASE_CLASS = "powerui-cf";
var NestedChatForm = function (props) {
    var _a = useState(''), searchText = _a[0], setSearchText = _a[1];
    var _b = useState(), editField = _b[0], setEditField = _b[1];
    var updateFormDataAtPath = function (path, value) {
        var segments = path.split('.');
        var updated = __assign$1({}, props.formData);
        var ref = updated;
        for (var i = 0; i < segments.length - 1; i++) {
            var seg = segments[i];
            var next = segments[i + 1];
            var isArray = !isNaN(Number(next));
            if (!ref[seg]) {
                ref[seg] = isArray ? [] : {};
            }
            ref = ref[seg];
        }
        ref[segments[segments.length - 1]] = value;
        props.onChange(updated);
    };
    var getValueAtPath = function (path) {
        return path.split('.').reduce(function (acc, key) { return acc === null || acc === void 0 ? void 0 : acc[key]; }, props.formData);
    };
    var filterFieldsBySearch = function (fields, pathPrefix) {
        return fields
            .map(function (field) {
            var _a, _b, _c, _d;
            var fullPath = pathPrefix ? "".concat(pathPrefix, ".").concat(field.name) : field.name;
            var labelMatch = (_b = (_a = field.label) === null || _a === void 0 ? void 0 : _a.toLowerCase().includes(searchText.toLowerCase())) !== null && _b !== void 0 ? _b : false;
            var nameMatch = field.name.toLowerCase().includes(searchText.toLowerCase());
            var promptMatch = (_d = (_c = field.conversationalPrompt) === null || _c === void 0 ? void 0 : _c.toLowerCase().includes(searchText.toLowerCase())) !== null && _d !== void 0 ? _d : false;
            if (labelMatch || nameMatch || promptMatch) {
                return field;
            }
            if ((field.type === 'group' || field.type === 'array') && field.fields) {
                var subfields = filterFieldsBySearch(field.fields, fullPath);
                if (subfields.length > 0) {
                    return __assign$1(__assign$1({}, field), { fields: subfields });
                }
            }
            return null;
        })
            .filter(function (f) { return f !== null; });
    };
    var filteredFields = useMemo(function () {
        if (!searchText.trim())
            return props.schema.fields;
        setEditField(undefined);
        return filterFieldsBySearch(props.schema.fields, '');
    }, [searchText, props.schema.fields]);
    var flattenFieldsWithData = function (fields, formData, pathPrefix) {
        if (pathPrefix === void 0) { pathPrefix = ''; }
        return fields.flatMap(function (field) {
            var fullPath = pathPrefix ? "".concat(pathPrefix, ".").concat(field.name) : field.name;
            var fieldData = getValueAtPath(fullPath);
            if (field.type === 'group' && field.fields) {
                return flattenFieldsWithData(field.fields, formData, fullPath);
            }
            if (field.type === 'array') {
                if (!Array.isArray(fieldData) || fieldData.length === 0) {
                    // Skip this array field entirely if it has no entries
                    return [];
                }
                return fieldData.flatMap(function (_, index) {
                    var itemPath = "".concat(fullPath, ".").concat(index);
                    return flattenFieldsWithData(field.fields, formData, itemPath);
                });
            }
            return [fullPath];
        });
    };
    var flattenedFieldPaths = useMemo(function () {
        return flattenFieldsWithData(props.schema.fields, props.formData);
    }, [props.schema.fields, props.formData]);
    var handleFinishEdit = function () {
        if (!editField)
            return;
        var currentIndex = flattenedFieldPaths.indexOf(editField);
        console.log(currentIndex, flattenedFieldPaths, currentIndex >= 0 && currentIndex < flattenedFieldPaths.length - 1);
        if (currentIndex >= 0 && currentIndex < flattenedFieldPaths.length - 1) {
            setEditField(flattenedFieldPaths[currentIndex + 1]);
            console.log("*", flattenedFieldPaths[currentIndex + 1]);
        }
        else {
            setEditField(undefined);
        }
    };
    var handleCancelEdit = function () {
        setEditField(undefined);
    };
    useEffect(function () {
        console.log(editField);
    }, [editField]);
    return (React$1.createElement(React$1.Fragment, null,
        React$1.createElement("div", { className: getClassName(BASE_CLASS) },
            React$1.createElement("div", { className: getClassName(BASE_CLASS, ["actionheader"]) },
                React$1.createElement("div", { className: getClassName(BASE_CLASS, ["actionheader", "search"]) },
                    React$1.createElement("input", { autoFocus: true, type: "text", placeholder: "Search fields...", value: searchText, onChange: function (e) { return setSearchText(e.target.value); } })),
                React$1.createElement("div", { className: getClassName(BASE_CLASS, ["actionheader", "actions"]) }, props.actions)),
            filteredFields.map(function (field) { return (React$1.createElement(FieldRenderer, { key: field.name, field: field, fieldPath: field.name, value: getValueAtPath(field.name), onChange: function (val) { return updateFormDataAtPath(field.name, val); }, editField: editField, onStartEdit: function (e) { return setEditField(e); }, onFinishEdit: handleFinishEdit, onCancelEdit: handleCancelEdit, errorMap: props.errorMap, onAssist: props.onAssist })); }))));
};

var getEditorConfig = function () {
    var config = useEditor({
        extensions: [
            Typography,
            TextStyle, Color,
            Underline$1.configure({
                HTMLAttributes: {
                    class: 'my-custom-class',
                },
            }),
            TextAlign.configure({
                types: ['heading', 'paragraph'],
            }),
            Image.configure({
                HTMLAttributes: {
                    class: 'my-custom-class',
                },
                inline: true,
                allowBase64: true,
            }),
            Youtube.configure({
                inline: true,
                controls: true,
            }),
            Table.configure({
                HTMLAttributes: {
                    class: 'my-custom-class',
                },
                resizable: true
            }),
            TableRow,
            TableHeader,
            TableCell,
            FontFamily.configure({
                types: ['textStyle'],
            }),
            Link.configure({
                HTMLAttributes: {
                    class: 'my-custom-class',
                },
                validate: function (href) { return /^https?:\/\//.test(href); },
            }),
            Highlight.configure({
                HTMLAttributes: {
                    class: 'my-custom-class',
                },
                multicolor: true,
            }),
            Subscript,
            Superscript,
            TaskList.configure({
                HTMLAttributes: {
                    class: 'my-custom-class',
                },
            }),
            TaskItem.configure({
                nested: true,
            }),
            StarterKit.configure({
                bulletList: {
                    keepMarks: true,
                    keepAttributes: false, // TODO : Making this as `false` becase marks are not preserved when I try to preserve attrs, awaiting a bit of help
                },
                orderedList: {
                    keepMarks: true,
                    keepAttributes: false, // TODO : Making this as `false` becase marks are not preserved when I try to preserve attrs, awaiting a bit of help
                },
            }),
        ],
        content: "Hello",
    });
    return config;
};

var EditorUtils = /*#__PURE__*/Object.freeze({
    __proto__: null,
    getEditorConfig: getEditorConfig
});

var uispec_types = /*#__PURE__*/Object.freeze({
    __proto__: null
});

export { AddImage, AddTable, AddYoutubeVideo, AlignCenter, AlignJustify, AlignLeft, AlignRight, AlignmentDropdown, BlockQuote, Bold, BulletList, ClearFormatting, Code, CodeBlock, NestedChatForm as ConversationalForm, uispec_types as ConversationalFormTypes, Editor, EditorUtils, FontColor, HeadingDropdown, HighlightColor, HorizontalRule, Italic, List, ListItem, OrderedList, SearchBar, Strikethrough, Toolbar, Underline };
//# sourceMappingURL=index.esm.js.map
