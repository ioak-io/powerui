import React from 'react';
import { ArrayField } from '../../types/DynamicFormTypes';
import { OptionsObjectType } from 'basicui';
type ArrayFieldComponentProps = {
    field: ArrayField;
    value: any[];
    optionsLookupDictionary: {
        [key: string]: OptionsObjectType[];
    };
};
declare const ArrayFieldComponent: React.FC<ArrayFieldComponentProps>;
export default ArrayFieldComponent;
