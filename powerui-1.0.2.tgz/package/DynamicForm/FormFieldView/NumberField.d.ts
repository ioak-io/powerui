import React from 'react';
import { OptionsObjectType } from 'basicui';
import { NumberField } from '../../types/DynamicFormTypes';
declare const NumberFieldComponent: ({ field, value, optionsLookupDictionary, }: {
    field: NumberField;
    value: any;
    optionsLookupDictionary: {
        [key: string]: OptionsObjectType[];
    };
}) => React.JSX.Element;
export default NumberFieldComponent;
