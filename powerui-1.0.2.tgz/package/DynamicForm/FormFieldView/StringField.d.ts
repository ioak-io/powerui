import React from 'react';
import { OptionsObjectType } from 'basicui';
import { StringField } from '../../types/DynamicFormTypes';
declare const StringFieldComponent: ({ field, value, optionsLookupDictionary, }: {
    field: StringField;
    value: any;
    optionsLookupDictionary: {
        [key: string]: OptionsObjectType[];
    };
}) => React.JSX.Element;
export default StringFieldComponent;
