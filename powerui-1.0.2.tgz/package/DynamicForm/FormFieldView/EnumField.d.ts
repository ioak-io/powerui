import React from 'react';
import { EnumField } from '../../types/DynamicFormTypes';
declare const EnumFieldComponent: ({ field, value, }: {
    field: EnumField;
    value: any;
}) => React.JSX.Element;
export default EnumFieldComponent;
