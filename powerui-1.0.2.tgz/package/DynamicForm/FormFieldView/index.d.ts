import React from 'react';
import { SpecField } from '../../types/DynamicFormTypes';
import { OptionsObjectType } from 'basicui';
declare const FormFieldView: ({ field, value, optionsLookupDictionary, }: {
    field: SpecField;
    value: any;
    optionsLookupDictionary: {
        [key: string]: OptionsObjectType[];
    };
}) => React.JSX.Element | null;
export default FormFieldView;
