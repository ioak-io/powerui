import React from 'react';
import { OptionsObjectType } from 'basicui';
import { ObjectField } from '../../types/DynamicFormTypes';
declare const ObjectFieldComponent: ({ field, value, optionsLookupDictionary, }: {
    field: ObjectField;
    value: any;
    optionsLookupDictionary: {
        [key: string]: OptionsObjectType[];
    };
}) => React.JSX.Element;
export default ObjectFieldComponent;
