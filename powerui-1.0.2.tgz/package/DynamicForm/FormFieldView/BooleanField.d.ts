import React from 'react';
import { BooleanField } from '../../types/DynamicFormTypes';
declare const BooleanFieldComponent: ({ field, value, }: {
    field: BooleanField;
    value: any;
}) => React.JSX.Element;
export default BooleanFieldComponent;
