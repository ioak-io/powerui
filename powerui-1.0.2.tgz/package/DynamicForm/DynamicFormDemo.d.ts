import React from 'react';
declare const DynamicFormDemo: () => React.JSX.Element;
export default DynamicFormDemo;
