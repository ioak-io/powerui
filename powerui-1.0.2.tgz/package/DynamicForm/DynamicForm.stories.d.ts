import { Meta, StoryObj } from '@storybook/react';
import DynamicFormDemo from './DynamicFormDemo';
declare const meta: Meta<typeof DynamicFormDemo>;
export default meta;
type Story = StoryObj<typeof DynamicFormDemo>;
export declare const Demo: Story;
