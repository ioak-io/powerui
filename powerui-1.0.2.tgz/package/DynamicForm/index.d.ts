import React from 'react';
import { DynamicFormProps, DynamicFormHandle } from '../types/DynamicFormTypes';
declare const DynamicForm: React.ForwardRefExoticComponent<DynamicFormProps & React.RefAttributes<DynamicFormHandle>>;
export default DynamicForm;
