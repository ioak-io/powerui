import React from 'react';
import { OptionsObjectType } from 'basicui';
import { ObjectField } from '../../types/DynamicFormTypes';
declare const ObjectFieldComponent: ({ fieldName, field, value, onChange, optionsLookupDictionary, onRemove }: {
    fieldName: string;
    field: ObjectField;
    value: any;
    onChange: (name: string, value: any) => void;
    optionsLookupDictionary: {
        [key: string]: OptionsObjectType[];
    };
    onRemove?: () => void;
}) => React.JSX.Element;
export default ObjectFieldComponent;
