import React from 'react';
import { ArrayField } from '../../types/DynamicFormTypes';
import { OptionsObjectType } from 'basicui';
type ArrayFieldComponentProps = {
    fieldName: string;
    field: ArrayField;
    value: any[];
    onChange: (name: string, value: any[]) => void;
    optionsLookupDictionary: {
        [key: string]: OptionsObjectType[];
    };
};
declare const ArrayFieldComponent: React.FC<ArrayFieldComponentProps>;
export default ArrayFieldComponent;
