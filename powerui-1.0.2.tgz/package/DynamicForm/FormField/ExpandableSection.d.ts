import React from 'react';
type ExpandableSectionProps = {
    expanded: boolean;
    onToggleExpand: () => void;
    onRemove?: () => void;
    label: string;
    labelDesc?: string;
    children: React.ReactNode;
};
declare const ExpandableSection: React.FC<ExpandableSectionProps>;
export default ExpandableSection;
