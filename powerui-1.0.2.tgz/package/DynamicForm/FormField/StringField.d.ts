import React from 'react';
import { OptionsObjectType } from 'basicui';
import { StringField } from '../../types/DynamicFormTypes';
declare const StringFieldComponent: ({ fieldName, field, value, onChange, optionsLookupDictionary, editor }: {
    fieldName: string;
    field: StringField;
    value: any;
    onChange: (name: string, value: any) => void;
    optionsLookupDictionary: {
        [key: string]: OptionsObjectType[];
    };
    editor?: any;
}) => React.JSX.Element | undefined;
export default StringFieldComponent;
