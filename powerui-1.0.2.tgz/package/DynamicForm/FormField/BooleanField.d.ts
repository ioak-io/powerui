import React from 'react';
import { BooleanField } from '../../types/DynamicFormTypes';
declare const BooleanFieldComponent: ({ fieldName, field, value, onChange, }: {
    fieldName: string;
    field: BooleanField;
    value: any;
    onChange: (name: string, value: any) => void;
}) => React.JSX.Element;
export default BooleanFieldComponent;
