import React from 'react';
import { OptionsObjectType } from 'basicui';
import { NumberField } from '../../types/DynamicFormTypes';
declare const NumberFieldComponent: ({ fieldName, field, value, onChange, optionsLookupDictionary }: {
    fieldName: string;
    field: NumberField;
    value: any;
    onChange: (name: string, value: any) => void;
    optionsLookupDictionary: {
        [key: string]: OptionsObjectType[];
    };
}) => React.JSX.Element | undefined;
export default NumberFieldComponent;
