import React from 'react';
import { SpecField } from '../../types/DynamicFormTypes';
import { OptionsObjectType } from 'basicui';
declare const FormField: ({ fieldName, field, value, onChange, optionsLookupDictionary, onRemove, editor }: {
    fieldName: string;
    field: SpecField;
    value: any;
    onChange: (name: string, value: any) => void;
    optionsLookupDictionary: {
        [key: string]: OptionsObjectType[];
    };
    onRemove?: () => void;
    editor?: any;
}) => React.JSX.Element | null;
export default FormField;
