import React from 'react';
import { EnumField } from '../../types/DynamicFormTypes';
declare const EnumFieldComponent: ({ fieldName, field, value, onChange, }: {
    fieldName: string;
    field: EnumField;
    value: any;
    onChange: (name: string, value: any) => void;
}) => React.JSX.Element;
export default EnumFieldComponent;
