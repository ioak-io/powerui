export type FieldType = 'text' | 'textarea' | 'number' | 'select' | 'multiselect' | 'date' | 'boolean' | 'email' | 'phone' | 'password' | 'tag' | 'group' | 'array' | 'custom';
export interface FieldOption {
    name: string;
    value: string | number | boolean;
}
export interface FieldValidation {
    required?: boolean;
    minLength?: number;
    maxLength?: number;
    pattern?: string;
    min?: number;
    max?: number;
    customValidator?: (value: any) => string | null;
}
export interface FormFieldSchema {
    name: string;
    type: FieldType;
    label?: string;
    description?: string;
    placeholder?: string;
    defaultValue?: any;
    options?: {
        label: string;
        value: string | number;
    }[];
    validation?: FieldValidation;
    multiple?: boolean;
    visibleIf?: {
        referenceField: string;
        value?: any;
    }[];
    editableIf?: {
        referenceField: string;
        value?: any;
    }[];
    conversationalPrompt?: string;
    fields?: FormFieldSchema[];
    assistant?: {
        id: string;
    };
}
export interface FormAction {
    label: string;
    type: "save" | "reset" | "cancel" | "delete" | "generate" | "version" | "custom";
    icon?: any;
    generation?: {
        id: string;
        inputFields?: FormFieldSchema[];
    };
}
export interface FormSchema {
    header?: {
        title?: {
            type: "static" | "dynamic";
            field?: string;
            value?: string;
        };
        subtitle?: {
            type: "static" | "dynamic";
            field?: string;
            value?: string;
        };
        actions?: FormAction[];
    };
    versioning?: boolean;
    fields: FormFieldSchema[];
    actions?: {
        primaryMenu?: FormAction[];
        contextMenu?: FormAction[];
    };
    children?: {
        domain: string;
        field: {
            parent: string;
            child: string;
        };
        formSchemaId: string;
    }[];
}
export interface DomainVersion {
    _id: string;
    __version: string;
    __columns: Record<string, number>;
    __percentage: number;
    reference: string;
    updatedBy: string;
    updatedAt: Date;
    createdBy: string;
    createdAt: Date;
}
