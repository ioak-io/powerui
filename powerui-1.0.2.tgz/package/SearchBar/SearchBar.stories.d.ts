import { Meta } from '@storybook/react';
import SearchBar, { SearchBarProps } from '.';
declare const meta: Meta<typeof SearchBar>;
export default meta;
export declare const Playground: {
    args: {
        onSearch: (data: {
            searchText: string;
            filters: {
                fieldName: string;
                selectedValueList: (string | number)[];
            }[];
        }) => void;
        filters: import("..").SearchBarFilterType[];
        placeholder?: string;
    };
    decorators?: import("@storybook/types").DecoratorFunction<import("@storybook/react").ReactRenderer, {
        onSearch: (data: {
            searchText: string;
            filters: {
                fieldName: string;
                selectedValueList: (string | number)[];
            }[];
        }) => void;
        filters: import("..").SearchBarFilterType[];
        placeholder?: string | undefined;
    }> | import("@storybook/types").DecoratorFunction<import("@storybook/react").ReactRenderer, {
        onSearch: (data: {
            searchText: string;
            filters: {
                fieldName: string;
                selectedValueList: (string | number)[];
            }[];
        }) => void;
        filters: import("..").SearchBarFilterType[];
        placeholder?: string | undefined;
    }>[] | undefined;
    parameters?: import("@storybook/types").Parameters;
    argTypes?: Partial<import("@storybook/types").ArgTypes<SearchBarProps>> | undefined;
    loaders?: import("@storybook/types").LoaderFunction<import("@storybook/react").ReactRenderer, SearchBarProps> | import("@storybook/types").LoaderFunction<import("@storybook/react").ReactRenderer, SearchBarProps>[] | undefined;
    render?: import("@storybook/types").ArgsStoryFn<import("@storybook/react").ReactRenderer, SearchBarProps> | undefined;
    name?: import("@storybook/types").StoryName;
    storyName?: import("@storybook/types").StoryName;
    play?: import("@storybook/types").PlayFunction<import("@storybook/react").ReactRenderer, SearchBarProps> | undefined;
    tags?: import("@storybook/types").Tag[];
    story?: Omit<import("@storybook/types").StoryAnnotations<import("@storybook/react").ReactRenderer, SearchBarProps, Partial<SearchBarProps>>, "story"> | undefined;
};
