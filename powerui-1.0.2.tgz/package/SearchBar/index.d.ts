import React from "react";
import { SearchBarFilterType } from "../types/SearchBarFilterType";
type SearchPayload = {
    searchText: string;
    filters: {
        fieldName: string;
        selectedValueList: (string | number)[];
    }[];
};
export type SearchBarProps = {
    onSearch: (data: SearchPayload) => void;
    filters: SearchBarFilterType[];
    placeholder?: string;
};
/**
 * Component to render search bar with advanced options.
 */
declare const SearchBar: (props: SearchBarProps) => React.JSX.Element;
export default SearchBar;
