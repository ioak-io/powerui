import React from 'react';
type FilterSectionProps = {
    fieldLabel: string;
    fieldName: string;
    fieldValues: {
        id: string | number;
        label: string;
    }[];
    selectedFilters: Record<string, (string | number)[]>;
    toggleFilter: (field: string, valueId: string | number) => void;
};
declare const FilterSection: ({ fieldLabel, fieldName, fieldValues, selectedFilters, toggleFilter }: FilterSectionProps) => React.JSX.Element;
export default FilterSection;
