import './style.css';
import React from 'react';
export type EditorProps = {
    editor: any;
    children: any;
    toolbarPlacement?: 'top' | 'bottom';
    onChange?: (content: string) => void;
};
declare const Editor: (props: EditorProps) => React.JSX.Element;
export default Editor;
