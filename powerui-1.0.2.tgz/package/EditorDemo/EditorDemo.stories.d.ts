import { Meta } from '@storybook/react';
import EditorDemo, { EditorDemoProps } from '.';
declare const meta: Meta<typeof EditorDemo>;
export default meta;
export declare const Demo: {
    args: {
        toolbarPlacement: string;
    };
    decorators?: import("@storybook/types").DecoratorFunction<import("@storybook/react").ReactRenderer, {
        toolbarPlacement?: "top" | "bottom" | undefined;
    }> | import("@storybook/types").DecoratorFunction<import("@storybook/react").ReactRenderer, {
        toolbarPlacement?: "top" | "bottom" | undefined;
    }>[] | undefined;
    parameters?: import("@storybook/types").Parameters;
    argTypes?: Partial<import("@storybook/types").ArgTypes<EditorDemoProps>> | undefined;
    loaders?: import("@storybook/types").LoaderFunction<import("@storybook/react").ReactRenderer, EditorDemoProps> | import("@storybook/types").LoaderFunction<import("@storybook/react").ReactRenderer, EditorDemoProps>[] | undefined;
    render?: import("@storybook/types").ArgsStoryFn<import("@storybook/react").ReactRenderer, EditorDemoProps> | undefined;
    name?: import("@storybook/types").StoryName;
    storyName?: import("@storybook/types").StoryName;
    play?: import("@storybook/types").PlayFunction<import("@storybook/react").ReactRenderer, EditorDemoProps> | undefined;
    tags?: import("@storybook/types").Tag[];
    story?: Omit<import("@storybook/types").StoryAnnotations<import("@storybook/react").ReactRenderer, EditorDemoProps, Partial<EditorDemoProps>>, "story"> | undefined;
};
