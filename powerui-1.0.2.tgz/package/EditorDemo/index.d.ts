import React from 'react';
import './style.css';
export type EditorDemoProps = {
    toolbarPlacement?: 'top' | 'bottom';
};
declare const EditorDemo: (props: EditorDemoProps) => React.JSX.Element;
export default EditorDemo;
