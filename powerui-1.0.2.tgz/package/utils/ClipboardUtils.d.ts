export declare const copyHtmlToClipboard: ({ htmlContent, textContent, }: {
    htmlContent?: string;
    textContent?: string;
}) => "" | undefined;
