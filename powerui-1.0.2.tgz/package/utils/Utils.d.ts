export declare function isEmptyOrSpaces(str: any): boolean;
export declare function isEmptyAttributes(object: Record<string, any>): boolean;
export declare function match(text: string, words: string): boolean;
export declare function sort(array: any[], property: string | number, isReverseOrder: boolean): any[];
export declare function htmlToText(str?: string | null): string | false;
