export declare const formatDate: (input?: string | Date | null) => string;
