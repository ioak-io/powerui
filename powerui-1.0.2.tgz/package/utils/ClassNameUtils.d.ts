export declare const getClassName: (baseClassName: string, section?: string[], variants?: string[], additionalClassName?: string) => string;
